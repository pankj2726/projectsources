# Changelog

## Full audit + undo/redo fix (unreleased – nothing here has been run in a browser or deployed)

### Fixed
- **Undo / redo did nothing after a text edit.** Committing from the sidebar's Text box (or the mobile Done button) left keyboard focus inside that field, so Ctrl/Cmd+Z was treated as typing and the browser undid text *inside the closed box* instead of the document edit. Focus now returns to the document, where undo/redo reach the command stack.
- The **undo/redo buttons above the phone keyboard** acted on the formatting history instead of the document. They now undo the edit; the formatting undo stays in the text panel.
- Changes made with the object **Properties** panel could not be undone: history was only written when the field lost focus, and several handlers deliberately keep focus. A burst of changes is now recorded as one undo step even without a blur.
- **Pinching / opening the keyboard could jump the view**: the code that restored the scroll position after a viewport resize used a broken expression. The same scroll offset is now restored, which is correct because these events do not change zoom.
- **Ctrl/Cmd+B, I and U restyled text even while formatting was locked.**
- The **mobile bottom toolbar showed "Edit text" twice.**
- The web app manifest is now served as a real file (a data-URI manifest is not reliably accepted by browsers).

### Not fixed / still open
Nothing in this entry has been executed: the three new e2e regression tests and the existing suites have not been run, and no real-device check was made. See `docs/KNOWN_LIMITATIONS.md` (KL-SIDEBAR-TEXT-SYNC, KL-FRAME-*).

## Regression: the "Edited text" sidebar panel is back (unreleased – nothing here has been run in a browser or deployed)

### Fixed
- **Clicking text shows the familiar panel again**: a **Text** box with the whole line, `Original: "…"` with a **Reset** button, the detected font and size, **B**/**I** and colour, and the cover-and-replace note with the sampled background colour. It had silently become unreachable: the old panel only appeared for a *selected* text object, and the one-click editor never selects anything.
- The **Properties / Forms tabs no longer disappear** while you edit text (the text panel now lives inside the Properties tab).

### Changed
- The Text box in the sidebar and the editor on the page are two views of the same text: type in either and the other follows, and the text box frame resizes with it. Enter in the sidebar commits the edit (one undo step), Esc returns to the page editor.
- Reset puts the line back to the page's text without closing the edit.

### Known gaps
The caret jumps to the end when you type in the sidebar; the page editor's selection is not mirrored into the sidebar. Nothing has been executed – see KL-SIDEBAR-TEXT-REGR / KL-SIDEBAR-TEXT-SYNC.

## TASKS-02 §2.4C: active text box restored (unreleased – nothing here has been run in a browser or deployed)

### Fixed
- **The text box around the text you are editing is back.** It was only ever drawn for the Select tool, and the one-click editor never selects anything, so it never appeared. It now belongs to the edit itself: it appears with the editor and the sidebar, only for the line being edited, never on hover, and vanishes completely when the edit closes.

### Added
- A clear 1.5 px accent frame with a white halo (readable on light, dark and image backgrounds) that stays the same thickness at every zoom, hugs the line, and grows and shrinks as you type. It follows zoom, scrolling, page rotation and CropBox offsets.
- **8 resize handles** (edges change the width – a paragraph reflows, a line shrinks to fit down to 60%; Shift + a corner scales the font), a **rotate handle** (Shift snaps to 15°), **move** by dragging the border or the grip, and **arrow keys** (1 pt, 10 pt with Shift) when the box border has focus. Each change is one undo step.
- Using the frame never closes or commits the edit. The sidebar's Box fields (new editable **Box width**, Offset X / Y, Rotation) and the frame update each other live.
- Width, position and rotation set on the frame are what gets exported.

### Known gaps
Top / bottom handles scale the font (line) or the line spacing (paragraph) – the task did not say; dragging handles by touch is untested and the handles are small; Safari is unverified; no visual baselines yet. Nothing has been executed – see KL-FRAME-GATES.

## TASKS-02 §2.4A: text properties sidebar restored (unreleased – nothing here has been run in a browser or deployed)

### Fixed
- **The text sidebar (size, font, colour, formatting…) no longer disappears while you edit text.** It was tied to the object selection, which the one-click editor never sets. It now belongs to the edit itself: it opens the moment the editor opens, stays for the whole edit, and is filled from the clicked line's real font name, size and colour (with "substituted" / "estimated" hints) instead of defaults.
- Using the sidebar can no longer close or commit the edit: its buttons don't take focus, a click on it isn't "outside", and focus returns to the editor with your selection intact.

### Added
- Font family / size, bold, italic, underline, strikethrough, super/subscript, colour (picker, hex, eyedropper where supported, recent colours), background fill, opacity, alignment, line / character / word spacing, UPPER / lower / Title Case, offset, rotation, front / back, lock, duplicate, delete, undo / redo of format changes, reset. Groups collapse and remember it. Ctrl/Cmd+B / I / U work in the editor.
- **Range-aware formatting**: with a selection only the selection changes; with just a caret the whole line and new typing follow; mixed values show "Mixed". A restyle redraws only the formatted words, never the rest of the line.
- Live preview while editing, and the same layout is used for export, so the downloaded file matches.
- With nothing being edited, the text tools show (and use) the defaults for the next new text box. On phones and tablets the panel is a bottom sheet.
- UI feature checklist (static test + e2e suite) so a future change cannot silently remove a toolbar button, panel or shortcut.

### Known gaps
Original colour space (gray / CMYK / ICC) is not preserved on restyled text (pdf.js hands over RGB); colour is exact only on pages whose text is a single colour; only Sans / Serif / Mono are available; see KL-SIDEBAR-* and KL-COLORSPACE. Nothing has been executed – see KL-SIDEBAR-GATES.

## TASKS-02 revision: edit unit = line segment (unreleased – nothing here has been run in a browser or deployed)

### Fixed
- Editing a word no longer turns every word into its own object. Text is grouped into the line segment a human sees; a sentence opens as one unit, while other columns, table cells (ruling lines), large gaps, style/size jumps and rotated text never join in. Justified text with stretched, uniform spaces stays one line.

### Changed
- **One click edits.** Click any text and its line opens in an inline editor immediately, caret where you clicked. No hover outlines or popovers (an optional "highlight on hover" setting is off by default); the pointer just becomes an I-beam over text. A tap does the same on touch. Enter saves, Esc cancels, one Ctrl/Cmd+Z undoes the whole edit; clicking another line saves this one and opens that one.
- **Minimal-diff saves.** Only the changed characters are covered and rewritten; unchanged words stay exactly where they are. If the new text is wider or narrower only the rest of that line moves. No room → shrink to fit, allow overflow, or skip, with a message. No change → nothing happens. The new text is real text, written as one run.
- Replace / Replace All use the same save path, grouped per line, still one undo step.
- Optional paragraph (reflow) mode in the Edit text panel. `?debug=text` now shows units, and every boundary decision with its reason.

### Not done
Removing the old glyphs from the file (the covered original is still extractable) and updating OCR layers (KL-EDIT-2); a boundary for text layered over shapes/watermarks (KL-LAYERS). Nothing has been executed – see KL-T2R-GATES.

## TASKS-02 (earlier entry; nothing in it has been run in a browser or deployed)

### Fixed
- **Download produced a broken file.** Export removed all pages and re-added them, but the PDF library deletes a page's object when it is removed, so every export wrote dangling page references. Pages are now restored under their original references (root cause identified from the library source; see `docs/DECISIONS.md` D14).
- A failure while verifying the output could stop the download silently. Verification no longer gates the download (except for redactions), and every failure now shows a plain message.

### Changed
- Export keeps going when one object is bad: invalid objects (NaN/negative geometry, unreadable image…) are skipped and listed in the dialog; the PDF is still produced. An invalid **redaction** box aborts instead, so nothing is left unredacted by accident.
- Worker jobs have an idle timeout, handle `onmessageerror` and un-cloneable payloads, and raise a typed `JobError`.
- The download dialog always offers a "Download didn't start? Click here" link, a native "Save as…" where the browser supports it, and a working "Download again".
- **Text editing is now glyph-exact.** Clicking selects one word; double-click the word; triple-click the line (within its column); drag an exact character range; Shift+click extends; Alt+drag selects a rectangle; handles nudge by one character. The captured text and character count are shown before editing, and only those glyphs are covered (tight, clipped away from neighbours). After export the text outside each edit is re-checked and failing edits are rolled back.
- `?debug=text` draws glyph quads, word boxes, line groups, the hit point and the winning glyph.

### Added
- **Find & Replace** (Ctrl/Cmd+F, Ctrl/Cmd+H): match case, whole word (Unicode-aware), exact phrase, regex (validity indicator, 4 s timeout), ignore accents; page / selected / document scope; next/previous with wrap-around; highlight all; match counter; Replace, Skip, Replace All (one undo step, summary with skipped pages), shrink-to-fit / allow overflow / skip, case-aware replace.
- Tests written but **not yet executed**: `export-robustness.test.ts`, `glyphMap.test.ts`, `matcher.test.ts`, `tests/e2e/{download,selection,findreplace}.spec.ts`.

### Known gaps
See `docs/KNOWN_LIMITATIONS.md` → "TASKS-02 additions" (notably KL-T2-GATES: no gate has passed; KL-EDIT-2: replaced text is covered, not removed, and the OCR layer is not updated).
