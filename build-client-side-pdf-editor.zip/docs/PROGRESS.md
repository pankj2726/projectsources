# PROGRESS

## Honest summary

The blueprint asks for gated stages, each ending with a local CI run, `PROGRESS.md` update, commit and preview deploy.
**None of that could be done here**: the environment offers file tools and `vite build` only (no shell, git, Playwright,
browser, Lighthouse, axe or Vercel). All ten stages were therefore written in a single pass, and the only gate that was
actually run at each point was **"TypeScript compiles"** (the file tool type-checks on every write) plus **`vite build`** at the end
(twice). *Every other gate below is UNVERIFIED.* This is logged as KL-ENV-1…5 rather than hidden.

## Measured numbers (the only ones I have)

| Metric | Value | Source |
| --- | --- | --- |
| `vite build` | succeeds, 110 modules, ~9 s | `build_project` |
| `dist/index.html` | 2,851.80 kB (959.17 kB gzip) | `build_project` output |
| Blueprint budget | initial JS ≤ 200 KB gzip | **exceeded ≈ 4.8×** (single-file build inlines pdf.js, its worker, pdf-lib twice, tesseract loader) |
| Typecheck | clean at every file write (tsconfig strict, noUnusedLocals) | tool feedback |
| Unit/integration tests | **written, never executed** (`src/tests/*.test.ts`, 5 files) | – |
| Lighthouse / axe / S1 / memory / 300-page scroll | **not measured** | – |

## Stage log

| Stage | Built | Gate | Result |
| --- | --- | --- | --- |
| 1 Foundation | Vite+React+TS strict+Tailwind (D1), `vercel.json` headers, `ci.yml`, Dependabot, `.prettierrc`, license-check + bundle-budget scripts, vitest, docs | blank app deployed; CI green; license audit | **Not verified**: no deploy, CI never ran, license script never run. ESLint & Playwright not installed (KL-ENV-4); no analytics (KL-ANALYTICS) |
| 2 Upload & viewer | magic bytes, typed errors, size warn/limit, password dialog, pdf.js worker, lazy per-page rendering with eviction, thumbnails, zoom/fit/jump/view-rotate | 300-page scroll, memory, encrypted prompt | **Not verified** (code complete) |
| 3 Model/commands/export | `DocData`, command stack, `coords.ts`, export skeleton, filename edit, runtime re-parse | round-trip of every fixture opens in a 2nd viewer | Tests written (`coords`, `commands`, `pipeline`), **not run**; only second *parser* (pdf.js) available, not second *viewer* |
| 4 Annotations | all tools, selection/move/resize/rotate/duplicate/z-order/eraser, properties panel, shortcuts | visual regression across 3 viewers | **Not verified**; no visual-regression harness |
| 5 Text edit & redaction | text-run extraction, cover-and-replace with sampled colours, font mapping + missing-glyph path, whiteout, rasterising redaction with GC + re-extraction proof | edited fixtures render elsewhere; redacted text not extractable | **Not verified** on real files |
| 6 Page management | thumbnail reorder/rotate/delete/duplicate/blank/insert/extract, merge, split, crop, resize, numbers/header/footer/Bates, watermark | page counts & order verified programmatically | Tests written (`pipeline.test.ts`), **not run** |
| 7 Forms & signing | field detection/fill/flatten, add 5 field kinds, signature dialog | forms persist in other viewers | Tests written, **not run** |
| 8 Convert/optimise/secure/OCR | PDF→image/text, image→PDF, compress, protect/unlock, metadata, OCR | compressed smaller; protected prompts in Adobe/Chrome; OCR selectable | Runtime re-parse built in; **not run**; only pdf.js used as 2nd reader |
| 9 Polish | chaining, autosave/recovery/clear, responsive layouts, dark mode, tour, i18n (en/es scaffold), 18 landing pages w/ FAQ JSON-LD, sitemap/robots, privacy/terms/about/contact | Lighthouse Perf ≥ 90 / A11y ≥ 95 / SEO ≥ 95 | **Not measured**; Perf will almost certainly fail until code-split |
| 10 Hardening | `ErrorBoundary`, security headers, Section 12 audit (see final report) | S1–S6 verified | **Not met** – see audit |

## TASKS-02 (download fix · precise text selection · find & replace)

Same constraints as before: file tools + `vite build` only. **No Playwright, no browsers, no second viewer, no deploy – so none of the three gates has passed.** What was measured:

| Item | Result |
| --- | --- |
| `vite build` (final) | succeeds, 122 modules, `dist/index.html` 2,895.59 kB (974.32 kB gzip) – still ≈ 4.9× the 200 KB budget (KL-LH) |
| Type-check | clean across `src/` **including all test files** (the file tool type-checks on every write) |
| vitest / Playwright | **not executed.** Written: `export-robustness.test.ts`, `glyphMap.test.ts`, `matcher.test.ts` (unit/integration); `tests/e2e/{download,selection,findreplace}.spec.ts` |
| Incident | `build_project` timed out 4× in a row mid-task. Cause: several parallel `edit_file` calls on one file had silently overwritten each other (missing import / usage / functions), leaving a broken module graph. Fixed by re-applying edits one per file; files touched earlier were re-verified by grep (DECISIONS D18). |

| Task | Built | Gate status |
| --- | --- | --- |
| 1 Download | root cause from source (D14); per-object validation + warnings returned and shown; redaction never skipped silently; typed `JobError` with idle timeout / `onmessageerror` / clone-failure handling; zero-length-result guard; deduplicated transfer list; 60 s URL revoke; always-visible fallback link; Save-as where supported; retry-safe dialog | **Not verified**: E2E for 9 edit types × 3 browsers, 4 viewers, double download, forced-failure test are all written (`download.spec.ts`, `export-robustness.test.ts`) but unrun |
| 2 Selection | glyph map, explicit hit-test, word/line/range/rect/extend/handles, captured-string label + `data-testid`, `?debug=text` overlay, guards 1–3, tight covers, post-edit verify + auto-rollback, dead-glyph exclusion | **Not verified**; only synthetic layouts tested. **Not done:** real glyph removal from content streams, OCR-layer update (KL-EDIT-2); real-PDF fixtures (KL-T2-FIXTURES) |
| 3 Find & Replace | matcher with all options, search index with offset map, hyphen join, ligatures, NFC, column-safe phrases, regex worker + timeout, scoped search with progress/cancel, highlights, counter, Replace / Skip / Replace All as ONE command, shrink/overflow/skip, case-aware, summary + skipped list, Ctrl/Cmd+F/H | **Not verified**; §3.5 matrix is unit-tested (unrun); 300-page and pixel/undo checks are e2e code only |

## TASKS-02 revision: line-segment edit unit (this iteration)

Same constraints (file tools + `vite build` only), so **no gate passed**. Measured: `vite build` succeeds, 124 modules, `dist/index.html` 2,922.19 kB (983.42 kB gzip); type-check clean across `src/` including every test. **Not executed:** all vitest files and all Playwright specs.

| Spec item | Built | Not built / unverified |
| --- | --- | --- |
| §2.2–2.3 hierarchy + boundaries | units, hard/soft boundaries with reasons, uniform-justified rule, super/subscript, table rules from the operator list, tabular alignment, paragraphs | layers/z-order boundary (KL-LAYERS); rules never tested on a real PDF (KL-RULES) |
| §2.4 interaction | pointerdown-only hit-test, one click → inline editor, caret at click, I-beam via one static path, no hover UI (setting, off), tap on touch, Enter/Esc/blur/click-elsewhere, one undo step | iOS keyboard (KL-TOUCH); latency unmeasured (KL-SPEED) |
| §2.5 minimal diff | diffRange, only-changed-words, trailing words shifted within the unit, shrink/overflow/skip, no-change = nothing, real text as one run | **true glyph removal and OCR-layer update NOT implemented** (KL-EDIT-2); shifted words use a standard font (KL-EDIT-6) |
| §2.6 guards | guard 1, clipped/blocked covers, post-edit verify + rollback (unchanged) | rollback path not exercised end-to-end |
| §2.7 debug overlay | quads, words, colour-coded units, boundary decisions with reasons, click point, `active-unit-text`/`active-unit-id` | – |
| §2.8 tests | `glyphMap.test.ts`, `unitEdit.test.ts`, `edittext.spec.ts`, `layout.pdf` + truth generator | real-PDF fixtures, OCR fixture, pixel-diff (KL-T2-FIXTURES) |
| Task 3 | Replace moved onto the new commit, per-unit grouping | cross-unit matches skipped (KL-FR-3) |

## TASKS-02 §2.4A/B: text properties sidebar restored (this iteration)

Same constraints (file tools + `vite build` only), so **no gate passed**. Measured: `vite build` succeeds, 131 modules, `dist/index.html` 2,955.49 kB (994.56 kB gzip); type-check clean across `src/` including every test file. **Not executed:** all vitest files and all Playwright specs.

| Item | Built | Not built / unverified |
| --- | --- | --- |
| Root cause | confirmed from code (D28): panel keyed to object selection; one-click flow never selects | not reproduced in a browser |
| Panel lifecycle | session store; opens with the editor in the same tick; docked right / bottom sheet; defaults when idle; never hover / selection driven | < 100 ms unmeasured |
| Focus rule | pointer/mouse-down cancel, blur-into-sidebar ignored, 600 ms guard, focus + selection restored | Safari / Firefox behaviour untested |
| Controls | Font (family combobox, size + stepper, original name + substituted/estimated badges, match original), Style (B I U S x² x₂), Color (picker, hex, eyedropper, recent, background, opacity), Paragraph (align, line / character / word spacing, case), Box (offset X/Y, rotation, front/back, lock, duplicate, delete), Actions (undo, redo, reset), collapsible + remembered | W/H read-only; align/line spacing only for paragraphs (KL-SIDEBAR-BOX/-ALIGN) |
| Range-aware + Mixed | spans model, per-char mixed detection, reconcile on typing | caret may drift in overlay preview (KL-SIDEBAR-RANGE) |
| Export | runs / underline / strike / sub-sup / spacing / opacity / justify via one shared layout | original colour space not preserved (KL-COLORSPACE); non-WinAnsi text rastered base-style only |
| Guard | `uiRegistry.ts` + `uiChecklist.test.ts` (static) + `ui-checklist.spec.ts` | source-text based (KL-REGGUARD); e2e half unrun |
| Bug caught in review | spans-only restyle redrew the whole tail of the line; fixed + asserted | – |

## TASKS-02 §2.4C: active text box restored (this iteration)

Same constraints (file tools + `vite build` only), so **no gate passed**. Measured: `vite build` succeeds, 133 modules, `dist/index.html` 2,966.14 kB (998.45 kB gzip); type-check clean across `src/` including every test file. **Not executed:** all vitest files and all Playwright specs. Tasks 1 and 3 untouched.

| Item | Built | Not built / unverified |
| --- | --- | --- |
| Root cause | confirmed from code (D35): the only frame with handles is gated on `tool === "select"`; the one-click flow never selects | not reproduced in a browser |
| Frame | own component, mounted with the edit session, page-space SVG, screen-constant 1.5 px line + white halo, always above everything on the page, unit-band bounds that grow / shrink with typing, oriented about the export pivot | bounds ±2 px and < 100 ms unmeasured; Safari hit-testing / focus unverified (KL-FRAME-SAFARI) |
| Pointer rules + focus rule | border + handles capture, interior passes through, pointer capture (no window listeners), `onBlur` ignores `[data-text-frame]`, focus returns to the editor | – |
| Handles | 8 resize (width / shrink-to-fit / reflow, Shift + corner = font scale, n / s = font or line spacing), rotate (Shift = 15°), move (border + grip), arrow nudge on the focused border | n / s semantics are my choice (KL-FRAME-NS); touch drag untested (KL-FRAME-TOUCH) |
| Undo | a drag = one step, a plain click = none, resize from the start snapshot | – |
| Sidebar sync | one store; Box width (new, editable), Offset X / Y, Rotation | height read-only |
| Export | box width limit, paragraph reflow width, move, rotate reach the object; chrome never exported | rotation preview caret in Safari (KL-FRAME-ROT) |
| Guard | `TEXT_FRAME_CONTROLS` in the registry, static test, e2e checklist | source-text based |
| Fixtures | `frame-bg.pdf` (light / dark / striped), `para.pdf` | scripts not run; no visual baselines |

## Regression fix: the sidebar's "Edited text" panel (this iteration)

The user showed the panel that used to appear when clicking text to edit (Text box, `Original:` + Reset, Font/Size, B/I, colour, cover-and-replace note). Same constraints as before (file tools + `vite build` only), so **nothing was run**. Measured: `vite build` succeeds, 133 modules, `dist/index.html` 2,967.66 kB (998.81 kB gzip); type-check clean across `src/` including every test.

| Item | Built | Not built / unverified |
| --- | --- | --- |
| Root cause | confirmed from code (D42): that panel only rendered for a SELECTED object, and the one-click editor never selects; the tablist was inside `editing && desktop`, so the tabs vanished too | not reproduced in a browser |
| Text group | textarea with the whole line segment, `Original:` + Reset, cover-and-replace note with the sampled colour | two-way sync caveats (KL-SIDEBAR-TEXT-SYNC) |
| Tabs | `Properties` / `Forms` always visible, sticky, with the text panel inside Properties | – |
| Sync | one string in the session; the page editor's value and the frame width read from it | caret jumps to the end when typing in the sidebar |
| Tests | `uiChecklist.test.ts` (source-text guard + Text group), `textsidebar.spec.ts` (two-way, Reset, Enter commits, tabs) | both unrun |

## Full audit + undo/redo fix (this iteration)

Same constraints (file tools + `vite build` only), so **nothing was executed**. Measured: `vite build` succeeds, 141 modules, `dist/index.html` 2,999.63 kB (1,006.60 kB gzip); type-check clean across `src/` **including every test file**; a structural sweep for duplicated/orphaned JSX blocks across all `.tsx` files found none.

| Audit area | Result |
| --- | --- |
| Command stack (`commands.ts`, `docState.ts`, `commit()`, `endGesture`) | **correct** – read line by line; `src/tests/commands.test.ts` covers do/undo/redo, no-ops and serialization |
| Undo/redo entry points (toolbar, mobile top bar, Ctrl+Z / Ctrl+Shift+Z / Ctrl+Y, page ops, text edits, Replace All, baked tools) | all push history correctly |
| **Undo/redo bug** | **FOUND AND FIXED** – focus stayed in a text field after committing, so Ctrl+Z was treated as typing and the browser undid text inside the closed box (D44) |
| Mobile keyboard toolbar undo/redo | **FIXED** – targeted the format history instead of the document (D45.1) |
| PropertiesPanel "live" edits | **FIXED** – history was only written on blur, which often never fired (D45.2) |
| Pinch viewport anchoring | **FIXED** – broken restore expression could jump the view when the keyboard opened (D45.3) |
| Format lock (Task D) | **FIXED** – Ctrl/Cmd+B/I/U bypassed it |
| Mobile toolbar | **FIXED** – Edit text was rendered twice |
| PWA manifest | linked to the real `public/manifest.webmanifest` (the data-URI form is not reliably accepted) |
| Tests | `tests/e2e/edittext.spec.ts` gained 3 audit regression tests (focus-after-commit, toolbar + Ctrl+Z, lock vs Ctrl+B) – **none run** |

## What to do next (in order)

1. `npm i && npx tsc --noEmit && npx vitest run && node scripts/license-check.mjs` – fix whatever the unexecuted tests reveal.
2. `node scripts/make-fixtures.mjs`, then open each fixture in the editor, export, and open the result in Chrome, Firefox, Safari/Preview and Adobe Reader.
3. Replace the placeholders listed in KL-OPS.
4. Move off the single-file build (hashed chunks, lazy tesseract/pdf.js) – required for S1/NF1 and to remove CSP `unsafe-inline`.
5. Run Playwright (`tests/e2e`) and Lighthouse/axe against the preview; record numbers here.
