# TRACEABILITY — Feature registry (Section 7), final state

**Status vocabulary.** This environment had file tools and `vite build` only – no shell, git, CI, browser, Lighthouse, axe or deploy.
Blueprint rule 3 defines DONE as "has a *passing* test". No test has been *executed*, so **no feature is marked DONE.**

- `IMPLEMENTED` – module exists, is wired into the UI, type-checks and the production build succeeds. Behaviour not yet proven by an executed test.
- `LIMITED` – implemented, with a disclosed gap (ID → `KNOWN_LIMITATIONS.md`).
- Test column: `written` = file exists but has **never been run**; `runtime` = the app itself re-checks the result at use time with `src/lib/pdf/verify.ts` (pdf.js, a second parser); `none` = no automated test.

All paths are under `src/` unless noted. Tests: `src/tests/*.test.ts` (vitest, written), `tests/e2e/smoke.spec.ts` (Playwright, written, Playwright not installed).

| ID | Feature | Stage | Module(s) | Test / verification | Status |
| --- | --- | --- | --- | --- | --- |
| F01 | Drag-drop / picker upload with validation | 2 | `lib/pdf/load.ts` (magic bytes, size warn/limit, typed errors), `lib/pdf/openFile.ts`, `components/UploadZone.tsx` | e2e `not-a-PDF and corrupt files show typed errors` (written) | IMPLEMENTED |
| F02 | Password-protected PDF open | 2 | `lib/pdf/load.ts` (`PasswordRequired`/`WrongPassword`), `lib/pdf/session.ts` (`openBytes`), `components/ui.tsx` (`PasswordDialog`) | e2e `encrypted file prompts…` (written); `pipeline.test.ts › protect / unlock` (written) | IMPLEMENTED |
| F03 | Virtualized viewer, zoom, fit, nav, thumbnails, view rotation | 2 | `components/viewer/{Viewer,PageView}.tsx`, `components/sidebar/Thumbnails.tsx`, `lib/pdf/render.ts` | none (300-page smoothness/memory unmeasured – KL-PERF-UNVERIFIED) | IMPLEMENTED |
| F04 | Undo/redo for all edits | 3 | `lib/model/commands.ts`, `lib/model/docState.ts` | `commands.test.ts` (written) | IMPLEMENTED |
| F05 | Download with custom filename | 3 | `lib/pdf/export.ts`, `lib/pdf/session.ts`, `components/dialogs/ExportDialog.tsx`, `lib/pdf/range.ts` (`sanitizeFilename`) | `pipeline.test.ts › export pipeline` (written); runtime re-parse on every download | IMPLEMENTED |
| F06 | Text box | 4 | `components/viewer/ObjectLayer.tsx`, `lib/model/objects.ts`, `lib/pdf/export.ts` | `pipeline.test.ts › draws every object type` (written) | IMPLEMENTED |
| F07 | Highlight / underline / strikethrough | 4 | same | same | LIMITED (KL-ANN: flattened, not `/Annot`) |
| F08 | Freehand draw | 4 | same | same | IMPLEMENTED |
| F09 | Shapes (rect, ellipse, line, arrow) | 4 | same | same | IMPLEMENTED |
| F10 | Insert image | 4 | `components/toolbar/Toolbar.tsx`, `lib/pdf/images.ts`, `export.ts` | none | IMPLEMENTED |
| F11 | Sticky note | 4 | `ObjectLayer.tsx`, `export.ts` (`/Text` annotation + flattened square) | `pipeline.test.ts` (note in "every object type") | IMPLEMENTED |
| F12 | Select/move/resize/rotate/duplicate/delete/z-order, properties panel, shortcuts, eraser | 4 | `ObjectLayer.tsx`, `components/sidebar/PropertiesPanel.tsx`, `pages/Editor.tsx` | `commands.test.ts` (z-order, duplicate) (written); pointer interactions untested | IMPLEMENTED |
| F13 | Edit existing text (cover-and-replace) | 5 | `components/viewer/TextEditLayer.tsx`, `lib/pdf/render.ts` (`extractTextRuns`, `sampleRunColors`), `lib/fonts/fontMap.ts`, `export.ts` | `fontMap.test.ts` (written) | LIMITED (KL-EDIT, KL-FONT) |
| F14 | Whiteout | 5 | `ObjectLayer.tsx`, `export.ts` | `pipeline.test.ts` (whiteout drawn) | IMPLEMENTED |
| F15 | True redaction | 5 | `lib/pdf/session.ts` (`prepareExport` raster + keep-runs), `lib/pdf/export.ts` (`applyRedaction`), `lib/pdf/gc.ts`, `lib/pdf/verify.ts` | runtime proof (re-extract text, blocks download on failure); `pipeline.test.ts › garbage collection`; **no automated redaction test** (needs canvas) | LIMITED (KL-REDACT, KL-REDACT-2) |
| F16 | Reorder / delete / duplicate / rotate pages | 6 | `components/sidebar/Thumbnails.tsx`, `commands.ts`, `export.ts` | `commands.test.ts`, `pipeline.test.ts` (order via page widths) (written) | IMPLEMENTED |
| F17 | Insert blank page / pages from another PDF | 6 | `Thumbnails.tsx`, `commands.ts`, `export.ts` | `pipeline.test.ts › inserts pages from another PDF` (written) | IMPLEMENTED |
| F18 | Merge | 6 | `lib/pdf/merge.ts`, `components/tools/ToolPanels.tsx` | `pipeline.test.ts › merge / split` (written) | LIMITED (KL-FORM/KL-NOLINK: forms & outlines of inputs not carried over) |
| F19 | Split (range / every N / selection) | 6 | `lib/pdf/split.ts`, `lib/pdf/range.ts`, `ToolPanels.tsx` | `range.test.ts`, `pipeline.test.ts` (written) | IMPLEMENTED |
| F20 | Crop / resize pages | 6 | `lib/pdf/pageTools.ts` | `pipeline.test.ts › page tools` (crop with rotation) (written); resize untested | IMPLEMENTED |
| F21 | Page numbers, header/footer, Bates | 6 | `pageTools.ts` (`stampPages`) | `pipeline.test.ts › page tools` (written) | IMPLEMENTED |
| F22 | Watermark (text/image, opacity, rotation, tiling) | 6 | `pageTools.ts` (`addWatermark`) | `pipeline.test.ts › page tools` (text+tile) (written) | IMPLEMENTED |
| F23 | Fill existing form fields | 7 | `lib/pdf/forms.ts`, `components/sidebar/FormsPanel.tsx` | `pipeline.test.ts › adds real form fields` (fill → re-read) (written) | LIMITED (KL-FORM: side panel, not inline) |
| F24 | Add form fields (text, checkbox, radio, dropdown, date) | 7 | `export.ts`, `ObjectLayer.tsx`, `PropertiesPanel.tsx` | `pipeline.test.ts` (written) | LIMITED (KL-FORM: date = text field) |
| F25 | Flatten forms | 7 | `forms.ts` | `pipeline.test.ts` (flatten → 0 fields) (written) | IMPLEMENTED |
| F26 | Visual signature (draw/type/upload) | 7 | `components/dialogs/SignatureDialog.tsx`, `lib/pdf/images.ts` | none | IMPLEMENTED (visual by design; disclosed in dialog, properties panel, export dialog, terms) |
| F27 | PDF to image (DPI, zip) | 8 | `ToolPanels.tsx` (`ToImagePanel`), `lib/pdf/render.ts` | none | IMPLEMENTED |
| F28 | Image to PDF (size, margin, orientation) | 8 | `lib/pdf/imagesToPdf.ts`, `ToolPanels.tsx` | `pipeline.test.ts › image → PDF` (PNG path) (written) | IMPLEMENTED |
| F29 | PDF to text | 8 | `ToolPanels.tsx` (`ToTextPanel`), `render.ts` (`extractPlainText`) | none | IMPLEMENTED |
| F30 | Compress with presets, before/after size | 8 | `lib/pdf/compress.ts`, `ToolPanels.tsx` | none (needs OffscreenCanvas); size delta shown in UI | LIMITED (KL-COMPRESS: JPEG only) |
| F31 | Protect (password / permissions) | 8 | `lib/pdf/protect.ts`, `ToolPanels.tsx` | `pipeline.test.ts › protect / unlock` (written); runtime re-parse (prompts + opens with password) | LIMITED (KL-PROTECT) |
| F32 | Unlock (known password) | 8 | `protect.ts`, `ToolPanels.tsx` | `pipeline.test.ts` (written); runtime re-parse | IMPLEMENTED |
| F33 | Metadata editor | 8 | `pageTools.ts` (`setMetadata`), `ToolPanels.tsx` | `pipeline.test.ts › page tools` (title/author/clear) (written) | IMPLEMENTED |
| F34 | OCR to searchable PDF (progress, cancel, on-demand languages) | 8 | `lib/pdf/imagesToPdf.ts` (`addTextLayer`), `ToolPanels.tsx` (`OcrPanel`, tesseract.js) | runtime: re-extracts text from output and reports count; no automated test | LIMITED (KL-OCR, KL-CDN) |
| F35 | Tool chaining without re-upload | 9 | `lib/pdf/session.ts` (`commitBytes` → `replaceBase`), `ToolPage.tsx` ("Run again", "Chain another tool", "Continue in editor") | none | IMPLEMENTED |
| F36 | Autosave / recovery / clear data | 9 | `lib/pdf/persist.ts`, `pages/Home.tsx`, `pages/Editor.tsx`, `Toolbar.tsx` | e2e `Clear my data wipes IndexedDB` (written) | LIMITED (KL-HISTORY) |
| F37 | Responsive + touch | 9 | Tailwind breakpoints, drawer sidebars, Pointer Events (`touch-action`) | none; no device testing (KL-ENV-5) | IMPLEMENTED |
| F38 | Dark mode | 9 | `lib/theme.ts`, `index.css`, `index.html` (no-flash script) | none | IMPLEMENTED |
| F39 | Per-tool SEO landing pages | 9 | `lib/tools.ts` (unique copy/FAQ ×18), `pages/ToolPage.tsx`, `lib/seo.ts` (title, description, canonical, FAQ/WebApplication/Breadcrumb JSON-LD), `public/sitemap.xml`, `public/robots.txt` | none | LIMITED (KL-SEO, KL-OPS) |
| F40 | Privacy / terms / about / contact pages | 9 | `pages/StaticPages.tsx`, `lib/config.ts` | none | LIMITED (KL-OPS: contact address is a placeholder) |
| F41 | Find: scope (page / selected / document), next/prev with wrap-around, highlight all, match counter, progress + cancel, Ctrl/Cmd+F | TASKS-02 T3 | `lib/text/find.ts`, `lib/text/searchIndex.ts`, `lib/text/matcher.ts`, `components/dialogs/FindPanel.tsx`, `components/viewer/FindHighlights.tsx` | `matcher.test.ts` (search index block) (written, not run); `tests/e2e/findreplace.spec.ts` (written, not run) | IMPLEMENTED (unverified) |
| F42 | Replace / Replace All (single undoable command, skipped-list summary, shrink/overflow/skip, case-aware, Ctrl/Cmd+H) | TASKS-02 T3 | `lib/text/find.ts` (`planReplace`, `applyReplace`), `lib/text/unitEdit.ts` (the guarded minimal-diff commit shared with Task 2) | `matcher.test.ts` §3.5 matrix + X→X property (written, not run); `findreplace.spec.ts` (written, not run) | LIMITED (KL-EDIT-2, KL-FR-1, KL-FR-2) |
| F43 | Match options: match case, whole word (Unicode-aware, possessive rule), exact phrase / word order, regex (+ validity + timeout), ignore diacritics | TASKS-02 T3 | `lib/text/matcher.ts`, `lib/text/matchTexts.ts`, `lib/workers/search.worker.ts` | `src/tests/matcher.test.ts` (written, not run) | IMPLEMENTED (unverified) |

## Non-functional registry

| ID | Item | Where | Status |
| --- | --- | --- | --- |
| NF1 | Performance | virtualised viewer, 16 MP canvas cap, worker offload; bundle **2.85 MB / 959 KB gzip** (`scripts/bundle-budget.mjs`) | **NOT MET** (KL-LH, KL-PERF-UNVERIFIED) |
| NF2 | Memory | canvas eviction outside ±1400 px, per-job workers terminated on completion/cancel | unmeasured |
| NF3 | Accessibility | ARIA labels/roles, focus trap in dialogs, skip link, visible focus, reduced motion, keyboard path for core flow | unmeasured (no axe) – KL-A11Y |
| NF4 | Security | `vercel.json` headers (CSP, nosniff, referrer, permissions, frame-ancestors), filename sanitising, `isEvalSupported:false`, PDF JS never run | partly (CSP needs `unsafe-inline`, KL-CSP) |
| NF5 | Privacy | no uploads, no cookies, no analytics, autosave opt-out + clear | implemented; network log not inspected (KL-ENV-1) |
| NF6 | SEO | see F39 | LIMITED |
| NF7 | Browser support | pdf.js legacy build, OffscreenCanvas needed for compress/image→PDF fallback | untested on Firefox/WebKit |
| NF8 | Error handling | typed `PdfError`s, `ErrorBoundary`, cancel on every job, OOM mapping (`friendlyError`) | implemented; untested |
| NF9 | License compliance | `scripts/license-check.mjs` in CI; deps: pdfjs-dist (Apache-2.0), @cantoo/pdf-lib (MIT), jszip (MIT OR GPL-3.0 → MIT elected), tesseract.js (Apache-2.0), zustand (MIT), vitest (MIT) | script written, **not run** |
| NF10 | Observability | console-only | NOT MET (KL-ANALYTICS) |

## TASKS-02 fixes → regression tests (all written, **none executed**)

| Fix | Affects | Regression test(s) | Status |
| --- | --- | --- | --- |
| Pages restored under their refs after `removePage` (root cause D14) | F05, F16, F17 | `export-robustness.test.ts` (every edit type; 60-page tree → 1 page); `pipeline.test.ts` round-trip; `download.spec.ts` | fixed in code, unverified |
| Per-object validation + warnings; invalid redaction aborts | F05, F15 | `export-robustness.test.ts › forced failure`, `› invalid redaction box`; `download.spec.ts › forced failure` | unverified |
| `JobError`, idle timeout, `onmessageerror`, clone failure, zero-length guard | F05 | none automated (needs a worker harness) | unverified |
| Fallback link, Save-as, 60 s revoke, retry-safe dialog | F05 | `download.spec.ts › twice in a row`, `› fallback link` | unverified |
| Glyph-level selection, tight covers, guards 1–3 | F13 | **superseded** by the line-segment unit (see the revision below): `glyphMap.test.ts` and `unitEdit.test.ts` were rewritten | unverified; synthetic layouts only |
| Post-edit verification + auto-rollback | F13 | `lib/text/verifyEdit.ts` (unchanged); covered in `unitEdit.test.ts` (invariant loop) and `edittext.spec.ts` (no rollback on a clean edit) | rollback path not exercised end-to-end |
| Debug overlay / captured-text test id | F13 | `selection.spec.ts` | **superseded** – see the revision below (that spec and the word-level selection model were removed) |

## TASKS-02 revision: line-segment edit unit, one-click inline editor, minimal-diff commit (all tests written, **none executed**)

| Requirement | Feature | Modules | Regression test(s) | Status |
| --- | --- | --- | --- | --- |
| §2.2/2.3 hierarchy Glyph→Word→**Line segment (unit)**→Paragraph; hard/soft boundaries with reasons (gap, uniform-justified, size change, baseline, rotation, column, table rule, tabular alignment) | F13 | `lib/text/glyphMap.ts`, `lib/pdf/render.ts` (`extractRules`) | `src/tests/glyphMap.test.ts` (fragmentation vs bleed, justified, style, super/subscript, rules, tabular, columns, paragraphs) | LIMITED (KL-LAYERS, KL-RULES, KL-GLYPH) |
| §2.4 one click opens the inline editor; **no hover UI**; I-beam via one static path; touch = tap; settings off by default | F13 | `components/viewer/TextEditLayer.tsx`, `lib/model/ui.ts`, `components/sidebar/EditTextHelp.tsx` | `tests/e2e/edittext.spec.ts` (one click focused, no overlay added on mousemove, caret within a glyph, tap) | unverified (KL-TOUCH) |
| §2.5 minimal-diff commit; unchanged words untouched; only trailing words of the same unit shift; shrink/overflow/skip; no-change = nothing; real text as one run | F13 | `lib/text/unitEdit.ts`, `lib/model/commands.ts` (`replaceObjects`), `lib/pdf/export.ts` | `src/tests/unitEdit.test.ts` (diffRange table, invariant over 9 edit kinds, append/insert/delete, re-edit/revert, overflow) | LIMITED (KL-EDIT-2, KL-EDIT-6, KL-EDIT-7) |
| §2.6 guards (original == unit glyphs; cover only unit glyphs, clipped/blocked) + post-edit verify with rollback | F13 | `lib/text/unitEdit.ts`, `lib/text/glyphMap.ts` (`computeCovers`), `lib/pdf/editVerify.ts`, `components/dialogs/ExportDialog.tsx` | `unitEdit.test.ts` (clip, block, guard 1, rotated), `glyphMap.test.ts`; rollback via `src/tests/glyphMap` verify cases in `verifyEdit` | unverified end-to-end |
| §2.7 debug overlay: quads, words, colour-coded units, hard/soft decisions with reasons, click point, active unit (`data-testid`) | F13 | `TextEditLayer.tsx` | `edittext.spec.ts` (reads `active-unit-text`) | unverified |
| §2.4 optional paragraph (reflow) mode | F13 | `glyphMap.ts` (`paragraphs`), `unitEdit.ts` (`planParagraphEdit`) | `unitEdit.test.ts › paragraph`, `glyphMap.test.ts › paragraphs` | LIMITED (KL-PARA) |
| Task 3 on the new commit (per-unit grouping, Replace All = one command) | F42 | `lib/text/find.ts` | `matcher.test.ts` (matcher/index); PDF-level in `findreplace.spec.ts` | LIMITED (KL-FR-3) |
| Fixtures with ground truth | F13 | `scripts/make-fixtures.mjs` → `layout.pdf`, `layout.truth.json` | `edittext.spec.ts › unit grouping` | not generated yet |

## F44 Text properties sidebar (RESTORED) and the regression guard (all tests written, **none executed**)

| Requirement | Feature | Modules | Regression test(s) | Status |
| --- | --- | --- | --- | --- |
| §2.4A opens with the editor on ONE click, docked right (desktop) / bottom sheet (mobile); stays open for the whole edit; never hover-driven, never selection-driven | **F44** | `lib/text/editSession.ts` (session store), `components/sidebar/TextPropertiesPanel.tsx`, `pages/Editor.tsx` (`editing && desktop` / `editing && !desktop`), `lib/useMedia.ts` | `tests/e2e/textsidebar.spec.ts` (< 100 ms with no hover; mobile bottom sheet; one instance); `src/tests/uiChecklist.test.ts › not tied to hover or selection` | unverified |
| populated from the clicked unit (font name, size, colour), not defaults; "substituted" / "estimated" hints | F44 | `lib/pdf/render.ts` (`fontLabel`, `substituted`), `lib/pdf/textColors.ts`, `lib/text/pageText.ts`, `TextEditLayer.tsx` (`open`) | `textsidebar.spec.ts` (sentence 11 pt Helvetica, heading 18 pt, gray, CMYK) | LIMITED (KL-COLORSPACE, KL-COLOR-DETECT, KL-FONTS) |
| focus rule: sidebar use never blurs / commits / closes the editor; "outside" = outside editor AND sidebar; focus returns to the editor | F44 | `TextPropertiesPanel.tsx` (`keepFocus`, `markSidebarPointer`, `focusEditor`), `TextEditLayer.tsx` (`onBlur`, `sidebarRecentlyUsed`, `focusSelf`) | `textsidebar.spec.ts › interacting with the sidebar never closes…`, `› click outside…`; `uiChecklist.test.ts › focus rule` | unverified (Safari/WebKit focus-on-click is the risk) |
| Font / Style / Color / Paragraph / Box / Actions controls | F44 | `TextPropertiesPanel.tsx`, `lib/uiRegistry.ts` (`TEXT_SIDEBAR_CONTROLS`) | `uiChecklist.test.ts › every required control`; `ui-checklist.spec.ts › offers every control` | LIMITED (KL-SIDEBAR-BOX, -ALIGN, KL-FONTS) |
| range-aware formatting + "Mixed"; live preview; one undo step per change (coalesced) | F44 | `lib/text/styleModel.ts`, `lib/text/editSession.ts`, `TextRuns.tsx` (preview), `lib/text/unitEdit.ts` (style = change) | `src/tests/styleModel.test.ts`, `src/tests/unitEdit.style.test.ts`, `textsidebar.spec.ts › range-aware` | LIMITED (KL-SIDEBAR-RANGE, KL-SIDEBAR-UNDO) |
| formatting is exported (runs, underline, strike, sub/superscript, char/word spacing, opacity, justify) | F44 | `lib/pdf/drawText.ts`, `lib/pdf/export.ts` | `src/tests/textstyle-export.test.ts`; `textsidebar.spec.ts` (bold-italic face present in the download) | LIMITED (KL-SIDEBAR-RASTER, KL-COLORSPACE) |
| text tools with nothing being edited show the defaults for the NEXT text box (and they are used) | F44 | `PropertiesPanel.tsx`, `lib/model/objects.ts` (`textDefaults`), `editSession.ts` (`setDefaults`) | `textsidebar.spec.ts › defaults for the NEXT text box`; `styleModel.test.ts › defaults` | unverified |
| §2.4B REGRESSION GUARD: previously working panels / toolbar / shortcuts must not disappear | F44 | `lib/uiRegistry.ts`, `lib/toolbarDef.ts` | `src/tests/uiChecklist.test.ts` (static, in vitest), `tests/e2e/ui-checklist.spec.ts` (running app) | unverified; the static half is source-text based (KL-REGGUARD) |

## F45 Active text box with handles (RESTORED) (all tests written, **none executed**)

| Requirement | Feature | Modules | Regression test(s) | Status |
| --- | --- | --- | --- | --- |
| §2.4C one click shows the frame within 100 ms (no hover first); bounds = the active unit's bounds (±2 px); oriented to rotated text | **F45** | `components/viewer/TextFrame.tsx`, `components/viewer/TextEditLayer.tsx`, `lib/text/frameGeometry.ts` | `tests/e2e/textframe.spec.ts › ONE click…`; `src/tests/textframe.test.ts › frame box` | unverified |
| never on hover, never on a non-active unit; fully removed after commit / cancel; no residue, no listeners; nothing in the exported PDF | F45 | `TextFrame.tsx` (pointer capture only), `TextEditLayer.tsx` (mounted only for the session) | `textframe.spec.ts › never on hover…`, `› …downloaded PDF`; `src/tests/uiChecklist.test.ts › F45` | unverified |
| aligned through zoom, scroll, page rotation, view rotation, CropBox offset; grows and shrinks as typed | F45 | `frameGeometry.ts` (`frameBox`, `pivotOf`), `TextEditLayer.tsx` | `textframe.spec.ts › stays aligned…` (rotated.pdf, cropbox.pdf) | unverified |
| 8 resize handles: edges = width (reflow in paragraph mode, shrink-to-fit in line mode); Shift + corner scales the font | F45 | `frameGeometry.ts` (`resizeBy`), `editSession.ts` (`applyFrame`), `unitEdit.ts` (box width limit / reflow) | `textframe.test.ts › resizeBy…`, `› a line's box width…`, `› a paragraph's box width…`; `textframe.spec.ts › handles` | LIMITED (KL-FRAME-NS, KL-FRAME-WIDTH) |
| rotate handle (Shift = 15° steps); move by border or grip; arrow keys nudge 1 pt / 10 pt | F45 | `frameGeometry.ts` (`rotateTo`), `TextFrame.tsx`, `TextEditLayer.tsx` (`onFrameNudge`) | `textframe.test.ts › angles`; `textframe.spec.ts › rotate…`, `› move…`, `› arrow keys…` | LIMITED (KL-FRAME-NUDGE, KL-FRAME-ROT) |
| correct resize / rotate / move cursors | F45 | `frameGeometry.ts` (`cursorFor`), `TextFrame.tsx` | `textframe.test.ts › handles` | unverified (custom rotate cursor is a data-URI) |
| every change = ONE undo command (a drag is one step; clicks leave none) | F45 | `editSession.ts` (`beginGesture` / `endGesture`) | `textframe.test.ts › frame gestures in the edit session`; `textframe.spec.ts › handles` | unverified |
| pointer rules: border + handles capture, interior passes clicks to the editor; focus rule: frame / handles / sidebar never blur or commit | F45 | `TextFrame.tsx`, `TextEditLayer.tsx` (`onBlur`, `go`) | `uiChecklist.test.ts › F45`; `textframe.spec.ts › clicking the frame…` | unverified (WebKit focus behaviour is the risk) |
| sidebar Box fields ⇄ frame stay in sync both ways | F45 / F44 | `editSession.ts` (one store), `TextPropertiesPanel.tsx` (Box width, Offset X/Y, Rotation) | `textframe.spec.ts › the sidebar's Box fields…` | unverified |
| frame look: 1.5 px accent line + white halo, screen-constant, above page / covers / annotations | F45 | `frameGeometry.ts` constants, `TextFrame.tsx` | `textframe.spec.ts › visible on light, dark and image backgrounds` (pixel check); `VISUAL=1` screenshots | baselines not created (KL-FRAME-GATES) |
| committed result: width limit, move, rotate reach the exported text | F45 | `unitEdit.ts`, `drawText.ts`, `ObjectLayer.tsx` | `textframe.test.ts`, `textframe.spec.ts › …downloaded PDF` | unverified |
| §2.4B guard: the frame parts are in the UI registry | F45 | `lib/uiRegistry.ts` (`TEXT_FRAME_CONTROLS`) | `uiChecklist.test.ts`, `tests/e2e/ui-checklist.spec.ts` | unverified |

## Regression: the sidebar's Text panel restored (the panel from the user's screenshot) (test written, **not executed**)

| Requirement | Feature | Modules | Regression test(s) | Status |
| --- | --- | --- | --- | --- |
| Root cause: the "Edited text" panel (Text box, `Original: …` + Reset, Font/Size, B/I, colour, cover note) only renders for a **selected** object; the one-click editor never selects | F44 / F13 | `components/sidebar/PropertiesPanel.tsx` | `src/tests/uiChecklist.test.ts › the Text group … is restored` | confirmed from code (KL-SIDEBAR-TEXT-REGR), not reproduced in a browser |
| The Properties / Forms tablist is always visible, also while an edit is open (it was in the `else` of `editing && desktop`, so it vanished) | F44 | `pages/Editor.tsx` (sticky tablist inside the aside), `PropertiesPanel.tsx` (dispatcher) | `uiChecklist.test.ts › the Properties / Forms tabs are ALWAYS visible`; `textsidebar.spec.ts › tabs stay visible` | unverified |
| Sidebar **Text** box: the whole line segment, two-way with the on-page editor, Enter commits, Esc returns to the editor | F44 / F13 | `lib/text/editSession.ts` (`orig`, `setTextFromSidebar`, text is the session's), `TextPropertiesPanel.tsx` (Text group), `TextEditLayer.tsx` (reads/writes the session text) | `textsidebar.spec.ts › the sidebar's Text box…`; `src/tests/styleModel.test.ts` (`setText` / `orig`) | unverified |
| `Original: "…"` + **Reset** (back to the page's text) | F44 | same | `textsidebar.spec.ts › the sidebar's Text box…` | unverified |
| The cover-and-replace explanation, with the sampled background colour, is back | F44 | `TextPropertiesPanel.tsx` (`cover-note`) | `textsidebar.spec.ts` | unverified |
| fixtures | F45 | `scripts/make-fixtures.mjs` → `frame-bg.pdf`, `para.pdf` | the specs above | not generated yet |
