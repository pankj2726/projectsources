/**
 * TASKS-02 §2.4A – text style model + edit-session store (F44). NOT YET RUN (no shell in the authoring environment).
 * Pure logic only: the sidebar's DOM behaviour (focus rule, bottom sheet, one click opens it) is in tests/e2e/textsidebar.spec.ts.
 */
import { beforeEach, describe, expect, it } from "vitest";
import { createObject, type RunStyle, type Span } from "../lib/model/objects";
import {
  FAMILY_LABEL,
  applyToRange,
  cmykToRgb,
  cpToU16,
  familyFromLabel,
  grayToRgb,
  isStandardFontName,
  layoutRuns,
  normalizeHex,
  rangeValue,
  reconcileSpans,
  setBase,
  splitRuns,
  stripSubsetPrefix,
  transformCase,
  u16ToCp,
  SCRIPT_SCALE,
  type RunMeasure,
} from "../lib/text/styleModel";
import { styleDiffersFromOriginal, styleDirty, useEditSession, type Detected, type Extras } from "../lib/text/editSession";

const base: RunStyle = { family: "sans", size: 10, bold: false, italic: false, underline: false, strike: false, script: "none", color: "#000000" };
const text = "hello world";
const len = Array.from(text).length;
/** every character is size/2 wide, so expected positions are exact */
const fake: RunMeasure = (t, f) => Array.from(t).length * f.size * 0.5;

describe("range-aware styling", () => {
  it("styles only the selected range and reports Mixed over a mixed range", () => {
    const spans = applyToRange(len, base, [], 6, 11, { bold: true });
    expect(spans).toEqual([{ a: 6, b: 11, s: { bold: true } }]);
    expect(rangeValue(len, base, spans, 0, 11, "bold")).toEqual({ value: false, mixed: true });
    expect(rangeValue(len, base, spans, 6, 11, "bold")).toEqual({ value: true, mixed: false });
    expect(rangeValue(len, base, spans, 0, 5, "bold")).toEqual({ value: false, mixed: false });
    // caret only (a === b) looks at the whole unit
    expect(rangeValue(len, base, spans, 3, 3, "bold").mixed).toBe(true);
  });
  it("setting a property back to the base value removes the span; adjacent equal spans merge", () => {
    const bold = applyToRange(len, base, [], 0, 6, { bold: true });
    expect(applyToRange(len, base, bold, 0, 6, { bold: false })).toEqual([]);
    const a = applyToRange(len, base, [], 0, 3, { bold: true });
    expect(applyToRange(len, base, a, 3, 6, { bold: true })).toEqual([{ a: 0, b: 6, s: { bold: true } }]);
  });
  it("overlapping different properties split into the right pieces", () => {
    let spans = applyToRange(len, base, [], 0, 6, { bold: true });
    spans = applyToRange(len, base, spans, 3, 9, { color: "#ff0000" });
    expect(spans).toEqual([
      { a: 0, b: 3, s: { bold: true } },
      { a: 3, b: 6, s: { bold: true, color: "#ff0000" } },
      { a: 6, b: 9, s: { color: "#ff0000" } },
    ]);
  });
  it("a caret-only change edits the base and clears that property from every span", () => {
    const spans: Span[] = [{ a: 0, b: 3, s: { bold: true, color: "#ff0000" } }, { a: 5, b: 8, s: { bold: false } }];
    const r = setBase({ ...base }, spans, { bold: true });
    expect(r.base.bold).toBe(true);
    expect(r.spans).toEqual([{ a: 0, b: 3, s: { color: "#ff0000" } }]);
  });
  it("splitRuns follows the spans", () => {
    const spans = applyToRange(len, base, [], 6, 11, { bold: true });
    expect(splitRuns(text, base, spans).map((r) => [r.text, r.style.bold])).toEqual([["hello ", false], ["world", true]]);
    expect(splitRuns(text, base, [])).toEqual([{ text, style: base }]);
  });
});

describe("spans follow edits to the text", () => {
  const span = (a: number, b: number): Span[] => [{ a, b, s: { bold: true } }];
  it("typing INSIDE a span extends it; at its edges it does not", () => {
    expect(reconcileSpans("abcdef", "abcXYdef", span(2, 4))).toEqual(span(2, 6));
    expect(reconcileSpans("abcdef", "abXYcdef", span(2, 4))).toEqual(span(4, 6)); // before the span: shifted, not styled
    expect(reconcileSpans("abcdef", "abcdXYef", span(2, 4))).toEqual(span(2, 4)); // right after the span: not styled
  });
  it("deleting inside shrinks, deleting everything drops the span", () => {
    expect(reconcileSpans("abcdef", "abdef", span(2, 4))).toEqual(span(2, 3));
    expect(reconcileSpans("abcdef", "abef", span(2, 4))).toEqual([]);
  });
  it("no change keeps the same spans", () => {
    const s = span(1, 3);
    expect(reconcileSpans("abc", "abc", s)).toBe(s);
  });
});

describe("helpers", () => {
  it("case transforms", () => {
    expect(transformCase("hello world", "upper")).toBe("HELLO WORLD");
    expect(transformCase("Hello World", "lower")).toBe("hello world");
    expect(transformCase("hELLO wORLD, don't", "title")).toBe("Hello World, Don't");
  });
  it("hex parsing accepts #rgb, rgb(), 'r,g,b' and rejects junk", () => {
    expect(normalizeHex("#ABC")).toBe("#aabbcc");
    expect(normalizeHex("336699")).toBe("#336699");
    expect(normalizeHex("rgb(1, 2, 3)")).toBe("#010203");
    expect(normalizeHex("12,34,56")).toBe("#0c2238");
    expect(normalizeHex("nope")).toBeNull();
    expect(normalizeHex("#12")).toBeNull();
  });
  it("gray / CMYK → RGB for display", () => {
    expect(grayToRgb(0.4)).toBe("#666666");
    expect(cmykToRgb(0, 0, 0, 1)).toBe("#000000");
    expect(cmykToRgb(0, 0, 0, 0)).toBe("#ffffff");
    expect(cmykToRgb(1, 0, 0, 0)).toBe("#00ffff");
  });
  it("subset prefixes are stripped and standard fonts recognised", () => {
    expect(stripSubsetPrefix("ABCDEF+Arial-BoldMT")).toBe("Arial-BoldMT");
    expect(stripSubsetPrefix("Arial")).toBe("Arial");
    for (const n of ["ABCDEF+Arial-BoldMT", "TimesNewRomanPSMT", "CourierNewPSMT", "Helvetica-Bold", "Liberation Sans"]) expect(isStandardFontName(n), n).toBe(true);
    for (const n of ["ABCDEF+Calibri", "Garamond", "NotoSansDevanagari"]) expect(isStandardFontName(n), n).toBe(false);
  });
  it("family labels round-trip (datalist search)", () => {
    for (const f of ["sans", "serif", "mono"] as const) expect(familyFromLabel(FAMILY_LABEL[f])).toBe(f);
    expect(familyFromLabel("Comic Sans")).toBeNull();
  });
  it("UTF-16 ↔ code point offsets agree for astral characters", () => {
    const t = "a😀b";
    expect(u16ToCp(t, 3)).toBe(2);
    expect(cpToU16(t, 2)).toBe(3);
  });
});

describe("layoutRuns (shared by the SVG preview and the PDF export)", () => {
  const edit = (over: Record<string, unknown> = {}) => Object.assign(createObject("textedit", "p", 10, 20, 100, 14), { text, fontSize: 10, baseline: 9, ...over });
  it("single run, baseline from the object", () => {
    const L = layoutRuns(edit(), fake);
    expect(L.lines).toHaveLength(1);
    expect(L.lines[0].baseline).toBe(9);
    expect(L.lines[0].runs).toMatchObject([{ x: 0, width: 55, size: 10, rise: 0 }]);
  });
  it("spans become consecutive runs with exact x positions", () => {
    const L = layoutRuns(edit({ spans: [{ a: 6, b: 11, s: { bold: true } }] }), fake);
    expect(L.lines[0].runs.map((r) => [r.text, r.x, r.width, r.style.bold])).toEqual([["hello ", 0, 30, false], ["world", 30, 25, true]]);
  });
  it("superscript is smaller and raised, subscript lowered", () => {
    const sup = layoutRuns(edit({ spans: [{ a: 6, b: 11, s: { script: "sup" } }] }), fake).lines[0].runs[1];
    expect(sup.size).toBeCloseTo(10 * SCRIPT_SCALE, 6);
    expect(sup.rise).toBeGreaterThan(0);
    expect(layoutRuns(edit({ spans: [{ a: 6, b: 11, s: { script: "sub" } }] }), fake).lines[0].runs[1].rise).toBeLessThan(0);
  });
  it("character and word spacing widen the run exactly", () => {
    expect(layoutRuns(edit({ charSpacing: 1 }), fake).lines[0].runs[0].width).toBe(55 + 11);
    expect(layoutRuns(edit({ wordSpacing: 2 }), fake).lines[0].runs[0].width).toBe(55 + 2);
  });
  it("alignment applies to text boxes and paragraphs, not to a single edited line", () => {
    const box = (align: string) => Object.assign(createObject("text", "p", 0, 0, 100, 20), { text: "ab", fontSize: 10, align });
    expect(layoutRuns(box("left"), fake).lines[0].runs[0].x).toBe(2);
    expect(layoutRuns(box("center"), fake).lines[0].runs[0].x).toBe(45);
    expect(layoutRuns(box("right"), fake).lines[0].runs[0].x).toBe(88);
    expect(layoutRuns(edit({ text: "ab", align: "center" }), fake).lines[0].runs[0].x).toBe(0);
  });
  it("justify stretches every line but the last", () => {
    const L = layoutRuns(edit({ type: "textedit", unitKey: "p1", text: "aa bb\ncc", align: "justify" }), fake);
    expect(L.lines[0].width).toBeCloseTo(100, 6);
    expect(L.lines[0].runs[0].wordSpacing).toBeCloseTo(75, 6);
    expect(L.lines[1].width).toBe(10);
  });
  it("sanitize is applied before measuring (export strips glyphs the font cannot encode)", () => {
    const L = layoutRuns(edit({ text: "ab你" }), fake, (s) => s.replace("你", "?"));
    expect(L.lines[0].runs[0].width).toBe(15);
  });
});

// ------------------------------------------------------------------ edit-session store
const extras: Extras = { bg: "#ffffff", opacity: 1, align: "left", lineHeight: 12, charSpacing: 0, wordSpacing: 0, dx: 0, dy: 0, rotation: 0, locked: false, boxW: null };
const detected: Detected = { fontLabel: "Arial", substituted: false, fontEstimated: false, sizeEstimated: false, color: "#000000", colorEstimated: false, style: base };
const begin = (t = text, kind: "unit" | "para" = "unit") => useEditSession.getState().begin({ key: "k", pageId: "p", kind, unitId: 0, text: t, orig: t, detected, detectedExtras: extras, base, spans: [], extras, sel: { a: 0, b: 0 }, selU16: { s: 0, e: 0 }, boxW: 50, boxH: 10, hasExisting: false });
const S = () => useEditSession.getState();

describe("edit session store", () => {
  beforeEach(() => {
    S().end();
    begin();
  });
  it("opens clean: nothing dirty, nothing different from the page", () => {
    expect(styleDirty(S().session!)).toBe(false);
    expect(styleDiffersFromOriginal(S().session!)).toEqual({ baseChanged: false, hasSpans: false });
  });
  it("caret only → whole unit (base); range → spans only", () => {
    S().patchRun({ bold: true });
    expect(S().session!.base.bold).toBe(true);
    expect(S().session!.spans).toEqual([]);
    S().setSel(6, 11);
    S().patchRun({ color: "#ff0000" });
    expect(S().session!.spans).toEqual([{ a: 6, b: 11, s: { color: "#ff0000" } }]);
    expect(S().session!.base.color).toBe("#000000");
    expect(S().recent[0]).toBe("#ff0000");
    expect(styleDiffersFromOriginal(S().session!)).toEqual({ baseChanged: true, hasSpans: true });
  });
  it("a range-only change is not a base change (unchanged words stay untouched)", () => {
    S().setSel(0, 5);
    S().patchRun({ italic: true });
    expect(styleDiffersFromOriginal(S().session!)).toEqual({ baseChanged: false, hasSpans: true });
  });
  it("selection is tracked in code points but remembered in UTF-16 for focus restore", () => {
    S().end();
    begin("a😀b");
    S().setSel(1, 3);
    expect(S().session!.sel).toEqual({ a: 1, b: 2 });
    expect(S().session!.selU16).toEqual({ s: 1, e: 3 });
  });
  it("rapid changes of the same property coalesce into ONE undo step; different properties do not", () => {
    S().patchRun({ size: 11 });
    S().patchRun({ size: 12 });
    S().patchRun({ size: 13 });
    expect(S().session!.past).toHaveLength(1);
    S().patchRun({ bold: true });
    expect(S().session!.past).toHaveLength(2);
    S().undo();
    expect(S().session!.base.bold).toBe(false);
    expect(S().session!.base.size).toBe(13);
    S().undo();
    expect(S().session!.base.size).toBe(10);
    S().redo();
    expect(S().session!.base.size).toBe(13);
  });
  it("setText keeps range formatting attached to the right characters", () => {
    S().setSel(6, 11);
    S().patchRun({ bold: true });
    S().setText("hello brave world");
    expect(S().session!.spans).toEqual([{ a: 12, b: 17, s: { bold: true } }]);
  });
  it("reset formatting restores the detected style, spans and extras", () => {
    S().patchRun({ size: 20 });
    S().setSel(0, 3);
    S().patchRun({ underline: true });
    S().patchExtras({ opacity: 0.5, dx: 4 });
    S().resetFormatting();
    const s = S().session!;
    expect(s.base).toEqual(base);
    expect(s.spans).toEqual([]);
    expect(s.extras).toEqual(extras);
  });
  it("moving, spacing and opacity count as 'redraw the whole unit'; alignment only matters for paragraphs", () => {
    S().patchExtras({ dx: 2 });
    expect(styleDiffersFromOriginal(S().session!).baseChanged).toBe(true);
    S().end();
    begin();
    S().patchExtras({ align: "center" });
    expect(styleDiffersFromOriginal(S().session!).baseChanged).toBe(false);
    S().end();
    begin(text, "para");
    S().patchExtras({ align: "center" });
    expect(styleDiffersFromOriginal(S().session!).baseChanged).toBe(true);
  });
  it("defaults for the next text box are changeable without a session", () => {
    S().end();
    S().setDefaults({ size: 22, bold: true });
    expect(S().defaults.size).toBe(22);
    expect(createObject("text", "p", 0, 0, 10, 10)).toMatchObject({ fontSize: 22, bold: true });
    S().setDefaults({ size: 16, bold: false });
  });
  it("end() closes the session", () => {
    S().end();
    expect(S().session).toBeNull();
  });
});
