/**
 * TASKS-02 §2.4B REGRESSION GUARD. "Changing an interaction must not silently remove existing UI or features."
 * Static half of the UI feature checklist (runs in vitest, no browser): every registry item must still exist in the code.
 * The running-app half is tests/e2e/ui-checklist.spec.ts. NOT YET RUN (no shell in the authoring environment).
 */
import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { TOOL_BUTTONS } from "../lib/toolbarDef";
import { TEXT_SIDEBAR_CONTROLS, UI_CHECKLIST } from "../lib/uiRegistry";
import { TOOLS } from "../lib/tools";

const read = (p: string) => readFileSync(p, "utf8");
const toolbar = read("src/components/toolbar/Toolbar.tsx");
const thumbs = read("src/components/sidebar/Thumbnails.tsx");
const editor = read("src/pages/Editor.tsx");
const panel = read("src/components/sidebar/TextPropertiesPanel.tsx");
const i18n = read("src/lib/i18n.ts");

describe("toolbar tools (F06–F15, F24, F26)", () => {
  it("every registry tool is still on the toolbar with the same label + shortcut", () => {
    for (const it of UI_CHECKLIST.filter((i) => i.where === "toolbar-tool")) {
      const b = TOOL_BUTTONS.find((x) => x.id === it.toolId);
      expect(b, `${it.feature} ${it.name}: missing tool "${it.toolId}"`).toBeTruthy();
      expect(`${b!.label} (${b!.key})`, it.name).toBe(it.name);
    }
  });
  it("every toolbar tool is in the registry (new tools must be registered too)", () => {
    for (const b of TOOL_BUTTONS) {
      if (b.id === "hand") continue; // navigation helper, not a registry feature
      expect(UI_CHECKLIST.some((i) => i.toolId === b.id), `tool ${b.id} is not in src/lib/uiRegistry.ts`).toBe(true);
    }
  });
  it("tool shortcuts are unique", () => {
    const keys = TOOL_BUTTONS.map((b) => b.key);
    expect(new Set(keys).size).toBe(keys.length);
  });
});

describe("header, tools menu, page toolbar, tabs", () => {
  const needle: Record<string, string> = { Undo: "editor.undo", Redo: "editor.redo", "⇩ Download": "editor.download", "Find and replace (Ctrl+F)": "Find and replace (Ctrl+F)" };
  it("header buttons", () => {
    for (const it of UI_CHECKLIST.filter((i) => i.where === "header-button")) {
      expect(toolbar, it.name).toContain(needle[it.name]);
      if (needle[it.name].startsWith("editor.")) expect(i18n).toContain(`"${needle[it.name]}"`);
    }
  });
  it("tools-menu entries still exist and open a panel", () => {
    for (const it of UI_CHECKLIST.filter((i) => i.where === "tools-menu")) {
      const t = TOOLS.find((x) => x.name === it.name);
      expect(t, `${it.feature} ${it.name}`).toBeTruthy();
      expect(t!.panel, `${it.name} has no panel`).toBeTruthy();
    }
  });
  it("page toolbar buttons", () => {
    for (const it of UI_CHECKLIST.filter((i) => i.where === "page-toolbar")) expect(thumbs, it.name).toContain(`aria-label="${it.name}"`);
  });
  it("right-hand tabs", () => {
    for (const it of UI_CHECKLIST.filter((i) => i.where === "tab")) expect(editor, it.name).toContain(`"${it.name}"`);
  });
});

describe("text sidebar (F44)", () => {
  it("every required control is still in the panel", () => {
    for (const name of TEXT_SIDEBAR_CONTROLS) expect(panel, `text sidebar lost "${name}"`).toContain(`"${name}"`);
  });
  it("the panel's visibility is never tied to hover or to the object selection", () => {
    expect(panel).not.toMatch(/onMouseEnter|onMouseOver|onPointerEnter|onPointerOver|hover\(|:hover/);
    expect(panel).not.toMatch(/useEditor\b|\.selection\b|selection:/); // not driven by the object selection (the original cause of the regression)
    expect(editor).toContain("TextPropertiesPanel");
    expect(editor).toMatch(/editing && !desktop/); // bottom sheet on mobile / tablet
  });
  it("the Properties / Forms tabs are ALWAYS visible, also while a text edit is open (they used to be replaced)", () => {
    expect(editor).toContain('role="tablist"');
    const aside = editor.slice(editor.indexOf('aria-label="Properties"'));
    const tablist = aside.slice(aside.indexOf('role="tablist"'), aside.indexOf("</div>", aside.indexOf('role="tablist"')));
    expect(tablist).toContain('"Properties"');
    expect(tablist).toContain('"Forms"');
    // the tab bar is not inside any conditional: it is a direct child of the aside
    expect(aside.indexOf('role="tablist"')).toBeLessThan(aside.indexOf("<PropertiesPanel />") + 500);
    const props = read("src/components/sidebar/PropertiesPanel.tsx");
    expect(props).toContain("if (editing) return <TextPropertiesPanel />");
    expect(props).toContain("useEditSession");
  });
  it("the focus rule is implemented on both sides", () => {
    expect(panel).toContain("data-text-sidebar");
    expect(panel).toContain("markSidebarPointer");
    expect(panel).toMatch(/onMouseDown=\{keepFocus\}/);
    const layer = read("src/components/viewer/TextEditLayer.tsx");
    expect(layer).toContain('closest?.("[data-text-sidebar]")');
    expect(layer).toContain("sidebarRecentlyUsed");
  });
  it("Edit text shows no hover UI by default", () => {
    const layer = read("src/components/viewer/TextEditLayer.tsx");
    expect(layer).not.toMatch(/onMouseEnter|onPointerEnter|onMouseOver/);
    expect(layer).toContain("if (!hoverHighlight");
  });
});

describe("active text box (F45) – regression guard", () => {
  const frame = read("src/components/viewer/TextFrame.tsx");
  const geom = read("src/lib/text/frameGeometry.ts");
  const layer = read("src/components/viewer/TextEditLayer.tsx");
  it("every frame part is still defined: 8 resize handles, rotate, move grip", async () => {
    const { TEXT_FRAME_CONTROLS } = await import("../lib/uiRegistry");
    expect(TEXT_FRAME_CONTROLS).toHaveLength(10);
    for (const label of TEXT_FRAME_CONTROLS) expect(geom, `text box lost "${label}"`).toContain(`"${label}"`);
    expect(frame).toContain("aria-label={hd.label}");
    expect(frame).toContain("aria-label={ROTATE_LABEL}");
    expect(frame).toContain("aria-label={MOVE_LABEL}");
  });
  it("it is mounted ONLY for the active edit session – never by hover or by the object selection", () => {
    expect(layer).toMatch(/active && mine && frame && ex && \(\s*<TextFrame/);
    expect(frame).not.toMatch(/onMouseEnter|onPointerEnter|onMouseOver|onPointerOver|:hover/);
    expect(frame).not.toMatch(/useEditor\b|\.selection\b|selection:/);
  });
  it("the interior is NOT a hit target (clicks reach the inline editor); the border and handles are", () => {
    expect(frame).toMatch(/pointerEvents: "none"/); // root svg
    expect(frame).toContain('pointerEvents="stroke"'); // border
    expect(frame).toContain('pointerEvents="all"'); // handles
    expect(frame).toContain('fill="none"');
  });
  it("it is drawn above the page, covers, annotations and the editor, in screen-constant pixels", () => {
    expect(layer.indexOf("<TextFrame")).toBeGreaterThan(layer.indexOf('data-testid="inline-editor"'));
    expect(frame).toContain("STROKE_PX / z");
    expect(frame).toContain("OUTER_STROKE_PX / z"); // white halo for dark / light / image backgrounds
    expect(geom).toContain("STROKE_PX = 1.5");
  });
  it("the focus rule covers the frame: no blur / commit when it is used", () => {
    expect(frame).toContain("markChromePointer");
    expect(frame).toContain("e.preventDefault()");
    expect(frame).toContain("data-text-frame");
    expect(layer).toContain('closest?.("[data-text-frame]")');
    expect(layer).toContain("focusSelf()"); // focus returns to the editor after a gesture
  });
  it("it holds no window / document listeners (pointer capture only), so nothing can leak after commit", () => {
    expect(frame).not.toMatch(/addEventListener|removeEventListener/);
    expect(frame).toContain("setPointerCapture");
  });
  it("the input no longer fakes the frame with its own CSS outline", () => {
    expect(layer).not.toMatch(/outline: `/);
    expect(layer).toContain('outline: "none"');
  });
  it("the sidebar still has the Box group wired to the same store", () => {
    expect(panel).toContain('label="Box width"');
    expect(panel).toContain("patchExtras({ boxW: n })");
  });
});
