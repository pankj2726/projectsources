/**
 * TASKS-02 §2.4A/§2.5 – the sidebar's formatting flows through the SAME minimal-diff planner as the text. NOT YET RUN.
 * The key property: STYLE counts as a change. "Make this word bold" must redraw that word even though its characters did not change.
 */
import { describe, expect, it } from "vitest";
import { buildGlyphMap, type RawItem } from "../lib/text/glyphMap";
import { effectiveUnitSpans, effectiveUnitText, planParagraphEdit, planUnitEdit, type StyleInput } from "../lib/text/unitEdit";
import type { RunStyle } from "../lib/model/objects";

const item = (str: string, x: number, baseline: number, size = 10, w?: number): RawItem => ({ str, x, baseline, w: w ?? str.length * size * 0.5, size, angle: 0, fontName: "f", family: "sans", bold: false, italic: false });
const SENTENCE = "The quarterly report is due on Friday";
const map = buildGlyphMap([item(SENTENCE, 50, 100, 10, 190)]);
const unit = map.units[0];
const ctx = { pageId: "p1", pageW: 612 };
const base: RunStyle = { family: "sans", size: 10, bold: false, italic: false, underline: false, strike: false, script: "none", color: "#000000" };
const sty = (over: Partial<StyleInput> = {}): StyleInput => ({ base, spans: [], baseChanged: false, ...over });
const Q = SENTENCE.indexOf("quarterly");

describe("style is a change", () => {
  it("no text change and no style change → nothing at all", () => {
    expect(planUnitEdit(map, unit, SENTENCE, { ...ctx, style: sty() })).toMatchObject({ ok: true, obj: null, unchanged: true });
  });

  it("bolding one word redraws ONLY that word: same characters, restyled flag, span re-based onto the fragment", () => {
    // a measure that returns the word's ORIGINAL width, so the width delta is exactly 0 and nothing after the word needs shifting
    const qIds = unit.charGlyph.slice(Q, Q + 9).filter((id) => id >= 0);
    const wQ = map.glyphs[qIds[qIds.length - 1]].ink.x + map.glyphs[qIds[qIds.length - 1]].ink.w - map.glyphs[qIds[0]].origin.x;
    const exact = (t: string, size: number) => (t === "quarterly" ? wQ : t.length * size * 0.5);
    const r = planUnitEdit(map, unit, SENTENCE, { ...ctx, measure: exact, style: sty({ spans: [{ a: Q, b: Q + 9, s: { bold: true } }] }) });
    expect(r.ok).toBe(true);
    if (!r.ok || !r.obj) throw new Error("expected an object");
    expect(r.obj.restyled).toBe(true);
    expect(r.obj.unitA).toBe(Q); // "The " is untouched
    expect(r.obj.unitEnd).toBe(Q + 9); // " report is due on Friday" is untouched too: only the formatted word is redrawn
    expect(r.obj.text).toBe("quarterly");
    expect(r.obj.spans).toEqual([{ a: 0, b: 9, s: { bold: true } }]);
    expect(r.obj.covers!.length).toBe(1); // the old word is covered, nothing before it
    expect(effectiveUnitText(unit, r.obj)).toBe(SENTENCE); // the line still reads exactly the same
    expect(effectiveUnitSpans(unit, r.obj)).toEqual([{ a: Q, b: Q + 9, s: { bold: true } }]); // …and re-opening shows the formatting
  });

  it("a changed base style / move / spacing redraws the WHOLE unit", () => {
    const r = planUnitEdit(map, unit, SENTENCE, { ...ctx, style: sty({ baseChanged: true, base: { ...base, size: 14, color: "#cc0000", underline: true } }) });
    expect(r.ok).toBe(true);
    if (!r.ok || !r.obj) throw new Error("expected an object");
    expect(r.obj.unitA).toBe(0);
    expect(r.obj.unitEnd).toBe(Array.from(SENTENCE).length);
    expect(r.obj.text).toBe(SENTENCE);
    expect(r.obj).toMatchObject({ fontSize: 14, color: "#cc0000", underline: true, restyled: true });
    expect(r.obj.x).toBeCloseTo(50, 5);
  });

  it("extras (offset, opacity, spacing, rotation, lock, background) land on the object", () => {
    const r = planUnitEdit(map, unit, SENTENCE, { ...ctx, style: sty({ baseChanged: true, extras: { dx: 3, dy: -2, opacity: 0.5, charSpacing: 0.4, wordSpacing: 1, rotation: 10, locked: true, bg: "#eeeeee" } }) });
    if (!r.ok || !r.obj) throw new Error("expected an object");
    expect(r.obj).toMatchObject({ opacity: 0.5, charSpacing: 0.4, wordSpacing: 1, rotation: 10, locked: true, bg: "#eeeeee", dx: 3, dy: -2 });
    expect(r.obj.x).toBeCloseTo(53, 5);
    expect(r.obj.y).toBeCloseTo(unit.bbox.y - 2, 5);
  });

  it("range formatting AND a text change in the same edit", () => {
    const next = SENTENCE.replace("Friday", "Monday");
    const r = planUnitEdit(map, unit, next, { ...ctx, style: sty({ spans: [{ a: Q, b: Q + 9, s: { italic: true } }] }) });
    if (!r.ok || !r.obj) throw new Error("expected an object");
    expect(r.obj.unitA).toBe(Q); // the range now spans from the formatted word to the changed word
    expect(effectiveUnitText(unit, r.obj)).toBe(next);
    expect(r.obj.spans![0]).toEqual({ a: 0, b: 9, s: { italic: true } });
  });

  it("shrink-to-fit scales explicit span sizes with the base size", () => {
    const longer = `${SENTENCE} and a good many more words to force the line past its room`;
    const r = planUnitEdit(map, unit, longer, { ...ctx, pageW: 260, minScale: 0.05, style: sty({ spans: [{ a: Q, b: Q + 9, s: { size: 20 } }] }) });
    if (!r.ok || !r.obj) throw new Error(r.ok ? "expected an object" : r.error);
    expect(r.obj.fontSize!).toBeLessThan(10);
    expect(r.obj.spans![0].s.size!).toBeLessThan(20);
    expect(r.notes.join(" ")).toMatch(/Shrunk/);
  });
});

describe("paragraph mode takes the base style, alignment and line spacing", () => {
  const line = (s: string, y: number) => item(s, 50, y, 10, 300);
  const pmap = buildGlyphMap([line("first line of the paragraph with enough words", 100), line("second line of the paragraph with enough words", 112), line("third line ends the paragraph here", 124)]);
  const para = pmap.paragraphs[0];
  const text = para.unitIds.map((i) => pmap.units[i].text).join(" ");
  it("a style-only change is still an edit", () => {
    const r = planParagraphEdit(pmap, para, text, { ...ctx, style: sty({ baseChanged: true, base: { ...base, bold: true }, extras: { align: "center", lineHeight: 18 } }) });
    if (!r.ok || !r.obj) throw new Error("expected an object");
    expect(r.obj).toMatchObject({ unitKey: "p0", bold: true, align: "center", lineHeight: 18, restyled: true });
    expect(planParagraphEdit(pmap, para, text, { ...ctx, style: sty() })).toMatchObject({ ok: true, obj: null });
  });
});
