/**
 * TASKS-02 §2.4A – styled text survives EXPORT (worker-side pipeline, pure pdf-lib; no DOM). NOT YET RUN.
 * Checks: nothing is skipped (no warnings), the page count survives, and a restyle of unchanged characters is really drawn.
 * What these cannot check (needs a viewer): that the glyphs look right. tests/e2e/textsidebar.spec.ts re-parses the download.
 */
import { PDFDocument } from "@cantoo/pdf-lib";
import { describe, expect, it } from "vitest";
import { exportDocumentWithReport } from "../lib/pdf/export";
import { createObject, type PdfObject } from "../lib/model/objects";
import type { ExportPayload } from "../lib/pdf/types";

async function src(): Promise<Uint8Array> {
  const d = await PDFDocument.create();
  d.addPage([300, 200]).drawText("source page", { x: 20, y: 150 });
  return d.save();
}
const payload = (bytes: Uint8Array, objects: PdfObject[]): ExportPayload => ({
  sources: [{ id: "s", bytes }],
  primaryId: "s",
  pages: [{ id: "a", sourceId: "s", srcIndex: 0, rotation: 0, cropBox: [0, 0, 300, 200] }],
  objects,
  rasters: {},
  redactions: {},
});
const edit = (over: Record<string, unknown> = {}): PdfObject =>
  Object.assign(createObject("textedit", "a", 20, 40, 120, 14), { text: "hello world", origText: "hello world", fontSize: 12, family: "sans", baseline: 11, covers: [{ x: 19, y: 40, w: 100, h: 14 }], bg: "#ffffff", restyled: true, ...over });

describe("styled text export (F44)", () => {
  it("per-range bold + colour, underline, strike, super/subscript, spacing: all drawn, nothing skipped", async () => {
    const src0 = await src();
    const objs: PdfObject[] = [
      edit({ spans: [{ a: 6, b: 11, s: { bold: true, color: "#cc0000" } }] }),
      edit({ y: 60, underline: true, strike: true }),
      edit({ y: 80, spans: [{ a: 6, b: 11, s: { script: "sup" } }, { a: 0, b: 2, s: { script: "sub", size: 8 } }] }),
      edit({ y: 100, charSpacing: 1.5, wordSpacing: 4, opacity: 0.6, rotation: 5 }),
      edit({ y: 120, family: "serif", italic: true, color: "#336699" }),
      edit({ y: 140, family: "mono", spans: [{ a: 0, b: 5, s: { family: "serif", italic: true } }] }),
    ];
    const r = await exportDocumentWithReport(payload(src0, objs));
    expect(r.warnings).toEqual([]);
    expect((await PDFDocument.load(r.bytes)).getPageCount()).toBe(1);
    expect(r.bytes.length).toBeGreaterThan(src0.length);
  });

  it("text boxes honour underline / strike / spacing too, and justified paragraphs export", async () => {
    const src0 = await src();
    const box = Object.assign(createObject("text", "a", 20, 20, 160, 80), { text: "one two three four five six seven eight nine ten eleven", fontSize: 11, underline: true, charSpacing: 0.3 });
    const para = edit({ unitKey: "p3", text: "the quick brown fox jumps over\nthe lazy dog and keeps going", origText: "x", w: 200, align: "justify", lineHeight: 14, restyled: true });
    const r = await exportDocumentWithReport(payload(src0, [box, para]));
    expect(r.warnings).toEqual([]);
    expect((await PDFDocument.load(r.bytes)).getPageCount()).toBe(1);
  });

  it("a restyle of UNCHANGED characters is drawn; without the flag it is skipped exactly as before", async () => {
    const src0 = await src();
    const plain = await exportDocumentWithReport(payload(src0, [edit({ restyled: undefined })]));
    const restyled = await exportDocumentWithReport(payload(src0, [edit({ spans: [{ a: 0, b: 5, s: { bold: true } }] })]));
    expect(plain.warnings).toEqual([]);
    expect(restyled.warnings).toEqual([]);
    expect(restyled.bytes.length).toBeGreaterThan(plain.bytes.length);
  });

  it("pure insertion (covers: []) covers nothing but still draws", async () => {
    const src0 = await src();
    const r = await exportDocumentWithReport(payload(src0, [edit({ covers: [], text: " today", origText: "", restyled: undefined })]));
    expect(r.warnings).toEqual([]);
  });

  it("characters the built-in fonts cannot encode never throw (they are replaced, or rastered by the main thread)", async () => {
    const src0 = await src();
    const r = await exportDocumentWithReport(payload(src0, [edit({ text: "naïve 你好 नमस्ते", spans: [{ a: 0, b: 3, s: { bold: true } }] })]));
    expect(r.warnings).toEqual([]);
  });

  it("an invalid new property is skipped with a warning; the PDF is still produced", async () => {
    const src0 = await src();
    const r = await exportDocumentWithReport(payload(src0, [edit({ fontSize: Number.NaN }), edit({ y: 70 })]));
    expect((await PDFDocument.load(r.bytes)).getPageCount()).toBe(1);
    expect(r.warnings.join(" ")).toMatch(/font size is invalid|not a finite number/);
  });
});
