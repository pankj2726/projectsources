/**
 * TASKS-02 §2.4C – the ACTIVE TEXT BOX (F45): handle geometry, one-undo-per-gesture, and how the box's width / position /
 * rotation reach the exported text. NOT YET RUN (no shell in the authoring environment). All numbers below are hand-derived
 * from the formulas in lib/text/frameGeometry.ts; a failure on first run is as likely a wrong expectation as a wrong formula.
 * The pointer / focus / DOM half is tests/e2e/textframe.spec.ts.
 */
import { beforeEach, describe, expect, it } from "vitest";
import { rotateAbout } from "../lib/model/coords";
import {
  HANDLES,
  angleAt,
  cursorFor,
  frameBox,
  insideBox,
  normDeg,
  pivotOf,
  resizeBy,
  rotateTo,
  snapAngle,
  type ResizeStart,
} from "../lib/text/frameGeometry";
import { styleDiffersFromOriginal, useEditSession, type Detected, type Extras } from "../lib/text/editSession";
import { buildGlyphMap, type RawItem } from "../lib/text/glyphMap";
import { planParagraphEdit, planUnitEdit, unitTextWidth, type StyleInput } from "../lib/text/unitEdit";
import type { RunStyle } from "../lib/model/objects";

const near = (a: number, b: number, d = 6) => expect(a).toBeCloseTo(b, d);

// ------------------------------------------------------------------ geometry
const box = { x: 10, y: 20, w: 100, h: 14 };
const pivot = { x: 60, y: 27 };
const start = (over: Partial<ResizeStart> = {}): ResizeStart => ({ box, pivot, rotation: 0, kind: "unit", size: 10, naturalW: 80, lineHeight: 12, boxW: null, dx: 0, dy: 0, minScale: 0.6, ...over });

describe("handles", () => {
  it("there are exactly 8, one per compass point, each with an accessible label", () => {
    expect(HANDLES.map((h) => h.id).sort()).toEqual(["e", "n", "ne", "nw", "s", "se", "sw", "w"]);
    expect(new Set(HANDLES.map((h) => h.label)).size).toBe(8);
  });
  it("resize cursors follow the handle's direction after rotation", () => {
    expect(cursorFor("e", 0)).toBe("ew-resize");
    expect(cursorFor("w", 0)).toBe("ew-resize");
    expect(cursorFor("n", 0)).toBe("ns-resize");
    expect(cursorFor("nw", 0)).toBe("nwse-resize");
    expect(cursorFor("se", 0)).toBe("nwse-resize");
    expect(cursorFor("ne", 0)).toBe("nesw-resize");
    expect(cursorFor("sw", 0)).toBe("nesw-resize");
    expect(cursorFor("e", 90)).toBe("ns-resize"); // a box turned 90° (page or text) has its right edge pointing down
    expect(cursorFor("se", 45)).toBe("ns-resize");
    expect(cursorFor("e", -45)).toBe("nesw-resize");
    expect(cursorFor("e", 360)).toBe("ew-resize");
  });
});

describe("angles", () => {
  it("snapAngle steps of 15°", () => {
    expect([snapAngle(22), snapAngle(23), snapAngle(-8), snapAngle(7)]).toEqual([15, 30, -15, 0]);
  });
  it("normDeg wraps into (-180, 180]", () => {
    expect([normDeg(190), normDeg(-190), normDeg(180), normDeg(-180), normDeg(720)]).toEqual([-170, 170, 180, 180, 0]);
  });
  it("angleAt is clockwise with 0° straight up", () => {
    const o = { x: 0, y: 0 };
    near(angleAt(o, { x: 0, y: -10 }), 0);
    near(angleAt(o, { x: 10, y: 0 }), 90);
    near(angleAt(o, { x: 0, y: 10 }), 180);
    near(angleAt(o, { x: -10, y: 0 }), -90);
  });
  it("rotateTo is relative to where the drag began (no jump), wraps, and snaps with Shift", () => {
    const o = { x: 0, y: 0 };
    const up = { x: 0, y: -10 };
    expect(rotateTo(o, up, up, 30, false)).toBe(30);
    expect(rotateTo(o, up, { x: 10, y: 0 }, 30, false)).toBe(120);
    expect(rotateTo(o, { x: 10, y: 0 }, { x: 0, y: 10 }, 170, false)).toBe(-100); // 170 + 90 = 260 → -100
    const a22 = { x: Math.sin((22 * Math.PI) / 180) * 10, y: -Math.cos((22 * Math.PI) / 180) * 10 };
    expect(rotateTo(o, up, a22, 0, true)).toBe(15);
    expect(rotateTo(o, up, a22, 0, false)).toBe(22);
  });
});

describe("frame box", () => {
  it("line mode scales about the BASELINE (exactly like the exported text) and follows dx / dy", () => {
    const rect = { x: 9, y: 88, w: 100, h: 14 };
    expect(frameBox({ kind: "unit", rect, baseline: 98, scale: 1, width: 100, height: 0, dx: 0, dy: 0 })).toEqual({ x: 9, y: 88, w: 100, h: 14 });
    expect(frameBox({ kind: "unit", rect, baseline: 98, scale: 2, width: 100, height: 0, dx: 0, dy: 0 })).toEqual({ x: 9, y: 78, w: 100, h: 28 });
    expect(frameBox({ kind: "unit", rect, baseline: 98, scale: 1, width: 120, height: 0, dx: 5, dy: -3 })).toEqual({ x: 14, y: 85, w: 120, h: 14 });
  });
  it("paragraph mode takes its height from the wrapped text", () => {
    expect(frameBox({ kind: "para", rect: { x: 9, y: 88, w: 100, h: 40 }, baseline: 98, scale: 1, width: 150, height: 66, dx: 2, dy: 1 })).toEqual({ x: 11, y: 89, w: 150, h: 66 });
  });
  it("the pivot is the centre of the text object's box, moved by dx / dy", () => {
    expect(pivotOf({ x: 10, y: 20, w: 100, h: 14 }, 5, -2)).toEqual({ x: 65, y: 25 });
  });
  it("insideBox works in the box's own rotated frame", () => {
    expect(insideBox({ x: 60, y: 27 }, box, pivot, 0)).toBe(true);
    expect(insideBox({ x: 5, y: 27 }, box, pivot, 0)).toBe(false);
    expect(insideBox({ x: 5, y: 27 }, box, pivot, 0, 6)).toBe(true); // padding
    expect(insideBox({ x: 60, y: 60 }, box, pivot, 90)).toBe(true); // a box turned 90° about its pivot now covers (60, 60)
    expect(insideBox({ x: 60, y: 100 }, box, pivot, 90)).toBe(false);
  });
});

describe("resizeBy – line mode", () => {
  it("right edge WIDER: the box gets room, the text does not grow", () => {
    const p = resizeBy(start(), "e", { x: 150, y: 27 }, false);
    expect(p).toMatchObject({ boxW: 140, scale: 1, dx: 0, dy: 0 });
  });
  it("right edge NARROWER: shrink-to-fit, never below the minimum scale", () => {
    expect(resizeBy(start(), "e", { x: 70, y: 27 }, false)).toMatchObject({ boxW: 60, scale: 0.75 });
    const clamped = resizeBy(start(), "e", { x: 20, y: 27 }, false);
    near(clamped.scale, 0.6);
    near(clamped.boxW!, 48);
  });
  it("left edge moves the text with it (dx) and keeps the right edge fixed", () => {
    const p = resizeBy(start(), "w", { x: 30, y: 27 }, false);
    expect(p).toMatchObject({ boxW: 80, scale: 1, dx: 20 });
    const narrow = resizeBy(start(), "w", { x: 70, y: 27 }, false);
    near(narrow.boxW!, 48);
    near(narrow.scale, 0.6);
    near(narrow.dx, 52);
  });
  it("a corner WITHOUT Shift only changes the width", () => {
    expect(resizeBy(start(), "se", { x: 150, y: 90 }, false)).toMatchObject({ boxW: 140, scale: 1, dy: 0 });
  });
  it("Shift + corner scales the font proportionally, anchored at the opposite corner", () => {
    expect(resizeBy(start(), "se", { x: 210, y: 48 }, true)).toMatchObject({ scale: 2, boxW: null, dx: 0 });
    const nw = resizeBy(start(), "nw", { x: 60, y: 27 }, true);
    near(nw.scale, 0.5);
    near(nw.dx, 50);
    expect(resizeBy(start(), "se", { x: 10000, y: 27 }, true).scale).toBe(8);
    expect(resizeBy(start(), "se", { x: 11, y: 21 }, true).scale).toBe(0.2);
  });
  it("top / bottom edges scale the font (the height follows the font size)", () => {
    near(resizeBy(start(), "s", { x: 60, y: 48 }, false).scale, 2);
    near(resizeBy(start(), "n", { x: 60, y: 6 }, false).scale, 2);
  });
  it("an explicit box width scales with the font", () => {
    expect(resizeBy(start({ boxW: 100 }), "se", { x: 210, y: 48 }, true).boxW).toBe(200);
  });
});

describe("resizeBy – paragraph mode", () => {
  const para = (o: Partial<ResizeStart> = {}) => start({ kind: "para", ...o });
  it("edges set the box width (the text reflows); the font and spacing are untouched", () => {
    const p = resizeBy(para(), "e", { x: 90, y: 27 }, false);
    expect(p).toMatchObject({ boxW: 80, scale: 1, lineHeight: 12 });
    expect(resizeBy(para(), "e", { x: 15, y: 27 }, false).boxW).toBe(24); // never narrower than 24 pt
  });
  it("top / bottom edges change line spacing, clamped to 0.6–4 × the font size", () => {
    near(resizeBy(para(), "s", { x: 60, y: 48 }, false).lineHeight, 24);
    expect(resizeBy(para(), "s", { x: 60, y: 21 }, false).lineHeight).toBe(6);
    expect(resizeBy(para(), "s", { x: 60, y: 900 }, false).lineHeight).toBe(40);
  });
  it("Shift + corner scales the font, the line spacing and the width together", () => {
    const p = resizeBy(para(), "se", { x: 210, y: 48 }, true);
    expect(p).toMatchObject({ scale: 2, lineHeight: 24, boxW: 200 });
  });
});

describe("resizeBy – rotated boxes resize along their OWN axes", () => {
  const turned = (local: { x: number; y: number }, deg: number) => rotateAbout(local, pivot, deg);
  it("right edge of a box rotated 90°", () => {
    expect(resizeBy(start({ rotation: 90 }), "e", turned({ x: 150, y: 27 }, 90), false)).toMatchObject({ boxW: 140, scale: 1 });
  });
  it("left edge of a box rotated 90° translates the text along the rotated axis", () => {
    const p = resizeBy(start({ rotation: 90 }), "w", turned({ x: 30, y: 27 }, 90), false);
    near(p.dx, 0, 5);
    near(p.dy, 20, 5);
    near(p.boxW!, 80, 5);
  });
  it("round-trips at any angle", () => {
    for (const deg of [0, 15, 37, 90, 135, 180, 270, -45]) {
      const p = resizeBy(start({ rotation: deg }), "e", turned({ x: 150, y: 27 }, deg), false);
      near(p.boxW!, 140, 5);
    }
  });
});

// ------------------------------------------------------------------ session: one gesture = one undo step
const base: RunStyle = { family: "sans", size: 10, bold: false, italic: false, underline: false, strike: false, script: "none", color: "#000000" };
const extras: Extras = { bg: "#ffffff", opacity: 1, align: "left", lineHeight: 12, charSpacing: 0, wordSpacing: 0, dx: 0, dy: 0, rotation: 0, locked: false, boxW: null };
const detected: Detected = { fontLabel: "Arial", substituted: false, fontEstimated: false, sizeEstimated: false, color: "#000000", colorEstimated: false, style: base };
const S = () => useEditSession.getState();
const open = (kind: "unit" | "para" = "unit", spans: { a: number; b: number; s: { size?: number } }[] = []) =>
  S().begin({ key: "k", pageId: "p", kind, unitId: 0, text: "hello world", orig: "hello world", detected, detectedExtras: extras, base, spans, extras, sel: { a: 0, b: 0 }, selU16: { s: 0, e: 0 }, boxW: 50, boxH: 12, hasExisting: false });

describe("frame gestures in the edit session", () => {
  beforeEach(() => {
    S().end();
    open();
  });
  const startSnap = () => ({ base: S().session!.base, spans: S().session!.spans });
  const patch = (o: Partial<{ dx: number; dy: number; boxW: number | null; scale: number; lineHeight: number }> = {}) => ({ dx: 0, dy: 0, boxW: null, scale: 1, lineHeight: 12, ...o });

  it("a whole drag is ONE undo step, however many pointer moves it has", () => {
    const st = startSnap();
    S().beginGesture();
    for (const f of [0.9, 0.8, 0.7, 0.6]) S().applyFrame(st, patch({ scale: f, boxW: 100 * f }));
    S().patchExtras({ rotation: 15 });
    S().endGesture();
    expect(S().session!.past).toHaveLength(1);
    S().undo();
    expect(S().session!.base.size).toBe(10);
    expect(S().session!.extras).toEqual(extras);
    S().redo();
    expect(S().session!.base.size).toBe(6);
    expect(S().session!.extras.rotation).toBe(15);
  });
  it("scale is relative to where the gesture STARTED (it never compounds)", () => {
    const st = startSnap();
    S().beginGesture();
    S().applyFrame(st, patch({ scale: 0.5 }));
    S().applyFrame(st, patch({ scale: 0.8 }));
    expect(S().session!.base.size).toBe(8);
    S().endGesture();
  });
  it("explicit sizes inside spans scale too, other spans are untouched", () => {
    S().end();
    open("unit", [{ a: 0, b: 2, s: { size: 20 } }, { a: 3, b: 5, s: {} }]);
    const st = startSnap();
    S().beginGesture();
    S().applyFrame(st, patch({ scale: 0.5 }));
    S().endGesture();
    expect(S().session!.spans[0].s.size).toBe(10);
    expect(S().session!.spans[1].s).toEqual({});
  });
  it("a click on a handle without dragging leaves NO undo step", () => {
    S().beginGesture();
    S().endGesture();
    expect(S().session!.past).toHaveLength(0);
    expect(S().session!.gesture).toBe(false);
  });
  it("changes inside a gesture do not create their own steps; after it, normal coalescing resumes", () => {
    S().beginGesture();
    S().patchExtras({ dx: 3 });
    S().patchExtras({ dx: 6 });
    expect(S().session!.past).toHaveLength(1);
    S().endGesture();
    S().patchExtras({ dy: 2 });
    expect(S().session!.past).toHaveLength(2);
  });
  it("nudging with the keyboard coalesces like any other format change", () => {
    S().patchExtras({ dx: 1 });
    S().patchExtras({ dx: 2 });
    S().patchExtras({ dx: 3 });
    expect(S().session!.past).toHaveLength(1);
  });
  it("beginGesture twice does not double-record", () => {
    S().beginGesture();
    S().beginGesture();
    S().patchExtras({ dx: 1 });
    S().endGesture();
    expect(S().session!.past).toHaveLength(1);
  });
  it("the layer can publish the live box size without touching history", () => {
    S().setBox(120, 14);
    expect(S().session!.boxW).toBe(120);
    expect(S().session!.past).toHaveLength(0);
    S().setBox(120.01, 14);
    expect(S().session!.boxW).toBe(120); // < 0.05 pt change: no store churn
  });
  it("a unit's width is only a LIMIT; a paragraph's width reflows it, so only the latter redraws unchanged words", () => {
    S().patchExtras({ boxW: 90 });
    expect(styleDiffersFromOriginal(S().session!).baseChanged).toBe(false);
    S().end();
    open("para");
    S().patchExtras({ boxW: 90 });
    expect(styleDiffersFromOriginal(S().session!).baseChanged).toBe(true);
  });
  it("closing the edit removes the session (and with it the frame and the sidebar)", () => {
    S().end();
    expect(S().session).toBeNull();
  });
});

// ------------------------------------------------------------------ the box reaches the exported text
const item = (str: string, x: number, baseline: number, size = 10, w?: number): RawItem => ({ str, x, baseline, w: w ?? str.length * size * 0.5, size, angle: 0, fontName: "f", family: "sans", bold: false, italic: false });
/** deterministic metrics: every character is size/2 wide */
const fixed = (t: string, size: number) => Array.from(t).length * size * 0.5;
const sty = (over: Partial<StyleInput> = {}): StyleInput => ({ base, spans: [], baseChanged: true, ...over });
const SENTENCE = "The quarterly report is due on Friday"; // 37 chars → 185 pt at 10 pt
const map = buildGlyphMap([item(SENTENCE, 50, 100, 10, 185)]);
const unit = map.units[0];
const ctx = { pageId: "p", pageW: 612, measure: fixed };

describe("unitTextWidth", () => {
  it("honours per-range styles and spacing", () => {
    const m = (t: string, size: number, st: { bold?: boolean }) => Array.from(t).length * size * (st.bold ? 0.6 : 0.5);
    expect(unitTextWidth("ab", base, [], {}, m)).toBe(10);
    expect(unitTextWidth("ab", base, [{ a: 1, b: 2, s: { bold: true } }], {}, m)).toBe(5 + 6);
    expect(unitTextWidth("ab", base, [], { charSpacing: 1, wordSpacing: 5 }, m)).toBe(12);
    expect(unitTextWidth("a b", base, [], { wordSpacing: 5 }, m)).toBe(15 + 5);
  });
});

describe("a line's box width is a shrink-to-fit limit", () => {
  it("narrower than the text → shrunk to fit, with a message", () => {
    const r = planUnitEdit(map, unit, SENTENCE, { ...ctx, style: sty({ extras: { boxW: 140 } }) });
    if (!r.ok || !r.obj) throw new Error(r.ok ? "expected an object" : r.error);
    expect(r.notes.join(" ")).toMatch(/Shrunk to 75%/);
    expect(r.obj.fontSize!).toBeCloseTo(7.46, 1);
  });
  it("too narrow even at the minimum scale → blocked, offering 'allow overflow' (never a silent overlap)", () => {
    const r = planUnitEdit(map, unit, SENTENCE, { ...ctx, style: sty({ extras: { boxW: 60 } }) });
    expect(r.ok).toBe(false);
    if (!r.ok) {
      expect(r.canOverflow).toBe(true);
      expect(r.error).toMatch(/No room/);
    }
  });
  it("wider than the text → no change to the size", () => {
    const r = planUnitEdit(map, unit, SENTENCE, { ...ctx, style: sty({ extras: { boxW: 400 } }) });
    expect(r.ok && r.obj?.fontSize).toBe(10);
  });
  it("a line the user MOVED is no longer limited by its old neighbour on the row", () => {
    const m2 = buildGlyphMap([item("left part", 50, 100, 10, 45), item("far right", 300, 100, 10, 45)]);
    const longer = "left part " + "x".repeat(60); // 70 chars = 350 pt: collides with "far right" at x = 300
    const c = { ...ctx, overflow: "skip" as const };
    expect(planUnitEdit(m2, m2.units[0], longer, { ...c, style: sty() }).ok).toBe(false);
    expect(planUnitEdit(m2, m2.units[0], longer, { ...c, style: sty({ extras: { dy: 10 } }) }).ok).toBe(true);
  });
  it("move, rotate, spacing and lock land on the object; rotation does not move the covers", () => {
    const r = planUnitEdit(map, unit, SENTENCE, { ...ctx, style: sty({ extras: { dx: 4, dy: -3, rotation: 15, boxW: 400 } }) });
    if (!r.ok || !r.obj) throw new Error("expected an object");
    expect(r.obj).toMatchObject({ rotation: 15, dx: 4, dy: -3 });
    expect(r.obj.x).toBeCloseTo(unit.x0 + 4, 5);
    const plain = planUnitEdit(map, unit, SENTENCE, { ...ctx, style: sty() });
    if (!plain.ok || !plain.obj) throw new Error("expected an object");
    expect(r.obj.covers).toEqual(plain.obj.covers); // covers are absolute page-space rectangles over the ORIGINAL glyphs
  });
});

describe("a paragraph's box width reflows it", () => {
  const line = (s: string, y: number) => item(s, 50, y, 10, 300);
  const pmap = buildGlyphMap([line("first line of the paragraph with enough words", 100), line("second line of the paragraph with enough words", 112), line("third line ends the paragraph here", 124)]);
  const para = pmap.paragraphs[0];
  const text = para.unitIds.map((i) => pmap.units[i].text).join(" ");
  const pctx = { pageId: "p", pageW: 612, measure: fixed };
  it("a narrower box wraps to more lines and the object is exactly that wide", () => {
    const wide = planParagraphEdit(pmap, para, text, { ...pctx, style: sty() });
    const narrow = planParagraphEdit(pmap, para, text, { ...pctx, style: sty({ extras: { boxW: 150 } }) });
    if (!wide.ok || !wide.obj || !narrow.ok || !narrow.obj) throw new Error("expected objects");
    expect(narrow.obj.w).toBeCloseTo(150, 5);
    expect(narrow.obj.text!.split("\n").length).toBeGreaterThan(wide.obj.text!.split("\n").length);
  });
});
