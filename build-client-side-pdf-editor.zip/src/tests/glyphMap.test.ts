/**
 * TASKS-02 Task 2 (revised) – edit-unit model tests on SYNTHETIC layouts. NOT YET RUN (no shell in the authoring
 * environment). Real-PDF fixtures: scripts/make-fixtures.mjs writes tests/fixtures/layout.pdf + layout.truth.json that
 * tests/e2e/edittext.spec.ts checks in a browser.
 *
 * The key property: for every word, the unit that a click opens equals the expected LINE SEGMENT exactly –
 * no missing words (no fragmentation inside a sentence) and no extra words from another section (no bleed).
 */
import { describe, expect, it } from "vitest";
import { buildGlyphMap, caretIndexAt, inkCenter, paragraphText, unitAt, unitTextOf, type GlyphMap, type RawItem, type Rule } from "../lib/text/glyphMap";
import { canvasToPage, pageToCanvas, type PageGeo } from "../lib/model/coords";

const item = (str: string, x: number, baseline: number, size = 10, w?: number, angle = 0, extra: Partial<RawItem> = {}): RawItem => ({
  str,
  x,
  baseline,
  w: w ?? str.length * size * 0.5,
  size,
  angle,
  fontName: "f",
  family: "sans",
  bold: false,
  italic: false,
  ...extra,
});
const texts = (m: GlyphMap) => m.units.map((u) => u.text);
const reasons = (m: GlyphMap) => m.boundaries.map((b) => `${b.hard ? "hard" : "soft"}: ${b.reason}`).join("\n");

describe("one sentence = one unit (no fragmentation)", () => {
  it("a sentence that pdf.js split into several items stays ONE unit", () => {
    const m = buildGlyphMap([item("The quarterly ", 50, 100, 10, 70), item("report is due ", 120, 100, 10, 70), item("on Friday", 190, 100, 10, 45)]);
    expect(texts(m)).toEqual(["The quarterly report is due on Friday"]);
    expect(new Set(m.glyphs.map((g) => g.lineId)).size).toBe(1);
  });

  it("justified text: one item per word with STRETCHED but uniform spaces is still one unit", () => {
    const m = buildGlyphMap([item("The", 50, 100, 10, 15), item("quarterly", 75, 100, 10, 45), item("report", 130, 100, 10, 30)]);
    expect(texts(m)).toEqual(["The quarterly report"]); // virtual spaces where words are separated by a gap
    expect(m.units[0].charGlyph.filter((g) => g === -1)).toHaveLength(2);
    expect(unitTextOf(m, m.units[0])).toBe("The quarterly report");
  });

  it("justified text with LARGE uniform gaps (> 2× font size) is still one unit; a lone far gutter still splits", () => {
    const stretched = buildGlyphMap([item("AAAA", 50, 100, 10, 20), item("BBBB", 115, 100, 10, 20), item("CCCC", 180, 100, 10, 20), item("DDDD", 245, 100, 10, 20)]); // gaps 45, 45, 45
    expect(texts(stretched)).toEqual(["AAAA BBBB CCCC DDDD"]);
    const gutter = buildGlyphMap([item("aa", 50, 100, 10, 10), item("bb", 64, 100, 10, 10), item("cc", 78, 100, 10, 10), item("dd", 92, 100, 10, 10), item("ee", 170, 100, 10, 10)]); // gaps 4,4,4 then 68
    expect(texts(gutter)).toEqual(["aa bb cc dd", "ee"]);
  });

  it("bold / italic / font changes inside a sentence do NOT split it", () => {
    const m = buildGlyphMap([item("The ", 50, 100, 10, 20), item("quarterly", 70, 100, 10, 45, 0, { bold: true, fontName: "b" }), item(" report", 115, 100, 10, 35, 0, { italic: true, fontName: "i" })]);
    expect(texts(m)).toEqual(["The quarterly report"]);
    expect(reasons(m)).toMatch(/soft: style change inside a sentence kept/);
  });

  it("superscripts / footnote markers stay attached to their word", () => {
    const m = buildGlyphMap([item("E=mc", 50, 100, 10, 20), item("2", 70, 96.5, 6.5, 3.25)]);
    expect(texts(m)).toEqual(["E=mc2"]);
    expect(reasons(m)).toMatch(/superscript\/subscript attached/);
  });

  it("fake-bold double strikes do not duplicate glyphs; real double letters survive", () => {
    expect(buildGlyphMap([item("Bold", 50, 100, 10, 20), item("Bold", 50.2, 100, 10, 20)]).glyphs).toHaveLength(4);
    expect(buildGlyphMap([item("ll", 50, 100, 10, 5.4)]).glyphs).toHaveLength(2);
  });

  it("Devanagari with combining marks is one unit and one word", () => {
    const m = buildGlyphMap([item("नमस्ते", 50, 100, 10, 40)]);
    expect(texts(m)).toEqual(["नमस्ते"]);
    expect(m.words).toHaveLength(1);
  });
});

describe("hard boundaries (no bleed) – each records its reason", () => {
  it("a gap > 2× font size splits (two sections on one baseline)", () => {
    const m = buildGlyphMap([item("Name: Ada", 50, 100, 10, 45), item("Total: 42", 200, 100, 10, 45)]);
    expect(texts(m)).toEqual(["Name: Ada", "Total: 42"]);
    expect(reasons(m)).toMatch(/hard: gap [\d.]+pt > 2×size/);
  });

  it("two columns: never merged across the gutter; the left column is read before the right", () => {
    const m = buildGlyphMap([item("left one", 50, 100, 10, 60), item("right one", 250, 100, 10, 70), item("left two", 50, 112, 10, 60), item("right two", 250, 112, 10, 70)]);
    expect(texts(m)).toEqual(["left one", "left two", "right one", "right two"]);
    expect(m.units.map((u) => u.columnId)).toEqual([0, 0, 1, 1]);
    expect(reasons(m)).toMatch(/hard: different column/);
  });

  it("heading next to body text on one baseline splits (font size change > 25%)", () => {
    const m = buildGlyphMap([item("Title", 50, 100, 20, 50), item("body text", 110, 100, 10, 40)]);
    expect(texts(m)).toEqual(["Title", "body text"]);
    expect(reasons(m)).toMatch(/hard: font size change 100%/);
  });

  it("rotated / skewed text is its own unit (different rotation)", () => {
    const m = buildGlyphMap([item("tilted", 50, 100, 10, 30, 0.5)]);
    expect(m.units[0].rotated).toBe(true);
    expect(reasons(m)).toMatch(/different rotation/);
  });

  it("a vertical ruling line between two cells is a hard boundary (table cell border)", () => {
    const row = [item("Name", 50, 100, 10, 22), item("Qty", 80, 100, 10, 15)];
    expect(texts(buildGlyphMap(row))).toEqual(["Name Qty"]);
    const rule: Rule = { kind: "v", x0: 76, x1: 76, y0: 90, y1: 105 };
    const m = buildGlyphMap(row, { rules: [rule] });
    expect(texts(m)).toEqual(["Name", "Qty"]);
    expect(reasons(m)).toMatch(/hard: table cell border/);
  });

  it("tabular alignment: the same column edge in ≥ 3 rows is a boundary even with a small gap (2 rows are not)", () => {
    const row = (a: string, aw: number, b: string, y: number) => [item(a, 50, y, 10, aw), item(b, 82, y, 10, 10)];
    const three = buildGlyphMap([...row("Ann", 20, "10", 100), ...row("Bob", 20, "20", 112), ...row("Cy", 14, "30", 124)]);
    expect(texts(three).sort()).toEqual(["10", "20", "30", "Ann", "Bob", "Cy"]);
    expect(reasons(three)).toMatch(/hard: tabular alignment \(3 rows/);
    const two = buildGlyphMap([...row("Ann", 20, "10", 100), ...row("Bob", 20, "20", 112)]);
    expect(texts(two).sort()).toEqual(["Ann 10", "Bob 20"]);
  });

  it("empty input is safe", () => {
    const m = buildGlyphMap([]);
    expect(m.units).toEqual([]);
    expect(unitAt(m, { x: 1, y: 1 })).toBeNull();
  });
});

describe("unit-grouping sweep – click every word, get exactly its line segment", () => {
  const items = [
    item("Quarterly Report", 50, 60, 18, 144),
    item("The quarterly report is due", 50, 100, 10, 120),
    item("on Friday afternoon", 50, 112, 10, 90),
    item("Prepared by the finance", 250, 100, 10, 110),
    item("team in March", 250, 112, 10, 70),
  ];
  const expected = ["Quarterly Report", "The quarterly report is due", "on Friday afternoon", "Prepared by the finance", "team in March"];
  const map = buildGlyphMap(items);

  it("ground truth: exactly the expected units, in reading order", () => {
    expect(texts(map)).toEqual(expected);
  });

  it("every word's centre opens ITS OWN unit: no missing words, no neighbour words", () => {
    for (const ids of map.words) {
      const g = map.glyphs[ids[Math.floor(ids.length / 2)]];
      const u = unitAt(map, inkCenter(g));
      expect(u, g.char).not.toBeNull();
      expect(u!.id).toBe(g.lineId);
      expect(u!.text).toBe(expected[g.lineId]);
    }
  });

  it("first and last glyph of every word, and the baseline edge, open the same unit", () => {
    for (const ids of map.words) {
      for (const gid of [ids[0], ids[ids.length - 1]]) {
        const g = map.glyphs[gid];
        for (const p of [{ x: g.ink.x + 0.3, y: g.baseline - 2 }, { x: g.ink.x + g.ink.w - 0.3, y: g.baseline - 2 }, { x: g.origin.x + 1, y: g.baseline + 0.5 }]) {
          expect(unitAt(map, p)?.id).toBe(g.lineId);
        }
      }
    }
  });

  it("negative: gutter, margins and the gap between lines open nothing", () => {
    for (const p of [{ x: 215, y: 97 }, { x: 5, y: 100 }, { x: 600, y: 100 }, { x: 80, y: 20 }, { x: 80, y: 103 }, { x: 225, y: 55 }]) expect(unitAt(map, p), `${p.x},${p.y}`).toBeNull();
  });

  it("the ≤ 2 pt tolerance applies along the baseline only", () => {
    const u = map.units[1];
    expect(unitAt(map, { x: u.x0 - 1.8, y: u.baseline - 3 }, 50)?.id).toBe(u.id);
    expect(unitAt(map, { x: u.x0 - 2.6, y: u.baseline - 3 }, 50)).toBeNull();
    expect(unitAt(map, { x: u.x0 + 5, y: u.baseline - 8.6 })).toBeNull(); // above the ascent band
  });

  for (const rotation of [0, 90, 180, 270]) {
    it(`same unit through canvas ↔ page at rotation ${rotation}° with a CropBox offset`, () => {
      const geo: PageGeo = { cropBox: [20, 30, 420, 530], rotation };
      for (const u of map.units) {
        const centre = { x: (u.x0 + u.x1) / 2, y: u.baseline - 0.3 * u.size };
        const page = canvasToPage(geo, 1.5, pageToCanvas(geo, 1.5, centre));
        expect(unitAt(map, page)?.id).toBe(u.id);
      }
    });
  }
});

describe("caret placement", () => {
  const map = buildGlyphMap([item("abc", 50, 100, 10, 30)]); // three glyphs, 10 pt each
  const u = map.units[0];
  it("lands on the glyph boundary nearest the click", () => {
    expect(caretIndexAt(map, u, { x: 51, y: 97 })).toBe(0);
    expect(caretIndexAt(map, u, { x: 54, y: 97 })).toBe(0);
    expect(caretIndexAt(map, u, { x: 56, y: 97 })).toBe(1);
    expect(caretIndexAt(map, u, { x: 66, y: 97 })).toBe(2);
    expect(caretIndexAt(map, u, { x: 79, y: 97 })).toBe(3);
  });
});

describe("paragraphs (optional reflow level)", () => {
  const line = (s: string, y: number) => item(s, 50, y, 10, 300);
  const map = buildGlyphMap([line("first line of the paragraph with enough words", 100), line("second line of the paragraph with enough words", 112), line("third line ends the paragraph here", 124), line("a different paragraph starts after a gap", 160), line("and continues on a second line right here", 172)]);
  it("groups consecutive lines with normal leading into a paragraph; a big gap starts a new one", () => {
    expect(map.paragraphs.map((p) => p.unitIds.length)).toEqual([3, 2]);
    expect(map.units.map((u) => u.paraId)).toEqual([0, 0, 0, 1, 1]);
    expect(map.paragraphs[0].pitch).toBeCloseTo(12, 5);
    expect(paragraphText(map, map.paragraphs[1])).toBe("a different paragraph starts after a gap and continues on a second line right here");
  });
  it("short lines (table cells, list items, headings) do not chain into a paragraph", () => {
    const m = buildGlyphMap([item("one", 50, 100, 10, 15), item("two", 50, 112, 10, 15), item("three", 50, 124, 10, 25), item("a wide line anchors the column width here", 50, 136, 10, 200)]);
    expect(m.paragraphs.length).toBeGreaterThan(1);
  });
});
