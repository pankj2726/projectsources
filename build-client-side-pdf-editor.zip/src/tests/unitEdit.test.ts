/**
 * TASKS-02 Task 2 §2.5/§2.6 – the minimal-diff commit and its guards. NOT YET RUN (no shell in the authoring environment).
 * Widths use the deterministic `estimateWidth` fallback, so assertions are invariants / inequalities, not pixel values.
 */
import { describe, expect, it } from "vitest";
import { buildGlyphMap, type RawItem, type Rule } from "../lib/text/glyphMap";
import { diffRange, effectiveParagraphText, effectiveUnitText, planParagraphEdit, planUnitEdit, rightLimit } from "../lib/text/unitEdit";
import { verifyEditedText } from "../lib/text/verifyEdit";

const cp = (s: string) => Array.from(s);
const item = (str: string, x: number, baseline: number, size = 10, w?: number): RawItem => ({ str, x, baseline, w: w ?? str.length * size * 0.5, size, angle: 0, fontName: "f", family: "sans", bold: false, italic: false });

const SENTENCE = "The quarterly report is due on Friday";
const map = buildGlyphMap([item(SENTENCE, 50, 100, 10, 190)]);
const unit = map.units[0];
const ctx = { pageId: "p1", pageW: 612 };

describe("diffRange – widen to a word only when the change is INSIDE a word", () => {
  it("replacing a whole middle word", () => {
    expect(diffRange(cp("The quarterly report"), cp("The annual report"))).toEqual({ from: 4, toOld: 13, toNew: 10 });
  });
  it("changing letters inside a word re-sets that whole word (and only it)", () => {
    expect(diffRange(cp("report"), cp("reports"))).toEqual({ from: 0, toOld: 6, toNew: 7 });
    expect(diffRange(cp("one quick fox"), cp("one quack fox"))).toEqual({ from: 4, toOld: 9, toNew: 9 });
  });
  it("pure insertion at a word boundary stays a pure insertion (no neighbour is re-set)", () => {
    expect(diffRange(cp("a b"), cp("a b c"))).toEqual({ from: 3, toOld: 3, toNew: 5 });
    expect(diffRange(cp("The quarterly"), cp("The very quarterly"))).toEqual({ from: 4, toOld: 4, toNew: 9 });
  });
  it("no change and total replacement", () => {
    expect(diffRange(cp("same"), cp("same"))).toEqual({ from: 4, toOld: 4, toNew: 4 });
    expect(diffRange(cp("cat"), cp("dog"))).toEqual({ from: 0, toOld: 3, toNew: 3 });
  });
});

describe("planUnitEdit", () => {
  it("no change → nothing (no cover, no object, no re-export)", () => {
    const r = planUnitEdit(map, unit, SENTENCE, ctx);
    expect(r).toMatchObject({ ok: true, obj: null, unchanged: true });
  });

  it("editing the LAST word covers only that word and draws the new one as one text run", () => {
    const r = planUnitEdit(map, unit, SENTENCE.replace("Friday", "Monday"), ctx);
    expect(r.ok).toBe(true);
    if (!r.ok || !r.obj) return;
    expect(r.obj.origText).toBe("Friday");
    expect(r.obj.text).toBe("Monday");
    expect(r.obj.unitKey).toBe("u0");
    expect(r.obj.covers).toHaveLength(1);
    const on = map.glyphs[unit.charGlyph[SENTENCE.indexOf("on")]];
    expect(r.obj.covers![0].x).toBeGreaterThanOrEqual(on.ink.x + on.ink.w - 1e-6); // does not reach back into unchanged words
  });

  it("INVARIANT: for every kind of edit, original-with-the-edit-applied equals the new text, and unchanged words are never covered", () => {
    const variants = [
      "The annual report is due on Friday", // middle word
      "The very quarterly report is due on Friday", // insertion
      "The quarterly report is due on Friday today", // append
      "quarterly report is due on Friday", // delete first word
      "The report is due on Friday", // delete a middle word
      "Completely different text here", // replace everything
      "The quarterly report is due on Monday", // last word
      "A The quarterly report is due on Friday", // prepend
      "The quarterly report is not due on Friday", // insert in the middle
    ];
    for (const v of variants) {
      const r = planUnitEdit(map, unit, v, ctx);
      expect(r.ok, v).toBe(true);
      if (!r.ok || !r.obj) continue;
      expect(effectiveUnitText(unit, r.obj), v).toBe(v);
      // text outside the replaced range is untouched: nothing before `unitA` is covered
      const a = r.obj.unitA!;
      const firstReal = unit.charGlyph.slice(a).find((id) => id >= 0);
      if (r.obj.covers!.length && firstReal !== undefined && a > 0) {
        const lead = [...unit.charGlyph.slice(0, a)].reverse().find((id) => id >= 0 && !map.glyphs[id].space);
        if (lead !== undefined) expect(r.obj.covers![0].x).toBeGreaterThanOrEqual(map.glyphs[lead].ink.x + map.glyphs[lead].ink.w - 1e-6);
      }
      // the output text check (verifyEdit) accepts it: replaced originals may stay hidden under the cover, nothing else
      const before = SENTENCE;
      const after = `${before} ${r.obj.text}`; // original (hidden) + new run, as pdf.js would extract it
      expect(verifyEditedText(before, after, [r.obj.origText ?? ""], [r.obj.text ?? ""]).ok, v).toBe(true);
    }
  });

  it("pure append: nothing is covered ([] means 'cover nothing', not 'use the default box')", () => {
    const r = planUnitEdit(map, unit, `${SENTENCE} today`, ctx);
    expect(r.ok && r.obj?.covers).toEqual([]);
    expect(r.ok && r.obj?.text).toBe(" today");
  });

  it("width change → ONLY the trailing words of this unit are re-set and shifted", () => {
    const r = planUnitEdit(map, unit, "The annual report is due on Friday", ctx);
    expect(r.ok).toBe(true);
    if (!r.ok || !r.obj) return;
    expect(r.obj.text?.startsWith("annual")).toBe(true);
    expect(r.obj.text?.endsWith(" report is due on Friday")).toBe(true); // trailing words come along in the same run
    expect(r.obj.unitEnd).toBe(cp(SENTENCE).length);
    expect(r.obj.unitA).toBe(4); // "The " is untouched
  });

  it("re-editing replaces the earlier edit of the same unit and can revert to the original (obj null)", () => {
    const first = planUnitEdit(map, unit, "The annual report is due on Friday", ctx);
    if (!first.ok || !first.obj) throw new Error("setup");
    expect(effectiveUnitText(unit, first.obj)).toBe("The annual report is due on Friday");
    const second = planUnitEdit(map, unit, "The annual report is due on Monday", { ...ctx, existing: first.obj });
    expect(second.ok && second.obj && effectiveUnitText(unit, second.obj)).toBe("The annual report is due on Monday");
    const back = planUnitEdit(map, unit, SENTENCE, { ...ctx, existing: first.obj });
    expect(back).toMatchObject({ ok: true, obj: null, unchanged: true });
  });

  it("guard 1: the editor's original text must match the page text", () => {
    const r = planUnitEdit(map, unit, "x", { ...ctx, origText: "something else entirely" });
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.error).toMatch(/no longer matches/);
  });

  it("rotated text is refused with an explanation", () => {
    const m = buildGlyphMap([{ ...item("tilted", 50, 100, 10, 30), angle: 0.5 }]);
    const r = planUnitEdit(m, m.units[0], "other", ctx);
    expect(r.ok).toBe(false);
  });
});

describe("guards 2 + 3 (forced failures)", () => {
  it("the cover is CLIPPED away from a neighbouring unit (never reaches non-unit glyphs)", () => {
    const rule: Rule = { kind: "v", x0: 80.2, x1: 80.2, y0: 90, y1: 105 };
    const m = buildGlyphMap([item("alpha", 50, 100, 10, 30), item("beta", 80.6, 100, 10, 20)], { rules: [rule] });
    expect(m.units.map((u) => u.text)).toEqual(["alpha", "beta"]);
    const u = m.units[0];
    const r = planUnitEdit(m, u, "omega", { ...ctx });
    expect(r.ok).toBe(true);
    if (r.ok && r.obj) {
      const right = r.obj.covers![0].x + r.obj.covers![0].w;
      expect(right).toBeLessThanOrEqual(80.6 + 1e-6);
      expect(right).toBeGreaterThanOrEqual(80 - 1e-6);
    }
  });

  it("if a neighbour overlaps the edited text itself the edit is BLOCKED and names the text in the way", () => {
    const m = buildGlyphMap([item("alpha", 50, 100, 10, 30), item("BETA", 50, 105, 10, 25)]);
    const u = m.units.find((x) => x.text === "alpha")!;
    const r = planUnitEdit(m, u, "omega", ctx);
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.error).toMatch(/BETA|overlaps/);
  });
});

describe("room: shrink-to-fit, overflow, skip (never a silent overlap)", () => {
  const tight = { ...ctx, pageW: 250 };
  const long = "The quarterly report is due on Wednesday afternoon";
  it("too long and shrinking would go below the minimum → error that offers 'allow overflow'", () => {
    const r = planUnitEdit(map, unit, long, tight);
    expect(r.ok).toBe(false);
    if (!r.ok) {
      expect(r.canOverflow).toBe(true);
      expect(r.error).toMatch(/No room/);
    }
  });
  it("shrinks when the minimum scale allows it", () => {
    const r = planUnitEdit(map, unit, long, { ...tight, minScale: 0.05 });
    expect(r.ok).toBe(true);
    if (r.ok && r.obj) {
      expect(r.obj.fontSize!).toBeLessThan(10);
      expect(r.notes.join(" ")).toMatch(/Shrunk/);
    }
  });
  it("allow-overflow keeps the size and says so; 'skip' refuses", () => {
    const over = planUnitEdit(map, unit, long, { ...tight, allowOverflow: true });
    expect(over.ok && over.obj?.fontSize).toBe(10);
    expect(over.ok && over.notes.join(" ")).toMatch(/runs past/);
    const skip = planUnitEdit(map, unit, long, { ...tight, overflow: "skip" });
    expect(skip.ok).toBe(false);
  });
  it("the right limit is the next unit on the row, else the page margin", () => {
    const m = buildGlyphMap([item("left part", 50, 100, 10, 45), item("far right", 300, 100, 10, 45)]);
    expect(rightLimit(m, m.units[0], 612)).toBeCloseTo(298, 5);
    expect(rightLimit(m, m.units[1], 612)).toBe(594);
  });
});

describe("paragraph (reflow) mode", () => {
  const line = (s: string, y: number) => item(s, 50, y, 10, 300);
  const base = [line("first line of the paragraph with enough words", 100), line("second line of the paragraph with enough words", 112), line("third line ends the paragraph here", 124)];
  it("replaces the whole paragraph by ONE wrapped text object with the original leading", () => {
    const m = buildGlyphMap(base);
    const para = m.paragraphs[0];
    const r = planParagraphEdit(m, para, `${effectiveParagraphText(m, para)} and a little more text`, ctx);
    expect(r.ok).toBe(true);
    if (r.ok && r.obj) {
      expect(r.obj.unitKey).toBe("p0");
      expect(r.obj.covers).toHaveLength(3);
      expect(r.obj.lineHeight).toBeCloseTo(12, 5);
      expect(r.obj.text).toContain("\n");
      expect(effectiveParagraphText(m, para, r.obj)).toContain("a little more text");
    }
  });
  it("blocks when extra lines would collide with content below it", () => {
    const m = buildGlyphMap([...base, item("FOOTER", 50, 150, 20, 100)]);
    const para = m.paragraphs.find((p) => m.units[p.unitIds[0]].text.startsWith("first"))!;
    const r = planParagraphEdit(m, para, `${effectiveParagraphText(m, para)} and a lot more text so that it needs another line or two`, ctx);
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.error).toMatch(/Not enough room/);
  });
  it("no change → nothing", () => {
    const m = buildGlyphMap(base);
    expect(planParagraphEdit(m, m.paragraphs[0], effectiveParagraphText(m, m.paragraphs[0]), ctx)).toMatchObject({ ok: true, obj: null });
  });
});
