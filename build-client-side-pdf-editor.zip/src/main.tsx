import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";
import { useEditor } from "./lib/model/docState";
import { useEditSession } from "./lib/text/editSession";

// Test hook for Playwright (tests/e2e/*): only exposed when the page is opened with ?e2e=1. Exposes the stores, no file data.
if (/[?&]e2e=1/.test(window.location.search)) (window as unknown as { __qf: unknown }).__qf = { useEditor, useEditSession };

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
