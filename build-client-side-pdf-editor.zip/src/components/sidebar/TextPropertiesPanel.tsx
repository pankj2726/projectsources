import { useState, type ReactNode } from "react";
import { focusEditor, markSidebarPointer, useEditSession } from "../../lib/text/editSession";
import { FAMILY_LABEL, cps, familyFromLabel, normalizeHex, rangeValue, type CaseMode, type RunKey } from "../../lib/text/styleModel";
import type { RunStyle, TextAlign } from "../../lib/model/objects";
import { cn } from "../../utils/cn";
import { buzz } from "../../lib/mobile/haptics";
import { input as inputCls } from "../ui";
import { EditTextHelp } from "./EditTextHelp";

/**
 * Text properties sidebar (F44). Opens in the SAME tick as the inline editor, stays open for the whole edit session, never
 * depends on hover, and never steals the editor's focus:
 *  - pointer-down on any non-field control is cancelled, so the editor keeps focus (and its selection);
 *  - fields (inputs / selects / textareas) take focus legitimately, and the editor's blur handler ignores a blur that moves
 *    INTO this panel (`data-text-sidebar`) or follows a pointer-down inside it;
 *  - after a control is used, focus returns to the editor with the selection restored.
 */

const round = (n: number, d = 1) => Math.round(n * 10 ** d) / 10 ** d;

function useCollapsed(id: string): [boolean, (v: boolean) => void] {
  const KEY = "qf-text-collapsed";
  const read = (): Record<string, boolean> => {
    try {
      return JSON.parse(localStorage.getItem(KEY) ?? "{}") as Record<string, boolean>;
    } catch {
      return {};
    }
  };
  const [closed, setClosed] = useState<boolean>(() => !!read()[id]);
  return [
    closed,
    (v) => {
      setClosed(v);
      try {
        localStorage.setItem(KEY, JSON.stringify({ ...read(), [id]: v }));
      } catch {
        /* ignore */
      }
    },
  ];
}

function Group({ id, title, children }: { id: string; title: string; children: ReactNode }) {
  const [closed, setClosed] = useCollapsed(id);
  return (
    <section className="border-b border-slate-200 dark:border-slate-700" data-group={id}>
      <h3>
        <button type="button" aria-expanded={!closed} className="flex w-full items-center justify-between px-4 py-2 text-left text-[11px] font-semibold tracking-wider text-slate-500 uppercase hover:text-indigo-700" onClick={() => setClosed(!closed)}>
          <span>{title}</span>
          <span aria-hidden="true">{closed ? "▸" : "▾"}</span>
        </button>
      </h3>
      {!closed && <div className="space-y-2 px-4 pb-3">{children}</div>}
    </section>
  );
}

function Tog({ label, pressed, onClick, children, disabled, title }: { label: string; pressed?: boolean | "mixed"; onClick: () => void; children: ReactNode; disabled?: boolean; title?: string }) {
  const on = pressed === true;
  return (
    <button
      type="button"
      aria-label={label}
      aria-pressed={pressed}
      title={title ? `${title}${disabled ? " (formatting locked)" : ""}` : label}
      disabled={disabled}
      onClick={() => {
        if (disabled) return; // locked: the control is inert and explains why through its title
        onClick();
        focusEditor();
      }}
      className={cn("inline-flex min-w-8 items-center justify-center rounded-lg border px-2 py-1 text-sm disabled:opacity-40", on ? "border-indigo-600 bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-100" : pressed === "mixed" ? "border-dashed border-slate-400" : "border-slate-300 bg-white hover:border-indigo-300 dark:border-slate-600 dark:bg-slate-800")}
    >
      {children}
    </button>
  );
}

function Num({ label, value, mixed, onChange, step = 1, min, max, disabled, title }: { label: string; value: number; mixed?: boolean; onChange: (n: number) => void; step?: number; min?: number; max?: number; disabled?: boolean; title?: string }) {
  const [draft, setDraft] = useState<string | null>(null);
  return (
    <label className="flex items-center gap-2 text-xs" title={title}>
      <span className="w-24 shrink-0 text-slate-500">{label}</span>
      <input
        aria-label={label}
        type="number"
        inputMode="decimal"
        className={cn(inputCls, "!py-1")}
        value={draft ?? (mixed ? "" : String(round(value, 2)))}
        placeholder={mixed ? "Mixed" : undefined}
        step={step}
        min={min}
        max={max}
        disabled={disabled}
        onChange={(e) => {
          setDraft(e.target.value);
          const n = parseFloat(e.target.value);
          if (Number.isFinite(n) && (min === undefined || n >= min) && (max === undefined || n <= max)) onChange(n);
        }}
        onBlur={() => setDraft(null)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            setDraft(null);
            focusEditor();
          }
        }}
      />
    </label>
  );
}

function useModel() {
  const session = useEditSession((s) => s.session);
  const defaults = useEditSession((s) => s.defaults);
  const patchRun = useEditSession((s) => s.patchRun);
  const setDefaults = useEditSession((s) => s.setDefaults);
  const dRun: RunStyle = { family: defaults.family, size: defaults.size, bold: defaults.bold, italic: defaults.italic, underline: defaults.underline, strike: defaults.strike, script: "none", color: defaults.color };
  if (session) {
    const len = cps(session.text).length;
    return {
      session,
      get: <K extends RunKey>(k: K) => rangeValue(len, session.base, session.spans, session.sel.a, session.sel.b, k),
      set: (p: Partial<RunStyle>) => patchRun(p),
    };
  }
  return {
    session: null,
    get: <K extends RunKey>(k: K) => ({ value: dRun[k], mixed: false }),
    set: (p: Partial<RunStyle>) => {
      const { script: _s, ...rest } = p;
      void _s;
      setDefaults(rest);
    },
  };
}

export function TextPropertiesPanel({ sheet }: { sheet?: boolean }) {
  const m = useModel();
  const locked = useEditSession((s) => s.session?.locked ?? false);
  const rememberUnlock = useEditSession((s) => s.rememberUnlock);
  const [askUnlock, setAskUnlock] = useState(false);
  /** The sidebar's Enter commits the edit; the layer owns the commit, so it is asked to do it (same path as its own Enter). */
  const commitFromSidebar = () => window.dispatchEvent(new CustomEvent("qf-commit-edit"));
  const s = m.session;
  const defaults = useEditSession((st) => st.defaults);
  const recent = useEditSession((st) => st.recent);
  const patchExtras = useEditSession((st) => st.patchExtras);
  const setDefaults = useEditSession((st) => st.setDefaults);
  const [family, setFamily] = useState<string | null>(null);
  const [hex, setHex] = useState<string | null>(null);

  const fam = m.get("family");
  const size = m.get("size");
  const color = m.get("color");
  const bold = m.get("bold");
  const italic = m.get("italic");
  const underline = m.get("underline");
  const strike = m.get("strike");
  const script = m.get("script");
  const pressed = (r: { value: boolean; mixed: boolean }): boolean | "mixed" => (r.mixed ? "mixed" : r.value);
  const ex = s?.extras;
  const align: TextAlign = s ? ex!.align : defaults.align;
  const isUnit = s?.kind === "unit";
  const act = (name: string) => window.dispatchEvent(new CustomEvent("qf-text-action", { detail: name }));
  const caseTo = (mode: CaseMode) => window.dispatchEvent(new CustomEvent("qf-text-case", { detail: mode }));
  const hasEyeDropper = typeof window !== "undefined" && "EyeDropper" in window;
  const pickScreenColor = async () => {
    try {
      const Ctor = (window as unknown as { EyeDropper: new () => { open(): Promise<{ sRGBHex: string }> } }).EyeDropper;
      const r = await new Ctor().open();
      m.set({ color: r.sRGBHex });
    } catch {
      /* cancelled */
    }
    focusEditor();
  };
  const setAlign = (a: TextAlign) => (s ? patchExtras({ align: a }) : setDefaults({ align: a }));
  const keepFocus = (e: React.SyntheticEvent) => {
    if ((e.target as HTMLElement).closest("input,select,textarea,label")) return; // real fields must be able to take focus
    e.preventDefault();
  };
  const det = s?.detected;
  const changedFromDetected = !!s && s.base.family === s.detected.style.family && s.base.bold === s.detected.style.bold && s.base.italic === s.detected.style.italic;

  return (
    <div
      data-text-sidebar
      data-testid="text-sidebar"
      data-mode={s ? "editing" : "defaults"}
      data-detected-size={det ? round(det.style.size, 2) : undefined}
      data-detected-color={det?.color}
      data-detected-font={det?.fontLabel}
      role="complementary"
      aria-label="Text properties"
      className={cn("text-sm", sheet && "max-h-[52vh] overflow-y-auto rounded-t-2xl border-t border-slate-300 bg-slate-50 shadow-2xl dark:border-slate-600 dark:bg-slate-900")}
      onPointerDownCapture={markSidebarPointer}
      onPointerDown={keepFocus}
      onMouseDown={keepFocus}
      onKeyDown={(e) => {
        if (e.key === "Escape") focusEditor();
      }}
    >
      <div className="border-b border-slate-200 px-4 py-3 dark:border-slate-700">
        <div className="flex items-center gap-2">
          <h2 className="text-sm font-semibold">{s ? "Edited text" : "Text"}</h2>
          {s && (
            <button
              type="button"
              onClick={() => {
                buzz("toggle");
                if (locked) setAskUnlock(true);
                else useEditSession.getState().setLocked(true);
              }}
              aria-pressed={!locked}
              className={cn("ml-auto inline-flex h-8 items-center gap-1 rounded-full px-2.5 text-xs font-semibold", locked ? "bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300" : "bg-indigo-600 text-white")}
              data-testid="sidebar-lock"
              title={locked ? "Formatting locked: only characters change" : "Formatting unlocked"}
            >
              <span aria-hidden="true">{locked ? "🔒" : "🔓"}</span>
              {locked ? "Locked" : "Unlocked"}
            </button>
          )}
        </div>
        {s && locked && <p className="mt-1 text-xs text-slate-500">Original formatting is locked – only the characters change. Unlock to restyle.</p>}
        {askUnlock && (
          <div role="alertdialog" aria-label="Unlock formatting" className="animate-pop mt-2 rounded-xl border border-amber-300 bg-amber-50 p-2.5 text-xs text-amber-900 dark:border-amber-800 dark:bg-amber-950 dark:text-amber-100">
            <p>Unlock formatting for this edit? Font, size, colour and position will no longer follow the original.</p>
            <div className="mt-2 flex flex-wrap gap-2">
              <button type="button" className="rounded-lg bg-amber-700 px-2.5 py-1 font-semibold text-white" onClick={() => { useEditSession.getState().setLocked(false); setAskUnlock(false); focusEditor(); }}>
                Unlock
              </button>
              <label className="flex items-center gap-1.5">
                <input type="checkbox" checked={rememberUnlock} onChange={(e) => useEditSession.getState().setRememberUnlock(e.target.checked)} /> Remember
              </label>
              <button type="button" className="ml-auto rounded-lg border border-amber-400 px-2.5 py-1" onClick={() => setAskUnlock(false)}>Keep locked</button>
            </div>
          </div>
        )}
        <p className="mt-0.5 truncate text-xs text-slate-500" data-testid="text-sidebar-target">
          {s ? `${s.kind === "para" ? "Paragraph" : "Line"}: “${s.text.slice(0, 40)}${s.text.length > 40 ? "…" : ""}”` : "Defaults for the next new text box"}
        </p>
        {s && (s.sel.a !== s.sel.b ? <p className="mt-1 text-xs text-indigo-700">Applies to the {s.sel.b - s.sel.a} selected character(s)</p> : <p className="mt-1 text-xs text-slate-500">No selection: applies to the whole line and new typing</p>)}
      </div>

      {s && (
        <Group id="text" title="Text">
          <textarea
            aria-label="Edit text content"
            data-testid="sidebar-text"
            spellCheck={false}
            className={cn(inputCls, "min-h-24 resize-y font-mono")}
            value={s.text}
            onChange={(e) => useEditSession.getState().setTextFromSidebar(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !(s.kind === "para" && e.shiftKey)) {
                e.preventDefault(); // Enter commits the whole edit, as on the page
                commitFromSidebar();
              } else if (e.key === "Escape") focusEditor();
            }}
          />
          <div className="flex items-center justify-between gap-2 text-xs">
            <span className="truncate text-slate-500" title={s.orig}>
              Original: “{s.orig.length > 24 ? `${s.orig.slice(0, 24)}…` : s.orig}”
            </span>
            <button type="button" className="shrink-0 text-indigo-700 underline disabled:opacity-40 disabled:no-underline" aria-label="Reset text to the original" disabled={s.text === s.orig} onClick={() => { useEditSession.getState().setTextFromSidebar(s.orig); focusEditor(); }}>
              Reset
            </button>
          </div>
        </Group>
      )}

      <Group id="font" title="Font">
        <div>
          <input
            aria-label="Font family"
            list="pf-font-families"
            className={cn(inputCls, "!py-1")}
            value={family ?? (fam.mixed ? "" : FAMILY_LABEL[fam.value])}
            placeholder={fam.mixed ? "Mixed" : "Search fonts…"}
            onChange={(e) => {
              setFamily(e.target.value);
              const f = familyFromLabel(e.target.value);
              if (f) m.set({ family: f });
            }}
            onBlur={() => setFamily(null)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                setFamily(null);
                focusEditor();
              }
            }}
          />
          <datalist id="pf-font-families">
            {Object.values(FAMILY_LABEL).map((l) => (
              <option key={l} value={l} />
            ))}
          </datalist>
        </div>
        {det && (
          <p className="text-xs text-slate-600 dark:text-slate-300" data-testid="detected-font">
            Original: <strong>{det.fontLabel || "unknown"}</strong>{" "}
            {det.substituted && <span className="rounded bg-amber-100 px-1 text-[10px] font-semibold text-amber-900" title="The built-in fonts cannot reproduce this typeface, so the closest one is used">substituted</span>}{" "}
            {det.fontEstimated && <span className="rounded bg-slate-200 px-1 text-[10px] text-slate-700 dark:bg-slate-700 dark:text-slate-200">estimated</span>}
          </p>
        )}
        <div className="flex items-center gap-1">
          <Tog label="Decrease font size" onClick={() => m.set({ size: Math.max(1, round(size.value - 1, 1)) })}>
            −
          </Tog>
          <div className="flex-1">
            <Num label="Font size" value={size.value} mixed={size.mixed} min={1} max={400} step={0.5} onChange={(n) => m.set({ size: n })} />
          </div>
          <Tog label="Increase font size" onClick={() => m.set({ size: Math.min(400, round(size.value + 1, 1)) })}>
            ＋
          </Tog>
        </div>
        {s && (
          <button type="button" className="text-xs text-indigo-700 underline disabled:opacity-40 disabled:no-underline" disabled={changedFromDetected && !size.mixed && size.value === s.detected.style.size} onClick={() => { useEditSession.getState().matchOriginalFont(); m.set({ size: s.detected.style.size }); focusEditor(); }}>
            Match original
          </button>
        )}
      </Group>

      <Group id="style" title="Style">
        <div className="flex flex-wrap gap-1" role="group" aria-label="Character style">
          <Tog label="Bold" pressed={pressed(bold)} onClick={() => m.set({ bold: !bold.value || bold.mixed })} title="Bold (Ctrl/Cmd+B)">
            <b>B</b>
          </Tog>
          <Tog label="Italic" pressed={pressed(italic)} onClick={() => m.set({ italic: !italic.value || italic.mixed })} title="Italic (Ctrl/Cmd+I)">
            <i>I</i>
          </Tog>
          <Tog label="Underline" pressed={pressed(underline)} onClick={() => m.set({ underline: !underline.value || underline.mixed })} title="Underline (Ctrl/Cmd+U)">
            <u>U</u>
          </Tog>
          <Tog label="Strikethrough" pressed={pressed(strike)} onClick={() => m.set({ strike: !strike.value || strike.mixed })}>
            <s>S</s>
          </Tog>
          <Tog label="Superscript" pressed={script.mixed ? "mixed" : script.value === "sup"} onClick={() => m.set({ script: script.value === "sup" && !script.mixed ? "none" : "sup" })} disabled={!s}>
            x²
          </Tog>
          <Tog label="Subscript" pressed={script.mixed ? "mixed" : script.value === "sub"} onClick={() => m.set({ script: script.value === "sub" && !script.mixed ? "none" : "sub" })} disabled={!s}>
            x₂
          </Tog>
        </div>
      </Group>

      <Group id="color" title="Color">
        <div className="flex items-center gap-2">
          <input type="color" aria-label="Text colour" className="h-8 w-10 shrink-0 cursor-pointer rounded border border-slate-300" value={color.mixed ? "#000000" : color.value} onChange={(e) => m.set({ color: e.target.value })} />
          <input
            aria-label="Text colour hex"
            className={cn(inputCls, "!py-1 font-mono")}
            value={hex ?? (color.mixed ? "" : color.value)}
            placeholder={color.mixed ? "Mixed" : "#rrggbb"}
            maxLength={24}
            onChange={(e) => {
              setHex(e.target.value);
              const h = normalizeHex(e.target.value);
              if (h) m.set({ color: h });
            }}
            onBlur={() => setHex(null)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                setHex(null);
                focusEditor();
              }
            }}
          />
          {hasEyeDropper && (
            <Tog label="Pick colour from screen" onClick={() => void pickScreenColor()}>
              ◉
            </Tog>
          )}
        </div>
        {det?.colorEstimated && !color.mixed && color.value === det.color && <p className="text-xs text-slate-500">Colour is <span className="rounded bg-slate-200 px-1 text-[10px] dark:bg-slate-700">estimated</span> from the page pixels.</p>}
        {recent.length > 0 && (
          <div className="flex flex-wrap items-center gap-1" role="group" aria-label="Recent colours">
            {recent.map((c) => (
              <button key={c} type="button" aria-label={`Use recent colour ${c}`} title={c} className="h-5 w-5 rounded border border-slate-300" style={{ background: c }} onClick={() => { m.set({ color: c }); focusEditor(); }} />
            ))}
          </div>
        )}
        {s && (
          <label className="flex items-center gap-2 text-xs">
            <span className="w-24 shrink-0 text-slate-500">Highlight / background</span>
            <input type="color" aria-label="Background fill" className="h-7 w-10 cursor-pointer rounded border border-slate-300" value={ex!.bg} onChange={(e) => patchExtras({ bg: e.target.value })} />
            <button type="button" className="text-indigo-700 underline" aria-label="Reset background fill" onClick={() => { patchExtras({ bg: s.detectedExtras.bg }); focusEditor(); }}>
              Auto
            </button>
          </label>
        )}
        <label className="flex items-center gap-2 text-xs">
          <span className="w-24 shrink-0 text-slate-500">Opacity {Math.round((s ? ex!.opacity : defaults.opacity) * 100)}%</span>
          <input type="range" aria-label="Opacity" className="w-full" min={0.05} max={1} step={0.05} value={s ? ex!.opacity : defaults.opacity} onChange={(e) => (s ? patchExtras({ opacity: Number(e.target.value) }) : setDefaults({ opacity: Number(e.target.value) }))} />
        </label>
      </Group>

      <Group id="paragraph" title="Paragraph">
        <div className="flex gap-1" role="group" aria-label="Alignment">
          <Tog label="Align left" pressed={align === "left"} onClick={() => setAlign("left")} disabled={isUnit} title={isUnit ? "Alignment applies to text boxes and paragraphs, not a single line in place" : "Align left"}>
            ⇤
          </Tog>
          <Tog label="Align center" pressed={align === "center"} onClick={() => setAlign("center")} disabled={isUnit} title={isUnit ? "Alignment applies to text boxes and paragraphs, not a single line in place" : "Align center"}>
            ↔
          </Tog>
          <Tog label="Align right" pressed={align === "right"} onClick={() => setAlign("right")} disabled={isUnit} title={isUnit ? "Alignment applies to text boxes and paragraphs, not a single line in place" : "Align right"}>
            ⇥
          </Tog>
          <Tog label="Justify" pressed={align === "justify"} onClick={() => setAlign("justify")} disabled={isUnit} title={isUnit ? "Alignment applies to text boxes and paragraphs, not a single line in place" : "Justify"}>
            ☰
          </Tog>
        </div>
        {s && (
          <>
            <Num label="Line spacing" value={ex!.lineHeight / Math.max(1, s.base.size)} min={0.6} max={4} step={0.05} disabled={isUnit} title={isUnit ? "Line spacing applies to paragraph mode" : "Multiple of the font size"} onChange={(n) => patchExtras({ lineHeight: n * s.base.size })} />
            <Num label="Character spacing" value={ex!.charSpacing} min={-5} max={50} step={0.1} onChange={(n) => patchExtras({ charSpacing: n })} />
            <Num label="Word spacing" value={ex!.wordSpacing} min={-10} max={100} step={0.5} onChange={(n) => patchExtras({ wordSpacing: n })} />
            <div className="flex flex-wrap gap-1" role="group" aria-label="Case">
              <Tog label="UPPERCASE" onClick={() => caseTo("upper")}>AA</Tog>
              <Tog label="lowercase" onClick={() => caseTo("lower")}>aa</Tog>
              <Tog label="Title Case" onClick={() => caseTo("title")}>Aa</Tog>
            </div>
          </>
        )}
      </Group>

      {s && (
        <>
          <Group id="box" title="Box">
            <div className="grid grid-cols-2 gap-x-2 gap-y-1">
              <Num label="Offset X" value={ex!.dx} step={0.5} onChange={(n) => patchExtras({ dx: n })} />
              <Num label="Offset Y" value={ex!.dy} step={0.5} onChange={(n) => patchExtras({ dy: n })} />
            </div>
            <Num label="Box width" value={ex!.boxW ?? s.boxW} min={4} max={2000} step={1} title={isUnit ? "Width of the text box. A line narrower than its text shrinks to fit (down to 60%)." : "Width of the paragraph: the text reflows to it."} onChange={(n) => patchExtras({ boxW: n })} />
            <p className="flex flex-wrap items-center gap-x-3 text-xs text-slate-500">
              <span>
                Height <output aria-label="Box height">{round(s.boxH)}</output> pt (follows the text)
              </span>
              <button type="button" className="text-indigo-700 underline disabled:opacity-40 disabled:no-underline" aria-label="Automatic box width" disabled={ex!.boxW === null} onClick={() => { patchExtras({ boxW: null }); focusEditor(); }}>
                Auto width
              </button>
            </p>
            <Num label="Rotation" value={ex!.rotation} step={1} min={-360} max={360} onChange={(n) => patchExtras({ rotation: n })} />
            <div className="flex flex-wrap gap-1">
              <Tog label="Bring to front" onClick={() => act("front")}>⤒</Tog>
              <Tog label="Send to back" onClick={() => act("back")}>⤓</Tog>
              <Tog label="Lock position" pressed={ex!.locked} onClick={() => patchExtras({ locked: !ex!.locked })}>🔒</Tog>
              <Tog label="Duplicate text" onClick={() => act("duplicate")}>⧉</Tog>
              <Tog label="Delete text edit" onClick={() => act("delete")}>🗑</Tog>
            </div>
          </Group>
          <Group id="actions" title="Actions">
            <div className="flex flex-wrap gap-1">
              <Tog label="Undo format change" onClick={() => useEditSession.getState().undo()} disabled={!s.past.length}>↶</Tog>
              <Tog label="Redo format change" onClick={() => useEditSession.getState().redo()} disabled={!s.future.length}>↷</Tog>
              <Tog label="Reset formatting" onClick={() => useEditSession.getState().resetFormatting()}>Reset</Tog>
            </div>
          </Group>
        </>
      )}

      {!s && (
        <div className="px-4 py-3 text-xs text-slate-600 dark:text-slate-300">
          <EditTextHelp />
        </div>
      )}
      {s && (
        <p className="px-4 py-3 text-xs text-slate-600 dark:text-slate-300" data-testid="cover-note">
          Cover-and-replace: the original words are covered with the sampled background (<code>{s.detectedExtras.bg}</code>) and replaced with real text. Complex layouts or subset fonts may not match exactly – use <strong>Redact</strong> to remove text permanently.
        </p>
      )}
    </div>
  );
}
