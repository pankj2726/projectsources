import { useUi } from "../../lib/model/ui";

/** Edit-text help + the two settings (both OFF by default). */
export function EditTextHelp() {
  const hover = useUi((s) => s.hoverHighlight);
  const para = useUi((s) => s.paragraphMode);
  const setHover = useUi((s) => s.setHoverHighlight);
  const setPara = useUi((s) => s.setParagraphMode);
  return (
    <div className="space-y-3">
      <p>
        <strong>Click any text</strong> – its whole line opens in an inline editor straight away, with the caret where you clicked. <kbd>Enter</kbd> saves, <kbd>Esc</kbd> cancels, <kbd>Ctrl/Cmd+Z</kbd> undoes the whole edit.
      </p>
      <ul className="list-disc space-y-1 pl-5 text-xs">
        <li>Only the words you change are touched; unchanged words stay exactly where they are.</li>
        <li>Text in another column, table cell or section never joins in.</li>
        <li>If the new text is wider, only the rest of that line moves. No room? You are told, and can shrink it or allow overflow.</li>
      </ul>
      <label className="flex items-start gap-2 text-xs">
        <input type="checkbox" className="mt-0.5" checked={para} onChange={(e) => setPara(e.target.checked)} />
        <span>
          <strong>Edit whole paragraph</strong> (reflow). A click opens the paragraph; <kbd>Shift+Enter</kbd> adds a line break.
        </span>
      </label>
      <label className="flex items-start gap-2 text-xs">
        <input type="checkbox" className="mt-0.5" checked={hover} onChange={(e) => setHover(e.target.checked)} />
        <span>Highlight editable text on hover (off by default).</span>
      </label>
      <p className="text-xs text-slate-500">Edits cover the old words and write real text on top (cover-and-replace). The covered original stays in the file's text layer – use Redact to remove text permanently.</p>
    </div>
  );
}
