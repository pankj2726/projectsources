import { cssFont } from "../../lib/fonts/fontMap";
import type { FontFamily, PdfObject } from "../../lib/model/objects";
import { layoutRuns, type RunMeasure } from "../../lib/text/styleModel";

let ctx: CanvasRenderingContext2D | null = null;
/** Canvas measurement (Arial / Times New Roman / Courier New ≈ Helvetica / Times / Courier metrics). */
export const runMeasure: RunMeasure = (text, f) => {
  if (!ctx) ctx = document.createElement("canvas").getContext("2d")!;
  ctx.font = cssFont(f.family, f.bold, f.italic, f.size);
  return ctx.measureText(text).width;
};

export const familyCss = (f: FontFamily): string => (f === "serif" ? '"Times New Roman", Times, serif' : f === "mono" ? '"Courier New", Courier, monospace' : 'Helvetica, Arial, "Liberation Sans", sans-serif');

/**
 * SVG rendering of a text / textedit object with per-run styles. Uses the SAME layout function as the PDF export
 * (`layoutRuns`), so the preview and the downloaded file agree on positions, spacing, underline and sub/superscripts.
 */
export function TextRuns({ o }: { o: PdfObject }) {
  const L = layoutRuns(o, runMeasure);
  return (
    <g opacity={o.opacity} data-testid="text-runs">
      {L.lines.map((ln, k) =>
        ln.runs
          .filter((r) => r.text !== "")
          .map((r, j) => {
            const y = o.y + ln.baseline - r.rise;
            const x0 = o.x + r.x;
            const w = Math.max(0.5, r.size / 16);
            return (
              <g key={`${k}-${j}`}>
                <text x={x0} y={y} fill={r.style.color} fontSize={r.size} style={{ fontFamily: familyCss(r.style.family), fontWeight: r.style.bold ? 700 : 400, fontStyle: r.style.italic ? "italic" : "normal", whiteSpace: "pre", letterSpacing: r.charSpacing, wordSpacing: r.wordSpacing }}>
                  {r.text}
                </text>
                {r.style.underline && <line x1={x0} x2={x0 + r.width} y1={y + r.size * 0.12} y2={y + r.size * 0.12} stroke={r.style.color} strokeWidth={w} />}
                {r.style.strike && <line x1={x0} x2={x0 + r.width} y1={y - r.size * 0.3} y2={y - r.size * 0.3} stroke={r.style.color} strokeWidth={w} />}
              </g>
            );
          })
      )}
    </g>
  );
}
