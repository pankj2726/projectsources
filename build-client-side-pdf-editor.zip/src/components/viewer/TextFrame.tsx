import { useRef, useState } from "react";
import {
  BORDER_HIT_PX,
  BORDER_LABEL,
  FRAME_PAD_PX,
  GRIP_OFFSET_PX,
  GRIP_PX,
  HANDLES,
  HANDLE_PX,
  MOVE_LABEL,
  OUTER_STROKE_PX,
  ROTATE_LABEL,
  ROTATE_OFFSET_PX,
  STROKE_PX,
  cursorFor,
  type Box,
  type HandleId,
} from "../../lib/text/frameGeometry";
import { focusEditor, markChromePointer } from "../../lib/text/editSession";
import type { Pt } from "../../lib/text/glyphMap";

export const FRAME_ACCENT = "#c15f3c";
/** Rotate cursor (white halo + dark arrow so it reads on any background); `grab` is the fallback where data-URI cursors are blocked. */
const ROTATE_CURSOR = `url("data:image/svg+xml;utf8,${encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><g fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M18.5 12a6.5 6.5 0 1 1-1.9-4.6M18.5 4.5v3.8h-3.8" stroke="#fff" stroke-width="4"/><path d="M18.5 12a6.5 6.5 0 1 1-1.9-4.6M18.5 4.5v3.8h-3.8" stroke="#141413" stroke-width="2"/></g></svg>'
)}") 12 12, grab`;

export type FrameGesture = "resize" | "rotate" | "move";

export interface TextFrameProps {
  /** the active unit's box in page space (WITHOUT the visual padding) */
  box: Box;
  /** the point the text rotates about */
  pivot: Pt;
  /** text rotation, clockwise degrees */
  rotation: number;
  /** page rotation + view rotation, used only to pick the right resize cursors */
  pageRotation: number;
  zoom: number;
  /** page → screen matrix of the page (includes zoom and page rotation) */
  matrix: number[];
  width: number;
  height: number;
  kind: "unit" | "para";
  /** TASKS-03 Task D: while the formatting is locked, the handles do nothing (prevents accidental thumb drags) */
  locked?: boolean;
  toPage(e: { clientX: number; clientY: number }): Pt;
  onBegin(kind: FrameGesture, handle: HandleId | null, p: Pt): void;
  onDrag(kind: FrameGesture, handle: HandleId | null, p: Pt, shift: boolean): void;
  onEnd(): void;
  /** unit screen direction + step in pt */
  onNudge(sx: number, sy: number, stepPt: number): void;
}

/**
 * The ACTIVE text box (F45): a frame with 8 resize handles, a rotate handle, a move grip and a draggable border.
 * It exists only while an edit is open, only for that unit, never on hover. Drawn in screen-constant pixels (1.5 px line with
 * a white halo) above everything else on the page. The border and handles capture the pointer; the interior does not, so
 * clicks reach the inline editor and the caret / selection work as usual. Nothing here is ever exported.
 */
export function TextFrame(p: TextFrameProps) {
  const [focused, setFocused] = useState(false);
  const z = p.zoom;
  const pad = FRAME_PAD_PX / z;
  const hs = HANDLE_PX / z;
  const sw = STROKE_PX / z;
  const x = p.box.x - pad;
  const y = p.box.y - pad;
  const w = p.box.w + 2 * pad;
  const h = p.box.h + 2 * pad;
  const cx = x + w / 2;
  const total = p.pageRotation + p.rotation;
  const rotY = y - ROTATE_OFFSET_PX / z;

  /**
   * Pointer plumbing shared by every draggable part. Pointer capture means no window listeners exist, so nothing can leak.
   * `dragging` (not the capture state) decides whether a gesture is open, so a capture the browser drops mid-drag still ends
   * the gesture instead of leaving the session stuck in "gesture" mode (which would stop later changes being recorded).
   */
  const dragging = useRef(false);
  const finish = (e: React.PointerEvent<SVGElement>) => {
    if (!dragging.current) return;
    dragging.current = false;
    try {
      if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {
      /* already released */
    }
    p.onEnd();
  };
  const drag = (kind: FrameGesture, handle: HandleId | null) => ({
    onPointerDown: (e: React.PointerEvent<SVGElement>) => {
      if (e.button !== 0 || dragging.current) return;
      e.preventDefault(); // keep focus in the editor
      e.stopPropagation(); // never reaches the page's click-to-edit layer
      markChromePointer();
      dragging.current = true;
      e.currentTarget.setPointerCapture(e.pointerId);
      p.onBegin(kind, handle, p.toPage(e));
    },
    onPointerMove: (e: React.PointerEvent<SVGElement>) => {
      if (!dragging.current) return;
      p.onDrag(kind, handle, p.toPage(e), e.shiftKey);
    },
    onPointerUp: finish,
    onPointerCancel: finish,
    onLostPointerCapture: finish,
    onMouseDown: (e: React.MouseEvent) => e.preventDefault(),
    style: { touchAction: "none" } as const,
  });

  const onKeyDown = (e: React.KeyboardEvent) => {
    const step = e.shiftKey ? 10 : 1; // arrow keys nudge 1 pt, 10 pt with Shift
    const dir: Record<string, [number, number]> = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] };
    if (dir[e.key]) {
      e.preventDefault();
      e.stopPropagation(); // the editor's global arrow-key nudge of selected objects must not also fire
      p.onNudge(dir[e.key][0], dir[e.key][1], step);
    } else if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      focusEditor();
    }
  };

  return (
    <svg
      data-text-frame
      data-testid="text-frame"
      data-kind={p.kind}
      data-box-x={p.box.x.toFixed(2)}
      data-box-y={p.box.y.toFixed(2)}
      data-box-w={p.box.w.toFixed(2)}
      data-box-h={p.box.h.toFixed(2)}
      data-rotation={p.rotation}
      className="absolute inset-0"
      width={p.width}
      height={p.height}
      style={{ overflow: "visible", pointerEvents: "none" }}
      role="group"
      aria-label="Text box"
    >
      <g transform={`matrix(${p.matrix.join(" ")})`}>
        <g transform={p.rotation ? `rotate(${p.rotation} ${p.pivot.x} ${p.pivot.y})` : undefined}>
          {/* white halo + accent line: visible on dark, light and image backgrounds. The interior is NOT a hit target. */}
          <rect x={x} y={y} width={w} height={h} fill="none" stroke="#ffffff" strokeWidth={OUTER_STROKE_PX / z} pointerEvents="none" data-testid="frame-halo" />
          <rect x={x} y={y} width={w} height={h} fill="none" stroke={FRAME_ACCENT} strokeWidth={sw} pointerEvents="none" data-testid="frame-outline" />
          {focused && <rect x={x - 3 / z} y={y - 3 / z} width={w + 6 / z} height={h + 6 / z} fill="none" stroke={FRAME_ACCENT} strokeWidth={sw} strokeDasharray={`${4 / z} ${3 / z}`} pointerEvents="none" />}

          {/* border: drag to move; keyboard-focusable, arrow keys nudge */}
          <rect
            x={x}
            y={y}
            width={w}
            height={h}
            fill="none"
            stroke="transparent"
            strokeWidth={BORDER_HIT_PX / z}
            pointerEvents="stroke"
            tabIndex={0}
            role="group"
            aria-label={BORDER_LABEL}
            data-testid="frame-border"
            onKeyDown={onKeyDown}
            onFocus={() => setFocused(true)}
            onBlur={() => setFocused(false)}
            {...drag("move", null)}
            style={{ cursor: "move", outline: "none", touchAction: "none" }}
          />

          {/* rotate handle (Shift snaps to 15°) */}
          <line x1={cx} y1={y} x2={cx} y2={rotY} stroke={FRAME_ACCENT} strokeWidth={sw} pointerEvents="none" />
          <circle cx={cx} cy={rotY} r={6 / z} fill={p.locked ? "#e8e6dc" : "#ffffff"} stroke={p.locked ? "#b1ada1" : FRAME_ACCENT} strokeWidth={sw} pointerEvents="all" role="button" aria-label={p.locked ? `${ROTATE_LABEL} (formatting locked)` : ROTATE_LABEL} aria-disabled={p.locked || undefined} data-testid="frame-rotate" data-locked={p.locked ? "1" : undefined} {...drag("rotate", null)} style={{ cursor: p.locked ? "not-allowed" : ROTATE_CURSOR, touchAction: "none" }} />

          {/* move grip */}
          <g transform={`translate(${x - GRIP_OFFSET_PX / z} ${y + h / 2 - GRIP_PX / 2 / z})`} pointerEvents="all" role="button" aria-label={MOVE_LABEL} data-testid="frame-move-grip" {...drag("move", null)} style={{ cursor: "move", touchAction: "none" }}>
            <rect width={GRIP_PX / z} height={GRIP_PX / z} rx={3 / z} fill="#ffffff" stroke={FRAME_ACCENT} strokeWidth={sw} />
            {[0, 1, 2].map((r) => [0, 1].map((c) => <circle key={`${r}${c}`} cx={(GRIP_PX * (0.33 + 0.34 * c)) / z} cy={(GRIP_PX * (0.25 + 0.25 * r)) / z} r={1.1 / z} fill={FRAME_ACCENT} />))}
          </g>

          {/* 8 resize handles */}
          {HANDLES.map((hd) => (
            <rect
              key={hd.id}
              x={x + w * hd.hx - hs / 2}
              y={y + h * hd.hy - hs / 2}
              width={hs}
              height={hs}
              rx={1.5 / z}
              fill="#ffffff"
              stroke={FRAME_ACCENT}
              strokeWidth={sw}
              pointerEvents="all"
              role="button"
              aria-label={hd.label}
              data-testid={`frame-handle-${hd.id}`}
              {...drag("resize", hd.id)}
              style={{ cursor: cursorFor(hd.id, total), touchAction: "none" }}
            />
          ))}
        </g>
      </g>
    </svg>
  );
}
