import { useCallback, useEffect, useRef } from "react";
import { useEditor } from "../../lib/model/docState";
import {
  clampZoom,
  distance,
  focalOf,
  isTap,
  MAX_ZOOM_FOR_TIER,
  memoryTier,
  midpoint,
  nearFit,
  rubberBand,
  scrollAfterZoom,
  scrollForFocal,
  DOUBLE_TAP_MS,
  DOUBLE_TAP_ZOOM,
  fitWidthZoom,
  type Focal,
} from "../../lib/mobile/gestures";
import { hapticsEnabled, buzz } from "../../lib/mobile/haptics";

export interface PinchOptions {
  /** ref of the native scroll container (the viewer) */
  root: React.RefObject<HTMLElement | null>;
  /** ref of the element that gets the CSS transform during a gesture (the pages wrapper) */
  content: React.RefObject<HTMLElement | null>;
  /** widest page width in pt, for fit-width / double-tap */
  widestPt: number;
  /** when true, one-finger drags move the caret instead of panning, and the frame handles win */
  editing: boolean;
  /** page points under the screen centre, to anchor viewport (keyboard / URL bar) changes */
  onViewportAnchor?: (get: () => { x: number; y: number } | null, restore: (p: { x: number; y: number }) => void) => void;
  onTapEmpty?: () => void;
}

interface Live {
  pointers: Map<number, { clientX: number; clientY: number }>;
  startDist: number;
  baseZoom: number;
  focal: Focal | null;
  panning: boolean;
  moved: number;
  downAt: number;
  lastTap: number;
  ratio: number;
  gestures: number;
}

const clamp01 = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

/**
 * Pinch-to-zoom + double-tap (TASKS-03 Task B, F47).
 *
 * During a gesture ONLY the wrapper's CSS transform changes (I2): no zoom state update, no re-render, no font re-measure.
 * On gesture end the real zoom is committed and the scroll is set so the focal point stays where it was (I7), then the
 * wrapper transform is cleared and the pages re-render crisply (I3 as far as this architecture allows: render.ts already
 * renders offscreen and blits, so there is no white flash).
 */
export function usePinchZoom(o: PinchOptions) {
  const live = useRef<Live>({ pointers: new Map(), startDist: 0, baseZoom: 1, focal: null, panning: false, moved: 0, downAt: 0, lastTap: 0, ratio: 1, gestures: 0 });
  const opt = useRef(o);
  opt.current = o;

  const applyTransform = useCallback(
    (ratio: number, f: Focal | null) => {
      const c = opt.current.content.current;
      if (!c) return;
      if (ratio === 1 || !f) {
        c.style.transform = "";
        c.style.transformOrigin = "";
        c.style.willChange = "";
        return;
      }
      c.style.transformOrigin = `${f.x}px ${f.y}px`;
      c.style.transform = `scale(${ratio})`;
      c.style.willChange = "transform";
    },
    []
  );

  const commit = useCallback(
    (ratio: number, f: Focal | null) => {
      const root = opt.current.root.current;
      applyTransform(1, null);
      if (!f || !root) return;
      const base = live.current.baseZoom;
      const target = clampZoom(base * ratio, MAX_ZOOM_FOR_TIER[memoryTier((navigator as { deviceMemory?: number }).deviceMemory)]);
      const s = scrollAfterZoom(f, base, target);
      useEditor.setState({ zoom: target, fitWidth: false });
      root.scrollLeft = s.scrollX;
      root.scrollTop = s.scrollY;
      if (hapticsEnabled()) buzz("toggle");
    },
    [applyTransform]
  );

  // ---- viewport anchoring (I6): keyboard open/close, URL bar, rotation, split-screen ----
  useEffect(() => {
    const vv = typeof window !== "undefined" ? window.visualViewport : undefined;
    if (!vv) return;
    let saved: { scrollX: number; scrollY: number } | null = null;
    const onResize = () => {
      const root = opt.current.root.current;
      if (!root) return;
      // Remember the scroll offset BEFORE the layout viewport changes (keyboard, URL bar, rotation, split-screen).
      // Zoom is unchanged by these, so restoring the same scroll offset keeps the anchored PDF point in place (I6).
      if (!saved) saved = { scrollX: root.scrollLeft, scrollY: root.scrollTop };
      // the layout has already been re-flowed: put the same content back at the same place
      requestAnimationFrame(() => {
        const r2 = opt.current.root.current;
        if (!r2 || !saved) return;
        r2.scrollLeft = saved.scrollX;
        r2.scrollTop = saved.scrollY;
      });
    };
    const onScrollEnd = () => {
      saved = null;
    };
    vv.addEventListener("resize", onResize);
    vv.addEventListener("scroll", onScrollEnd);
    return () => {
      vv.removeEventListener("resize", onResize);
      vv.removeEventListener("scroll", onScrollEnd);
    };
  }, []);

  const fit = useCallback(() => fitWidthZoom(opt.current.widestPt, opt.current.root.current?.clientWidth ?? 0), []);

  const zoomBy = useCallback((factor: number) => {
    const root = opt.current.root.current;
    if (!root) return;
    const st = useEditor.getState();
    const base = st.zoom;
    const target = clampZoom(base * factor);
    const f = focalOf(root.clientWidth / 2, root.clientHeight / 2, { left: 0, top: 0 }, root.scrollLeft, root.scrollTop);
    const s = scrollAfterZoom(f, base, target);
    useEditor.setState({ zoom: target, fitWidth: false });
    root.scrollLeft = s.scrollX;
    root.scrollTop = s.scrollY;
  }, []);

  const toggleFit = useCallback(
    (clientX?: number, clientY?: number) => {
      const root = opt.current.root.current;
      if (!root) return;
      const st = useEditor.getState();
      const fz = fit();
      const target = nearFit(st.zoom, fz) ? clampZoom(DOUBLE_TAP_ZOOM) : fz;
      const rect = root.getBoundingClientRect();
      const cx = clientX ?? rect.left + rect.width / 2;
      const cy = clientY ?? rect.top + rect.height / 2;
      const f = focalOf(cx, cy, { left: rect.left, top: rect.top }, root.scrollLeft, root.scrollTop);
      const s = scrollAfterZoom(f, st.zoom, target);
      useEditor.setState({ zoom: target, fitWidth: false });
      root.scrollLeft = s.scrollX;
      root.scrollTop = s.scrollY;
      if (hapticsEnabled()) buzz("toggle");
    },
    [fit]
  );

  const onPointerDown = useCallback((e: React.PointerEvent) => {
    const L = live.current;
    L.pointers.set(e.pointerId, { clientX: e.clientX, clientY: e.clientY });
    if (L.pointers.size === 1) {
      L.moved = 0;
      L.downAt = e.timeStamp;
      L.ratio = 1;
      L.panning = true;
    } else if (L.pointers.size === 2) {
      const [a, b] = [...L.pointers.values()];
      L.startDist = distance(a, b);
      L.baseZoom = useEditor.getState().zoom;
      const root = opt.current.root.current!;
      const mid = midpoint(a, b);
      const rect = root.getBoundingClientRect();
      L.focal = focalOf(mid.x, mid.y, { left: rect.left, top: rect.top }, root.scrollLeft, root.scrollTop);
      L.panning = false;
      L.gestures++;
    }
  }, []);

  const onPointerMove = useCallback(
    (e: React.PointerEvent) => {
      const L = live.current;
      if (!L.pointers.has(e.pointerId)) return;
      const prev = L.pointers.get(e.pointerId)!;
      L.moved += Math.hypot(e.clientX - prev.clientX, e.clientY - prev.clientY);
      L.pointers.set(e.pointerId, { clientX: e.clientX, clientY: e.clientY });
      if (L.pointers.size < 2 || !L.focal) return;
      const [a, b] = [...L.pointers.values()];
      const d = distance(a, b);
      if (L.startDist < 12) return;
      const ratio = clamp01(d / L.startDist, 0.4, 4);
      L.ratio = ratio;
      // a second finger landing during a one-finger pan must not jump: re-anchor the focal point to the current midpoint
      const root = opt.current.root.current!;
      const mid = midpoint(a, b);
      const rect = root.getBoundingClientRect();
      const f = focalOf(mid.x, mid.y, { left: rect.left, top: rect.top }, root.scrollLeft, root.scrollTop);
      L.focal = f;
      applyTransform(ratio, f);
      const s = scrollForFocal(f, ratio);
      root.scrollLeft = s.scrollX;
      root.scrollTop = s.scrollY;
    },
    [applyTransform]
  );

  const onPointerUp = useCallback(
    (e: React.PointerEvent) => {
      const L = live.current;
      if (!L.pointers.delete(e.pointerId)) return;
      const root = opt.current.root.current;
      if (L.pointers.size === 1) {
        // one finger lifted from a pinch: continue as a pan without a jump
        const [a] = [...L.pointers.values()];
        const rect = root!.getBoundingClientRect();
        L.focal = focalOf(a.clientX, a.clientY, { left: rect.left, top: rect.top }, root!.scrollLeft, root!.scrollTop);
        applyTransform(1, null);
        L.startDist = 0;
        L.panning = true;
        return;
      }
      if (L.pointers.size > 0) return;
      if (L.gestures > 0 && L.ratio !== 1) {
        commit(L.ratio, L.focal);
        L.gestures = 0;
        L.ratio = 1;
        return;
      }
      // ---- single-pointer release: tap detection (Task C.1) ----
      const ms = e.timeStamp - L.downAt;
      if (root && isTap({ moved: L.moved, ms, fingers: 1 })) {
        const rect = root.getBoundingClientRect();
        const inside = e.clientX >= rect.left && e.clientX <= rect.right && e.clientY >= rect.top && e.clientY <= rect.bottom;
        if (inside) {
          const now = e.timeStamp;
          const dbl = now - L.lastTap < DOUBLE_TAP_MS;
          L.lastTap = now;
          // A tap on TEXT is handled by the text layer (which stops propagation) and must never be delayed.
          // Only taps on EMPTY area fall through to here, so a double-tap costs nothing.
          if (dbl) {
            L.lastTap = 0;
            toggleFit(e.clientX, e.clientY);
          }
        }
      }
      L.panning = false;
    },
    [applyTransform, commit, toggleFit]
  );

  const onPointerCancel = useCallback(() => {
    const L = live.current;
    L.pointers.clear();
    L.gestures = 0;
    L.ratio = 1;
    applyTransform(1, null);
  }, [applyTransform]);

  return { onPointerDown, onPointerMove, onPointerUp, onPointerCancel, zoomBy, toggleFit, fit };
}

/** Rubber-band clamp for a scroll container (soft resistance at the ends, clamped on release). */
export function useRubberBand(root: React.RefObject<HTMLElement | null>) {
  useEffect(() => {
    const el = root.current;
    if (!el) return;
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const maxX = el.scrollWidth - el.clientWidth;
        const maxY = el.scrollHeight - el.clientHeight;
        const ox = el.scrollLeft < 0 ? el.scrollLeft : el.scrollLeft > maxX ? el.scrollLeft - maxX : 0;
        const oy = el.scrollTop < 0 ? el.scrollTop : el.scrollTop > maxY ? el.scrollTop - maxY : 0;
        if (!ox && !oy) return;
        el.style.overscrollBehavior = "contain";
        if (el.scrollLeft < 0 || el.scrollLeft > maxX) el.scrollLeft = ox > 0 ? maxX + rubberBand(ox, maxX) : rubberBand(ox, maxX);
        if (el.scrollTop < 0 || el.scrollTop > maxY) el.scrollTop = oy > 0 ? maxY + rubberBand(oy, maxY) : rubberBand(oy, maxY);
      });
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      el.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(raf);
    };
  }, [root]);
}
