import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type RefObject } from "react";
import { duplicateObjects, reorderZ, replaceObjects, type PageModel } from "../../lib/model/commands";
import { canvasToPage, pageMatrix, pageToCanvas, type PageGeo } from "../../lib/model/coords";
import { useEditor } from "../../lib/model/docState";
import { useUi } from "../../lib/model/ui";
import { createObject, wrapText, type PdfObject, type RunStyle, type Span } from "../../lib/model/objects";
import { sampleRunColors } from "../../lib/pdf/render";
import { caretIndexAt, unitAt, type LineInfo, type Pt, type Rect } from "../../lib/text/glyphMap";
import { getGlyphMap, type PageMap } from "../../lib/text/pageText";
import { effectiveParagraphText, effectiveUnitSpans, effectiveUnitText, planParagraphEdit, planUnitEdit, rightLimit, unitTextWidth, type Measure, type StyleInput } from "../../lib/text/unitEdit";
import { baseStyleOf, cps, cpToU16, rangeValue, transformCase, type CaseMode } from "../../lib/text/styleModel";
import { isWinAnsi } from "../../lib/fonts/fontMap";
import { tapSlopPt } from "../../lib/mobile/gestures";
import { registerEditorFocus, sidebarRecentlyUsed, styleDiffersFromOriginal, styleDirty, useEditSession, type Detected, type Extras } from "../../lib/text/editSession";
import { FRAME_PAD_PX, frameBox, insideBox, pivotOf, resizeBy, rotateTo, type Box, type HandleId, type ResizeStart } from "../../lib/text/frameGeometry";
import { measure as canvasMeasure } from "./textLayout";
import { TextRuns, familyCss } from "./TextRuns";
import { TextFrame, type FrameGesture } from "./TextFrame";

const measure: Measure = (t, size, st) => canvasMeasure({ family: st.family, bold: st.bold, italic: st.italic, fontSize: size }, t);
const spaceCount = (s: string) => (s.match(/ /g) ?? []).length;

interface Active {
  key: string;
  kind: "unit" | "para";
  id: number;
  text: string;
  /** effective text when the editor opened (guard 1 compares it with the page text) */
  orig: string;
  /** caret in UTF-16 units */
  caret: number;
  existing: PdfObject | null;
  colors: { bg: string; fg: string };
  /** the unit's / paragraph's ORIGINAL rect (1 pt inset around its line band) */
  rect: Rect;
  /** origin x of the first glyph, ink top and ink height of the first line, first baseline */
  x0: number;
  top: number;
  leadH: number;
  baseline: number;
  /** font size the page itself uses (the frame scales relative to it) */
  detSize: number;
  /** paragraph: original text width; unit: the width of the ORIGINAL text as the canvas measures it (the frame grows / shrinks by the difference) */
  origW: number;
  natural0: number;
  limit: number;
  letterSpacing: number;
  error: string | null;
  canOverflow: boolean;
}

interface FrameState {
  box: Box;
  pivot: Pt;
  rotation: number;
  kind: "unit" | "para";
  natural: number;
}

interface Gesture {
  kind: FrameGesture;
  handle: HandleId | null;
  p0: Pt;
  start: ResizeStart;
  startBase: RunStyle;
  startSpans: Span[];
  dx0: number;
  dy0: number;
  rotation0: number;
}

const UNIT_COLORS = ["#c15f3c", "#2f7d6b", "#7a5ca8", "#b08a2e", "#3b78a8", "#a8405c"];

/**
 * Edit-text mode. The EDIT UNIT is the line segment. No hover UI: hit-testing runs on pointerdown only (touch: on tap) and
 * ONE click opens, in the same tick: the inline editor, the text sidebar (edit session) and the ACTIVE TEXT BOX frame (F45).
 * The frame exists only for the active unit; commit is a minimal diff (lib/text/unitEdit.ts) that also carries the formatting,
 * position, rotation and width set through the sidebar or the frame.
 */
export function TextEditLayer({ page, geo, zoom, width, height, canvasRef }: { page: PageModel; objects: PdfObject[]; geo: PageGeo; zoom: number; width: number; height: number; canvasRef: RefObject<HTMLCanvasElement | null> }) {
  const doc = useEditor((s) => s.doc);
  const hoverHighlight = useUi((s) => s.hoverHighlight);
  const paragraphMode = useUi((s) => s.paragraphMode);
  const sess = useEditSession((s) => s.session);
  const [map, setMap] = useState<PageMap | null>(null);
  const [state, setState] = useState<"loading" | "ready" | "none">("loading");
  const [active, setActiveState] = useState<Active | null>(null);
  const [hover, setHover] = useState<LineInfo | null>(null);
  const [probe, setProbe] = useState<Pt | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const inputRef = useRef<HTMLInputElement & HTMLTextAreaElement>(null);
  const activeRef = useRef<Active | null>(null);
  const mapRef = useRef<PageMap | null>(null);
  const touch = useRef<{ x: number; y: number; t: number } | null>(null);
  const composing = useRef(false);
  const lastCommitted = useRef<PdfObject | null>(null);
  const frameRef = useRef<FrameState | null>(null);
  const gesture = useRef<Gesture | null>(null);
  const debug = useMemo(() => /[?&]debug=text/.test(window.location.href), []);
  const m = pageMatrix(geo, zoom);
  const pageW = Math.abs(page.cropBox[2] - page.cropBox[0]);
  const pageH = Math.abs(page.cropBox[3] - page.cropBox[1]);

  const setActive = (a: Active | null) => {
    activeRef.current = a;
    setActiveState(a);
  };
  const closeSession = () => {
    gesture.current = null;
    setActive(null);
    useEditSession.getState().end(); // the frame and the sidebar are driven by this session: they go with it
    registerEditorFocus(null);
    /**
     * AUDIT FIX (undo/redo): the editor and the sidebar's Text box are real form fields. If focus stays in one of them
     * after the edit closes, Ctrl/Cmd+Z is treated as "typing" by the editor's shortcut handler and the browser undoes
     * the text inside that (now unused) box instead of the document edit – which looks exactly like "undo does nothing".
     * So focus is moved out to the viewer, where Ctrl/Cmd+Z / Ctrl+Shift+Z reach the document command stack.
     */
    const el = document.activeElement as HTMLElement | null;
    if (el && el !== document.body && (el.dataset.testid === "inline-editor" || el.dataset.testid === "sidebar-text" || el.closest("[data-text-sidebar]"))) el.blur();
    document.querySelector<HTMLElement>('[data-testid="viewer"]')?.focus({ preventScroll: true });
  };

  /** Return focus to the inline editor with its caret / selection restored (the sidebar and the frame call this after use). */
  const focusSelf = useCallback(() => {
    const el = inputRef.current;
    const s = useEditSession.getState().session;
    if (!el || !s) return;
    el.focus({ preventScroll: true });
    try {
      el.setSelectionRange(s.selU16.s, s.selU16.e);
    } catch {
      /* not a text control yet */
    }
  }, []);

  useEffect(() => {
    let alive = true;
    setState("loading");
    if (!page.sourceId || !doc) {
      setMap(null);
      mapRef.current = null;
      setState("none");
      return;
    }
    getGlyphMap(doc.sources[page.sourceId], page.srcIndex, page.cropBox)
      .then((g) => {
        if (!alive) return;
        mapRef.current = g;
        setMap(g);
        setState(g.glyphs.length ? "ready" : "none");
      })
      .catch(() => alive && (setMap(null), setState("none")));
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page.id, page.sourceId, page.srcIndex]);

  const toPage = (e: { clientX: number; clientY: number }): Pt => {
    const r = svgRef.current!.getBoundingClientRect();
    return canvasToPage(geo, zoom, { x: e.clientX - r.left, y: e.clientY - r.top });
  };

  /** Commit the open editor (minimal diff + the sidebar's formatting). Returns false when it stays open because of an error. */
  const commit = (allowOverflow = false): boolean => {
    const a = activeRef.current;
    const mp = mapRef.current;
    if (!a || !mp) return true;
    const store = useEditSession.getState();
    const sn = store.session && store.session.key === a.key ? store.session : null;
    lastCommitted.current = null;
    // the session is the single source of truth for the text: the sidebar's Text box and the on-page editor both write to it
    const cur = sn ? sn.text : a.text;
    if (cur === a.orig && !(sn && styleDirty(sn))) {
      closeSession(); // no change: no cover, no re-export
      return true;
    }
    let style: StyleInput | undefined;
    if (sn) {
      const d = styleDiffersFromOriginal(sn);
      const e = sn.extras;
      style = { base: sn.base, spans: sn.spans, baseChanged: d.baseChanged, extras: { bg: e.bg, opacity: e.opacity, charSpacing: e.charSpacing, wordSpacing: e.wordSpacing, dx: e.dx, dy: e.dy, rotation: e.rotation, locked: e.locked, align: e.align, lineHeight: e.lineHeight, boxW: e.boxW } };
    }
    const st = useEditor.getState();
    const ctx = { pageId: page.id, pageW, colors: a.colors, existing: a.existing, overflow: "shrink" as const, allowOverflow, measure, style };
    const res = a.kind === "unit" ? planUnitEdit(mp, mp.units[a.id], cur, { ...ctx, origText: a.orig }) : planParagraphEdit(mp, mp.paragraphs[a.id], cur, ctx);
    // (the sidebar's Text box writes to the session, so `cur` above is what the user last typed in either place)
    if (!res.ok) {
      setActive({ ...a, error: res.error, canOverflow: !!res.canOverflow });
      return false;
    }
    const remove = a.existing ? [a.existing.id] : [];
    if (res.obj || remove.length) st.exec(replaceObjects(remove, res.obj ? [res.obj] : [], "Edit text")); // one undo step for the whole edit
    lastCommitted.current = res.obj;
    for (const n of res.notes) st.toast("info", n);
    closeSession();
    return true;
  };
  const commitRef = useRef(commit);
  commitRef.current = commit;

  // Events from other layers / the sidebar. Unmounting (tool change) commits too, and never leaves a session or a frame behind.
  useEffect(() => {
    const onCommit = () => void commitRef.current();
    const onAction = (e: Event) => {
      const act = (e as CustomEvent<string>).detail;
      const a = activeRef.current;
      if (!a) return;
      const st = useEditor.getState();
      if (act === "delete") {
        if (a.existing) st.exec(replaceObjects([a.existing.id], [], "Delete text edit"));
        closeSession();
        return;
      }
      if (!commitRef.current()) return;
      const o = lastCommitted.current;
      if (!o) return;
      if (act === "front" || act === "back") st.exec(reorderZ([o.id], act));
      else if (act === "duplicate") {
        const r = duplicateObjects([o.id]);
        st.exec(r.cmd);
        useEditor.setState({ selection: r.newIds });
      }
    };
    const onCase = (e: Event) => {
      const mode = (e as CustomEvent<CaseMode>).detail;
      const a = activeRef.current;
      const sn = useEditSession.getState().session;
      if (!a || !sn) return;
      const cp = cps(a.text);
      const from = sn.sel.a === sn.sel.b ? 0 : sn.sel.a;
      const to = sn.sel.a === sn.sel.b ? cp.length : sn.sel.b;
      const nt = cp.slice(0, from).join("") + transformCase(cp.slice(from, to).join(""), mode) + cp.slice(to).join("");
      setActive({ ...a, text: nt, error: null });
      useEditSession.getState().setText(nt);
      setTimeout(focusSelf, 0);
    };
    window.addEventListener("qf-commit-edit", onCommit);
    window.addEventListener("qf-text-action", onAction);
    window.addEventListener("qf-text-case", onCase);
    return () => {
      window.removeEventListener("qf-commit-edit", onCommit);
      window.removeEventListener("qf-text-action", onAction);
      window.removeEventListener("qf-text-case", onCase);
      void commitRef.current();
      if (activeRef.current) {
        activeRef.current = null; // commit refused (e.g. no room) but the tool is going away: drop the session with it
        useEditSession.getState().end();
        registerEditorFocus(null);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const open = (u: LineInfo, p: Pt) => {
    const mp = mapRef.current;
    if (!mp) return;
    const st = useEditor.getState();
    const edits = st.doc!.objects.filter((o) => o.pageId === page.id && o.type === "textedit"); // fresh: never stale after a commit
    const para = mp.paragraphs[u.paraId];
    const paraExisting = para ? (edits.find((o) => o.unitKey === `p${para.id}`) ?? null) : null;
    const asPara = !!para && (!!paraExisting || paragraphMode);
    if (asPara && !paraExisting && para.unitIds.some((id) => edits.some((o) => o.unitKey === `u${id}`))) {
      st.toast("info", "This paragraph already has line edits. Undo them first, or switch off paragraph mode.");
      return;
    }
    const units = asPara ? para.unitIds.map((i) => mp.units[i]) : [u];
    const lead: LineInfo = units[0];
    const existing = asPara ? paraExisting : (edits.find((o) => o.unitKey === `u${u.id}`) ?? null);
    const text = asPara ? effectiveParagraphText(mp, para, paraExisting) : effectiveUnitText(u, existing);
    const sampleRect: Rect = asPara ? para.bbox : { x: u.x0, y: Math.min(u.bbox.y, u.baseline - 0.8 * u.size), w: u.x1 - u.x0, h: Math.max(u.bbox.y + u.bbox.h, u.baseline + 0.2 * u.size) - Math.min(u.bbox.y, u.baseline - 0.8 * u.size) };
    const rect: Rect = asPara ? { x: para.bbox.x - 1, y: lead.bbox.y - 1, w: para.bbox.w + 2, h: para.bbox.h + 2 } : { x: sampleRect.x - 1, y: sampleRect.y - 1, w: sampleRect.w + 2, h: sampleRect.h + 2 };
    const x0 = Math.min(...units.map((q) => q.x0));
    const origW = Math.max(...units.map((q) => q.x1)) - x0;

    // ---- detected properties of the clicked unit (never defaults) ----
    const firstGlyph = mp.glyphs[lead.glyphIds.find((id) => !mp.glyphs[id].space) ?? lead.glyphIds[0]];
    const item = mp.items[firstGlyph.itemIndex];
    let sampled = { bg: "#ffffff", fg: "#000000" };
    const canvas = canvasRef.current;
    if (canvas && canvas.width > 1) {
      const c0 = pageToCanvas(geo, zoom, { x: sampleRect.x, y: sampleRect.y });
      const c1 = pageToCanvas(geo, zoom, { x: sampleRect.x + sampleRect.w, y: sampleRect.y + sampleRect.h });
      const k = canvas.width / width;
      sampled = sampleRunColors(canvas, Math.min(c0.x, c1.x) * k, Math.min(c0.y, c1.y) * k, Math.abs(c1.x - c0.x) * k, Math.abs(c1.y - c0.y) * k); // the canvas shows the ORIGINAL page, even under an earlier edit
    }
    const fg = item?.color ?? sampled.fg;
    const detStyle: RunStyle = { family: lead.family, size: lead.size, bold: lead.bold, italic: lead.italic, underline: false, strike: false, script: "none", color: fg };
    const detected: Detected = { fontLabel: item?.fontLabel ?? "", substituted: item?.substituted ?? false, fontEstimated: !item?.fontLabel, sizeEstimated: false, color: fg, colorEstimated: !item?.color, style: detStyle };
    const detectedExtras: Extras = { bg: sampled.bg, opacity: 1, align: "left", lineHeight: asPara ? para.pitch : lead.size * 1.2, charSpacing: 0, wordSpacing: 0, dx: 0, dy: 0, rotation: 0, locked: false, boxW: null };
    const base: RunStyle = existing ? baseStyleOf(existing) : detStyle;
    const extras: Extras = existing
      ? { bg: existing.bg ?? sampled.bg, opacity: existing.opacity, align: existing.align ?? "left", lineHeight: existing.lineHeight ?? detectedExtras.lineHeight, charSpacing: existing.charSpacing ?? 0, wordSpacing: existing.wordSpacing ?? 0, dx: existing.dx ?? 0, dy: existing.dy ?? 0, rotation: existing.rotation, locked: !!existing.locked, boxW: asPara && Math.abs(existing.w - origW) > 0.5 ? existing.w : null }
      : detectedExtras;
    const spans = existing && !asPara ? effectiveUnitSpans(u, existing) : [];
    const caretCp = !asPara && u.text === text ? caretIndexAt(mp, u, p) : cps(text).length;
    const caret = cpToU16(text, caretCp);
    const key = `${asPara ? "p" : "u"}${asPara ? para.id : u.id}:${Date.now()}`;
    const natural0 = asPara ? 0 : unitTextWidth(text, base, spans, extras, measure);
    const letterSpacing = asPara ? 0 : Math.max(-0.06 * base.size, Math.min(0.15 * base.size, (rect.w - 2 - natural0) / Math.max(1, cps(text).length))); // match the original width so entering edit mode does not shift the text

    useEditSession.getState().begin({ key, pageId: page.id, kind: asPara ? "para" : "unit", unitId: asPara ? para.id : u.id, text, orig: text, detected, detectedExtras, base, spans, extras, sel: { a: caretCp, b: caretCp }, selU16: { s: caret, e: caret }, boxW: rect.w, boxH: rect.h, hasExisting: !!existing });
    registerEditorFocus(focusSelf);
    setActive({ key, kind: asPara ? "para" : "unit", id: asPara ? para.id : u.id, text, orig: text, caret, existing, colors: { bg: sampled.bg, fg }, rect, x0, top: lead.bbox.y, leadH: lead.bbox.h, baseline: lead.baseline, detSize: lead.size, origW, natural0, limit: asPara ? pageW : rightLimit(mp, u, pageW), letterSpacing, error: null, canOverflow: false });
  };

  const go = (e: { clientX: number; clientY: number }) => {
    const mp = mapRef.current;
    if (!mp) return;
    const p = toPage(e);
    // the interior of the ACTIVE text box belongs to the inline editor (a click there must not commit and reopen the same line)
    const f = frameRef.current;
    if (f && activeRef.current && insideBox(p, f.box, f.pivot, f.rotation, FRAME_PAD_PX / zoom)) {
      focusSelf();
      return;
    }
    window.dispatchEvent(new Event("qf-commit-edit")); // commits the open editor (this page or another) before anything else
    if (debug) setProbe(p);
    if (activeRef.current || useEditSession.getState().session) return; // a commit was refused (e.g. no room): stay in that editor, its message explains why
    // fat-finger tolerance (Task C.1): a screen-space slop converted through the zoom, so a thumb hits the line it aimed at
    const u = unitAt(mp, p, tapSlopPt(10, zoom));
    if (!u) return; // blank space / gutter / margin: commit + close, nothing opens
    open(u, p);
  };

  const onPointerDown = (e: React.PointerEvent<SVGSVGElement>) => {
    if (e.button !== 0) return;
    if (e.pointerType === "touch") {
      touch.current = { x: e.clientX, y: e.clientY, t: e.timeStamp }; // a scroll gesture must not open an editor: decide on pointerup
      return;
    }
    go(e);
  };
  const onPointerUp = (e: React.PointerEvent<SVGSVGElement>) => {
    const t = touch.current;
    touch.current = null;
    if (t && Math.hypot(e.clientX - t.x, e.clientY - t.y) < 10 && e.timeStamp - t.t < 300) go(e); // a tap (Task C.1)
  };
  const onPointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!hoverHighlight || !mapRef.current || e.pointerType === "touch") return; // OFF by default: no hit-test on mousemove
    setHover(unitAt(mapRef.current, toPage(e), 2));
  };

  // focus + caret as soon as the editor is in the DOM (also retried next frame for browsers that steal focus on mousedown)
  const key = active?.key;
  useLayoutEffect(() => {
    const el = inputRef.current;
    const a = activeRef.current;
    if (!el || !a) return;
    el.focus({ preventScroll: true });
    el.setSelectionRange(a.caret, a.caret);
    const id = requestAnimationFrame(() => {
      if (document.activeElement !== el && activeRef.current?.key === a.key && !sidebarRecentlyUsed()) {
        el.focus({ preventScroll: true });
        el.setSelectionRange(a.caret, a.caret);
      }
    });
    return () => cancelAnimationFrame(id);
  }, [key]);

  const regions = useMemo(() => (map ? map.units.filter((u) => !u.rotated).map((u) => `M${u.x0 - 1} ${u.baseline - 0.8 * u.size}h${u.x1 - u.x0 + 2}v${u.size}h${-(u.x1 - u.x0 + 2)}z`).join("") : ""), [map]);

  /** Task D: blocked browser rich-text / formatting intents, and plain-text-only paste (spec §D.1). */
  const BLOCKED_INPUT = new Set(["formatBold", "formatItalic", "formatUnderline", "formatStrikeThrough", "formatSuperscript", "formatSubscript", "formatFontColor", "formatBackColor", "formatFontName", "formatFontSize", "insertHorizontalRule", "insertOrderedList", "insertUnorderedList", "historyUndo", "historyRedo"]);
  const onBeforeInput = (e: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const t = (e.nativeEvent as InputEvent).inputType;
    if (t && BLOCKED_INPUT.has(t)) e.preventDefault();
  };
  const onPaste = (e: React.ClipboardEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    // rich paste is blocked: plain text only, and the style at the caret is inherited (never a browser style)
    e.preventDefault();
    const text = e.clipboardData.getData("text/plain");
    const el = e.currentTarget;
    const s = el.selectionStart ?? 0;
    const en = el.selectionEnd ?? s;
    const next = `${el.value.slice(0, s)}${text}${el.value.slice(en)}`;
    setActive({ ...active!, error: null });
    useEditSession.getState().setText(next);
    const at = s + text.length;
    requestAnimationFrame(() => {
      el.setSelectionRange(at, at);
      useEditSession.getState().setSel(at, at);
    });
  };
  /**
   * IME composition (Task C.4): while Gboard / Samsung Keyboard / Devanagari IMEs compose, the value is theirs.
   * Updating React state mid-composition re-renders the input and loses or duplicates characters, so the model is only
   * synced on compositionend.
   */
  const onCompositionStart = () => {
    composing.current = true;
  };
  const onCompositionEnd = (e: React.CompositionEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    composing.current = false;
    const t = e.currentTarget.value;
    setActive({ ...active!, error: null });
    useEditSession.getState().setText(t);
    useEditSession.getState().setSel(e.currentTarget.selectionStart ?? 0, e.currentTarget.selectionEnd ?? 0);
  };
  const onChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    if (composing.current) return; // mid-composition: never touch the model
    const t = e.target.value;
    setActive({ ...active!, error: null, canOverflow: false });
    useEditSession.getState().setText(t);
    syncSel(e.currentTarget);
    // Task D.3: characters the original font cannot encode
    const bad = [...new Set([...t])].filter((c) => !isWinAnsi(c) && !/\s/.test(c));
    if (bad.length) useEditSession.getState().noteSubstituted(bad);
  };

  const toggleRun = (k: "bold" | "italic" | "underline") => {
    const s = useEditSession.getState().session;
    if (!s || s.locked) return; // Task D: while the formatting is locked, Ctrl/Cmd+B/I/U must not restyle either
    const cur = rangeValue(cps(s.text).length, s.base, s.spans, s.sel.a, s.sel.b, k).value;
    useEditSession.getState().patchRun({ [k]: !cur } as Partial<RunStyle>);
  };
  const syncSel = (el: HTMLInputElement | HTMLTextAreaElement) => useEditSession.getState().setSel(el.selectionStart ?? 0, el.selectionEnd ?? 0);

  const onKeyDown = useCallback((e: React.KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const a = activeRef.current;
    if (!a) return;
    e.stopPropagation(); // the editor's single-letter shortcuts must not fire while typing
    const mod = e.ctrlKey || e.metaKey;
    if (mod && !e.shiftKey && !e.altKey && ["b", "i", "u"].includes(e.key.toLowerCase())) {
      e.preventDefault();
      toggleRun(e.key.toLowerCase() === "b" ? "bold" : e.key.toLowerCase() === "i" ? "italic" : "underline");
    } else if (e.key === "Enter" && !(a.kind === "para" && e.shiftKey)) {
      e.preventDefault();
      commitRef.current();
    } else if (e.key === "Escape") {
      e.preventDefault();
      closeSession(); // cancel: nothing changes
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /**
   * THE FOCUS RULE (§2.4A / §2.4C). A blur that moves INTO the sidebar or the text box frame, or follows a pointer-down on
   * either, is not "outside": the edit must not commit, close, or unmount the sidebar / frame.
   */
  const onBlur = (e: React.FocusEvent) => {
    const to = e.relatedTarget as HTMLElement | null;
    if (to?.closest?.("[data-text-sidebar]") || to?.closest?.("[data-text-frame]")) return;
    if (sidebarRecentlyUsed()) return;
    void commitRef.current();
  };

  // ---------------------------------------------------------------- geometry of the active text box
  const mine = active && sess && sess.key === active.key ? sess : null;
  const base = mine?.base;
  const ex = mine?.extras;
  const curText = mine?.text ?? active?.text ?? "";
  /** Task D: the original formatting is locked unless the user explicitly unlocked this edit */
  const locked = mine?.locked ?? true;
  /** Task C.4: spellcheck is OFF by default on Android (autocorrect / suggestions silently change the text) */
  const spellcheck = false;
  let frame: FrameState | null = null;
  if (active && mine && base && ex) {
    if (active.kind === "unit") {
      const natural = unitTextWidth(curText, base, mine.spans, ex, measure);
      // the box GROWS AND SHRINKS with the typed text: the original width plus the difference in text width
      const w = ex.boxW ?? Math.max(8, active.rect.w + (natural - active.natural0));
      const box = frameBox({ kind: "unit", rect: active.rect, baseline: active.baseline, scale: base.size / active.detSize, width: w, height: 0, dx: ex.dx, dy: ex.dy });
      frame = { box, pivot: pivotOf({ x: active.x0, y: active.top, w: natural, h: Math.max(active.leadH, 4) }, ex.dx, ex.dy), rotation: ex.rotation, kind: "unit", natural };
    } else {
      const w = ex.boxW ?? active.rect.w;
      const lines = wrapText(curText, Math.max(10, w - 2), (s) => measure(s, base.size, base) + ex.charSpacing * cps(s).length + ex.wordSpacing * spaceCount(s));
      const textH = (lines.length - 1) * ex.lineHeight + active.leadH;
      const box = frameBox({ kind: "para", rect: active.rect, baseline: active.baseline, scale: 1, width: w, height: Math.max(active.rect.h, textH + 2), dx: ex.dx, dy: ex.dy });
      frame = { box, pivot: pivotOf({ x: active.x0, y: active.top, w: ex.boxW ?? active.origW, h: Math.max(textH, 4) }, ex.dx, ex.dy), rotation: ex.rotation, kind: "para", natural: 0 };
    }
  }
  frameRef.current = frame;
  const fw = frame?.box.w;
  const fh = frame?.box.h;
  useEffect(() => {
    if (fw !== undefined && fh !== undefined) useEditSession.getState().setBox(fw, fh); // the sidebar's Box fields follow the frame live
  }, [fw, fh]);

  // ---------------------------------------------------------------- frame gestures (each drag = ONE undo step)
  const onFrameBegin = (kind: FrameGesture, handle: HandleId | null, p: Pt) => {
    const st = useEditSession.getState();
    const s = st.session;
    const f = frameRef.current;
    if (!s || !f) return;
    st.beginGesture();
    gesture.current = {
      kind,
      handle,
      p0: p,
      startBase: s.base,
      startSpans: s.spans,
      dx0: s.extras.dx,
      dy0: s.extras.dy,
      rotation0: s.extras.rotation,
      start: { box: f.box, pivot: f.pivot, rotation: s.extras.rotation, kind: f.kind, size: s.base.size, naturalW: f.natural + 2, lineHeight: s.extras.lineHeight, boxW: s.extras.boxW, dx: s.extras.dx, dy: s.extras.dy, minScale: 0.6 },
    };
  };
  const onFrameDrag = (_k: FrameGesture, _h: HandleId | null, p: Pt, shift: boolean) => {
    const g = gesture.current;
    if (!g) return;
    const st = useEditSession.getState();
    if (g.kind === "move") st.patchExtras({ dx: Math.round((g.dx0 + p.x - g.p0.x) * 100) / 100, dy: Math.round((g.dy0 + p.y - g.p0.y) * 100) / 100 });
    else if (g.kind === "rotate") st.patchExtras({ rotation: rotateTo(g.start.pivot, g.p0, p, g.rotation0, shift) });
    else if (g.handle) st.applyFrame({ base: g.startBase, spans: g.startSpans }, resizeBy(g.start, g.handle, p, shift));
  };
  const onFrameEnd = () => {
    if (!gesture.current) return;
    gesture.current = null;
    useEditSession.getState().endGesture();
    focusSelf(); // the editor keeps (or regains) focus, caret and selection
  };
  const onFrameNudge = (sx: number, sy: number, stepPt: number) => {
    const s = useEditSession.getState().session;
    if (!s) return;
    // screen direction → page direction (page rotation / view rotation), so ArrowRight always moves right on screen
    const [a, b, c, d] = m;
    const det = a * d - b * c;
    const vx = (d * sx - c * sy) / det;
    const vy = (-b * sx + a * sy) / det;
    const len = Math.hypot(vx, vy) || 1;
    useEditSession.getState().patchExtras({ dx: Math.round((s.extras.dx + (vx / len) * stepPt) * 100) / 100, dy: Math.round((s.extras.dy + (vy / len) * stepPt) * 100) / 100 });
  };

  // ---------------------------------------------------------------- inline editor look
  const overlay = !!mine && active!.kind === "unit" && (mine.spans.length > 0 || base!.underline || base!.strike || base!.script !== "none");
  const box = frame?.box;
  const inputStyle =
    active && base && ex && box
      ? ({
          position: "absolute",
          left: box.x,
          top: box.y,
          width: box.w,
          height: box.h,
          margin: 0,
          padding: "0 1px",
          border: 0,
          outline: "none", // the text box frame (F45) is the visible frame; it must not be a style of the input itself
          borderRadius: 1 / zoom,
          background: ex.bg,
          color: overlay ? "transparent" : base.color,
          caretColor: base.color,
          fontFamily: familyCss(base.family),
          fontWeight: base.bold ? 700 : 400,
          fontStyle: base.italic ? "italic" : "normal",
          fontSize: base.size,
          lineHeight: active.kind === "unit" ? `${box.h}px` : `${ex.lineHeight}px`,
          letterSpacing: ex.charSpacing !== 0 ? ex.charSpacing : active.letterSpacing,
          wordSpacing: ex.wordSpacing,
          opacity: overlay ? 1 : ex.opacity,
          whiteSpace: active.kind === "unit" ? "pre" : "pre-wrap",
          resize: "none",
          overflow: "hidden",
          pointerEvents: "auto",
          boxSizing: "border-box",
        } as const)
      : undefined;
  const draft: PdfObject | null =
    overlay && active && base && ex && mine && frame
      ? {
          ...createObject("textedit", page.id, active.x0 + ex.dx, active.top + ex.dy, frame.natural, Math.max(active.leadH, 4)),
          text: mine.text,
          spans: mine.spans,
          family: base.family,
          fontSize: base.size,
          bold: base.bold,
          italic: base.italic,
          underline: base.underline,
          strike: base.strike,
          script: base.script,
          color: base.color,
          charSpacing: ex.charSpacing || undefined,
          wordSpacing: ex.wordSpacing || undefined,
          opacity: ex.opacity,
          baseline: active.baseline - active.top,
        }
      : null;
  const banner = active?.error ? pageToCanvas(geo, zoom, { x: active.rect.x, y: active.rect.y + active.rect.h }) : null;
  const unitOf = (u: LineInfo) => `M${u.bbox.x} ${u.bbox.y}h${u.bbox.w}v${u.bbox.h}h${-u.bbox.w}z`;

  return (
    <>
      <svg ref={svgRef} className="absolute inset-0 touch-pan-y" width={width} height={height} style={{ cursor: "default" }} onPointerDown={onPointerDown} onPointerUp={onPointerUp} onPointerCancel={() => (touch.current = null)} onPointerMove={onPointerMove} onMouseDown={(e) => e.preventDefault()} aria-label="Click text to edit it">
        <g transform={`matrix(${m.join(" ")})`}>
          {/* ONE static path = the only "hover" affordance: the I-beam cursor over editable text (pure CSS, no JS on mousemove) */}
          <path data-testid="text-regions" d={regions} fill="transparent" style={{ cursor: "text", pointerEvents: "all" }} />
          {hoverHighlight && hover && <rect data-testid="hover-highlight" x={hover.x0 - 1} y={hover.baseline - 0.8 * hover.size} width={hover.x1 - hover.x0 + 2} height={hover.size} fill="rgba(193,95,60,0.14)" stroke="#c15f3c" strokeWidth={0.6} pointerEvents="none" />}
          {debug && map && (
            <g pointerEvents="none" data-testid="debug-overlay">
              {map.glyphs.map((g) => (
                <polygon key={g.id} points={g.quad.map((q) => `${q.x},${q.y}`).join(" ")} fill="none" stroke="#b1ada1" strokeWidth={0.2} />
              ))}
              {map.words.map((w, i) => {
                const gs = w.map((id) => map.glyphs[id]);
                const x0 = Math.min(...gs.map((g) => g.ink.x));
                const y0 = Math.min(...gs.map((g) => g.ink.y));
                return <rect key={`w${i}`} x={x0} y={y0} width={Math.max(...gs.map((g) => g.ink.x + g.ink.w)) - x0} height={Math.max(...gs.map((g) => g.ink.y + g.ink.h)) - y0} fill="none" stroke="#16a34a" strokeWidth={0.3} strokeDasharray="1.2 1" />;
              })}
              {map.units.map((u) => (
                <path key={`u${u.id}`} data-unit-id={u.id} d={unitOf(u)} fill={UNIT_COLORS[u.id % UNIT_COLORS.length]} fillOpacity={0.1} stroke={UNIT_COLORS[u.id % UNIT_COLORS.length]} strokeWidth={0.7} />
              ))}
              {map.boundaries.map((b, i) => (
                <g key={`b${i}`}>
                  <line x1={b.x} x2={b.x} y1={b.y - 9} y2={b.y + 3} stroke={b.hard ? "#dc2626" : "#16a34a"} strokeWidth={0.8} />
                  <text x={b.x + 1} y={b.y - 9} fontSize={3.4} fill={b.hard ? "#dc2626" : "#15803d"}>
                    {b.hard ? "hard" : "soft"}: {b.reason}
                  </text>
                </g>
              ))}
              {probe && (
                <>
                  <line x1={probe.x - 4} x2={probe.x + 4} y1={probe.y} y2={probe.y} stroke="#dc2626" strokeWidth={0.6} />
                  <line y1={probe.y - 4} y2={probe.y + 4} x1={probe.x} x2={probe.x} stroke="#dc2626" strokeWidth={0.6} />
                </>
              )}
            </g>
          )}
        </g>
      </svg>

      {active && mine && inputStyle && frame && ex && (
        <div className="pointer-events-none absolute inset-0">
          <div style={{ position: "absolute", left: 0, top: 0, transformOrigin: "0 0", transform: `matrix(${m.join(",")})` }}>
            {/* hides the ORIGINAL text where it still is while the edited text has been moved / rotated / resized */}
            <div aria-hidden="true" style={{ position: "absolute", left: active.rect.x, top: active.rect.y, width: active.rect.w, height: active.rect.h, background: ex.bg, pointerEvents: "none" }} />
            {/* the editor and its preview rotate together about the SAME pivot as the exported text, so the caret stays on the glyphs */}
            <div data-testid="editor-rotator" style={{ position: "absolute", left: 0, top: 0, transformOrigin: `${frame.pivot.x}px ${frame.pivot.y}px`, transform: ex.rotation ? `rotate(${ex.rotation}deg)` : undefined }}>
              {active.kind === "unit" ? (
                <input
                  key={active.key}
                  ref={inputRef}
                  data-testid="inline-editor"
                  aria-label="Edit text"
                  spellCheck={false}
                  autoComplete="off"
                  value={curText}
                  style={inputStyle}
                  onChange={onChange}
                  onBeforeInput={onBeforeInput}
                  onPaste={onPaste}
                  onCompositionStart={onCompositionStart}
                  onCompositionEnd={onCompositionEnd}
                  onSelect={(e) => syncSel(e.currentTarget)}
                  onKeyUp={(e) => syncSel(e.currentTarget)}
                  onMouseUp={(e) => syncSel(e.currentTarget)}
                  onKeyDown={onKeyDown}
                  onBlur={onBlur}
                />
              ) : (
                <textarea
                  key={active.key}
                  ref={inputRef}
                  data-testid="inline-editor"
                  aria-label="Edit paragraph"
                  spellCheck={spellcheck}
                  inputMode="text"
                  enterKeyHint="done"
                  autoCapitalize="off"
                  autoCorrect="off"
                  value={curText}
                  style={inputStyle}
                  onChange={onChange}
                  onBeforeInput={onBeforeInput}
                  onPaste={onPaste}
                  onCompositionStart={onCompositionStart}
                  onCompositionEnd={onCompositionEnd}
                  onSelect={(e) => syncSel(e.currentTarget)}
                  onKeyUp={(e) => syncSel(e.currentTarget)}
                  onMouseUp={(e) => syncSel(e.currentTarget)}
                  onKeyDown={onKeyDown}
                  onBlur={onBlur}
                />
              )}
              {draft && (
                <svg width={pageW} height={pageH} style={{ position: "absolute", left: 0, top: 0, overflow: "visible", pointerEvents: "none" }} aria-hidden="true" data-testid="text-live-preview">
                  <TextRuns o={draft} />
                </svg>
              )}
            </div>
          </div>
        </div>
      )}

      {/* the ACTIVE TEXT BOX (F45): drawn above the editor, the cover, the page and every annotation; mounted only while an edit is open */}
      {active && mine && frame && ex && (
        <TextFrame box={frame.box} pivot={frame.pivot} rotation={ex.rotation} pageRotation={geo.rotation} zoom={zoom} matrix={m} width={width} height={height} kind={frame.kind} toPage={toPage} onBegin={onFrameBegin} onDrag={onFrameDrag} onEnd={onFrameEnd} onNudge={onFrameNudge} locked={locked} />
      )}

      {banner && active?.error && (
        <div role="alert" className="absolute z-10 max-w-[min(92%,24rem)] rounded-xl border border-red-300 bg-red-50 p-2 text-xs text-red-900 shadow-lg dark:border-red-800 dark:bg-red-950 dark:text-red-100" style={{ left: Math.max(4, Math.min(banner.x, width - 260)), top: banner.y + 8 }}>
          <p>{active.error}</p>
          <div className="mt-1.5 flex gap-2">
            {active.canOverflow && (
              <button className="rounded-lg bg-red-700 px-2 py-0.5 font-semibold text-white" onMouseDown={(e) => e.preventDefault()} onClick={() => commitRef.current(true)}>
                Allow overflow
              </button>
            )}
            <button className="rounded-lg border border-red-300 px-2 py-0.5" onMouseDown={(e) => e.preventDefault()} onClick={closeSession}>
              Cancel edit
            </button>
          </div>
        </div>
      )}
      {state === "loading" && <div className="pointer-events-none absolute left-2 top-2 rounded bg-slate-900/70 px-2 py-0.5 text-xs text-white">Reading text…</div>}
      {state === "none" && <div className="pointer-events-none absolute left-2 top-2 rounded bg-amber-600 px-2 py-0.5 text-xs text-white">No selectable text on this page (scan?). Run OCR first.</div>}
      {debug && (
        <div className="pointer-events-none absolute bottom-1 left-1 max-w-[90%] rounded bg-slate-900/85 px-2 py-1 font-mono text-[10px] text-white" data-testid="debug-hud">
          unit <span data-testid="active-unit-id">{active ? `${active.kind === "para" ? "p" : "u"}${active.id}` : "-"}</span>: “<span data-testid="active-unit-text">{active ? active.orig : ""}</span>”
        </div>
      )}
    </>
  );
}
