import { useEffect, useState } from "react";
import { cn } from "../../utils/cn";
import { useEditor } from "../../lib/model/docState";
import { useUi } from "../../lib/model/ui";
import { useEditSession } from "../../lib/text/editSession";
import { buzz } from "../../lib/mobile/haptics";
import { Wordmark } from "../Logo";
import { btn, btnPrimary } from "../ui";
import { TOOL_BUTTONS } from "../../lib/toolbarDef";

/** What the bottom bar shows directly; everything else is behind "More". */
const PRIMARY = ["select", "hand", "text", "highlight", "underline"] as const;

/**
 * Mobile editor chrome (TASKS-03 Task A, F46): a compact top bar, a bottom tool bar inside thumb reach, and the
 * contextual toolbar above the keyboard while editing (Task C.3 / D.2). Every target is ≥ 48 px.
 */
export function MobileEditorChrome({ onOpenSheets }: { onOpenSheets: () => void }) {
  const doc = useEditor((s) => s.doc)!;
  const tool = useEditor((s) => s.tool);
  const canUndo = useEditor((s) => s.past.length > 0);
  const canRedo = useEditor((s) => s.future.length > 0);
  const ui = useUi();
  const sess = useEditSession((s) => s.session);
  const [more, setMore] = useState(false);
  const st = useEditor.getState;

  const icon = "grid h-12 min-w-12 place-items-center rounded-xl text-lg";
  const pick = (id: (typeof TOOL_BUTTONS)[number]["id"]) => {
    if (id === "image") return document.querySelector<HTMLInputElement>('input[aria-label="Choose image to insert"]')?.click();
    if (id === "signature") return ui.set({ signatureOpen: true });
    buzz("tap");
    useEditor.setState({ tool: id });
  };

  return (
    <>
      <header className="flex items-center gap-1 border-b border-slate-200 bg-slate-100/95 px-2 py-1.5 backdrop-blur dark:border-slate-700 dark:bg-slate-900/95" style={{ paddingTop: "max(0.375rem, env(safe-area-inset-top))" }}>
        <button className="grid h-11 w-11 place-items-center rounded-xl" onClick={() => navigate0()} aria-label="PageFlex home">
          <Wordmark className="text-sm" />
        </button>
        <span className="min-w-0 flex-1 truncate text-xs text-slate-500" title={st().fileName}>{st().fileName}</span>
        <button className="grid h-11 w-11 place-items-center rounded-xl disabled:opacity-40" onClick={() => st().undo()} disabled={!canUndo} aria-label="Undo">↶</button>
        <button className="grid h-11 w-11 place-items-center rounded-xl disabled:opacity-40" onClick={() => st().redo()} disabled={!canRedo} aria-label="Redo">↷</button>
        <button className={cn(btnPrimary, "!px-3 !py-2")} onClick={() => ui.set({ exportOpen: true })} aria-label="Download">⇩</button>
      </header>

      <nav className="fixed inset-x-0 z-20 flex items-center gap-1 border-t border-slate-200 bg-slate-100/95 px-1.5 pb-[env(safe-area-inset-bottom)] backdrop-blur dark:border-slate-700 dark:bg-slate-900/95" style={{ bottom: sess ? "calc(3.5rem + env(safe-area-inset-bottom))" : 0 }} role="toolbar" aria-label="Editing tools">
        <button className={icon} onClick={onOpenSheets} aria-label="Pages and tools">☰</button>
        {/* primary tools (Edit text is pinned separately, so it must not also appear in this list) */}
        {PRIMARY.map((id) => {
          const b = TOOL_BUTTONS.find((x) => x.id === id)!;
          return (
            <button key={b.id} className={cn(icon, tool === b.id && "bg-indigo-600 text-white")} aria-pressed={tool === b.id} aria-label={`${b.label} (${b.key})`} title={`${b.label} (${b.key})`} onClick={() => pick(b.id)}>
              <span aria-hidden="true">{b.icon}</span>
            </button>
          );
        })}
        <button className={cn(icon, more && "bg-indigo-600 text-white")} onClick={() => setMore((v) => !v)} aria-label="More tools" aria-expanded={more}>⋯</button>
        <button className={cn(icon, tool === "edittext" && "bg-indigo-600 text-white")} aria-pressed={tool === "edittext"} onClick={() => pick("edittext")} aria-label="Edit text (E)" title="Edit text (E)">
          <span aria-hidden="true">✎</span>
        </button>
      </nav>
      {more && (
        <div className="animate-pop fixed inset-x-1 z-30 grid grid-cols-4 gap-1 rounded-2xl border border-slate-200 bg-slate-50 p-2 shadow-2xl dark:border-slate-700 dark:bg-slate-900" style={{ bottom: "calc(4.75rem + env(safe-area-inset-bottom))" }} role="menu" aria-label="More tools">
          {TOOL_BUTTONS.slice(6).map((b) => (
            <button key={b.id} role="menuitem" className={cn("flex h-16 flex-col items-center justify-center gap-0.5 rounded-xl text-[10px]", tool === b.id ? "bg-indigo-600 text-white" : "")} aria-pressed={tool === b.id} onClick={() => { pick(b.id); setMore(false); }}>
              <span className="text-lg" aria-hidden="true">{b.icon}</span>
              {b.label}
            </button>
          ))}
        </div>
      )}
      <span className="sr-only" aria-live="polite">
        {doc.pages.length} pages
      </span>
    </>
  );
}

function navigate0() {
  window.location.hash = "#/";
}

/** Task F: install prompt + offline notice, shown once when the browser offers an install. */
export function InstallPrompt() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    let off: (() => void) | undefined;
    void (async () => {
      const { watchInstallPrompt, promptInstall } = await import("../../lib/mobile/files");
      off = watchInstallPrompt(() => setReady(true));
      (window as unknown as { __pfPromptInstall: () => Promise<string> }).__pfPromptInstall = promptInstall;
    })();
    return () => off?.();
  }, []);
  if (!ready) return null;
  return (
    <div className="animate-slide-in fixed inset-x-3 z-30 flex items-center gap-3 rounded-2xl border border-slate-200 bg-slate-50 p-3 text-sm shadow-xl dark:border-slate-700 dark:bg-slate-900" style={{ bottom: "calc(5rem + env(safe-area-inset-bottom))" }} role="region" aria-label="Install PageFlex">
      <span className="flex-1">Install PageFlex to use it offline.</span>
      <button
        className={btn}
        onClick={async () => {
          await (window as unknown as { __pfPromptInstall: () => Promise<string> }).__pfPromptInstall();
          setReady(false);
        }}
      >
        Install
      </button>
      <button className={btn} onClick={() => setReady(false)} aria-label="Dismiss install prompt">✕</button>
    </div>
  );
}
