import { useEffect, useRef, useState, type ReactNode } from "react";
import { cn } from "../../utils/cn";
import { buzz } from "../../lib/mobile/haptics";
import { pushMode } from "../../lib/mobile/backButton";

/**
 * Bottom sheet (TASKS-03 Task A). Replaces the desktop side panels on phones: same data, same controls, mobile layout.
 * It registers itself with the Back-button stack so Android Back closes the sheet instead of leaving the page (F55).
 */
export function BottomSheet({ title, onClose, children, footer, tall }: { title: string; onClose: () => void; children: ReactNode; footer?: ReactNode; tall?: boolean }) {
  const [drag, setDrag] = useState(0);
  const start = useRef<number | null>(null);
  useEffect(() => {
    const off = pushMode({ kind: "sheet", close: () => (onClose(), true) });
    return off;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return (
    <div className="animate-fade-in fixed inset-0 z-40 flex flex-col justify-end bg-slate-950/50" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <section
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={cn("animate-slide-in flex flex-col rounded-t-3xl border-t border-slate-200 bg-slate-50 shadow-2xl dark:border-slate-700 dark:bg-slate-900", tall ? "h-[88vh]" : "max-h-[80vh]")}
        style={{ transform: drag ? `translateY(${drag}px)` : undefined, paddingBottom: "env(safe-area-inset-bottom)" }}
      >
        <div
          className="flex cursor-grab touch-none flex-col items-center pt-2 pb-1"
          onPointerDown={(e) => {
            start.current = e.clientY;
            e.currentTarget.setPointerCapture(e.pointerId);
          }}
          onPointerMove={(e) => start.current !== null && setDrag(Math.max(0, e.clientY - start.current))}
          onPointerUp={() => {
            if (drag > 120) onClose();
            start.current = null;
            setDrag(0);
          }}
        >
          <span className="h-1.5 w-10 rounded-full bg-slate-300 dark:bg-slate-600" aria-hidden="true" />
          <h2 className="mt-2 w-full px-4 pb-1 text-left text-sm font-semibold">{title}</h2>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain">{children}</div>
        {footer && <div className="flex flex-wrap justify-end gap-2 border-t border-slate-200 p-3 dark:border-slate-700">{footer}</div>}
      </section>
    </div>
  );
}

/**
 * The contextual toolbar docked above the keyboard (TASKS-03 Task C.3 / Task D.2).
 * Everything a typist needs while the IME is open: undo, redo, find, the Formatting-locked toggle, Done.
 */
export function KeyboardToolbar({
  locked,
  onToggleLock,
  onDone,
  onUndo,
  onRedo,
  onFind,
  canUndo,
  canRedo,
  substituteCount,
  onReviewSubstitutes,
}: {
  locked: boolean;
  onToggleLock: () => void;
  onDone: () => void;
  onUndo: () => void;
  onRedo: () => void;
  onFind: () => void;
  canUndo: boolean;
  canRedo: boolean;
  substituteCount: number;
  onReviewSubstitutes?: () => void;
}) {
  const b = "inline-flex h-11 min-w-11 items-center justify-center gap-1 rounded-xl px-3 text-sm font-medium disabled:opacity-40";
  return (
    <div
      className="fixed inset-x-0 z-30 flex items-center gap-1 border-t border-slate-200 bg-slate-100/95 px-2 backdrop-blur dark:border-slate-700 dark:bg-slate-900/95"
      style={{ bottom: "calc(env(safe-area-inset-bottom) + var(--pf-keyboard-inset, 0px))" }}
      role="toolbar"
      aria-label="Text editing actions"
      data-testid="keyboard-toolbar"
    >
      <button className={b} onClick={onUndo} disabled={!canUndo} aria-label="Undo edit">↶</button>
      <button className={b} onClick={onRedo} disabled={!canRedo} aria-label="Redo edit">↷</button>
      <button className={b} onClick={onFind} aria-label="Find and replace">🔍</button>
      <button
        className={cn(b, locked ? "bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300" : "bg-indigo-600 text-white")}
        onClick={() => {
          buzz("toggle");
          onToggleLock();
        }}
        aria-pressed={!locked}
        aria-label={locked ? "Formatting locked. Tap to unlock." : "Formatting unlocked. Tap to lock."}
        title={locked ? "Formatting locked – only characters change" : "Formatting unlocked"}
        data-testid="lock-toggle"
      >
        <span aria-hidden="true">{locked ? "🔒" : "🔓"}</span>
        <span className="hidden xs:inline">{locked ? "Locked" : "Unlocked"}</span>
      </button>
      {substituteCount > 0 && (
        <button className={cn(b, "bg-amber-100 text-amber-900 dark:bg-amber-900 dark:text-amber-100")} onClick={onReviewSubstitutes} aria-label={`Used a substitute font for ${substituteCount} characters`}>
          <span aria-hidden="true">⚠</span>
          <span className="text-xs">{substituteCount}</span>
        </button>
      )}
      <button className={cn(b, "ml-auto bg-indigo-600 font-semibold text-white")} onClick={onDone} data-testid="keyboard-done">
        Done
      </button>
    </div>
  );
}

/** "Tap to type" fallback chip (Task C.2) when focus() did not raise the keyboard. */
export function TapToTypeChip({ onTap, x, y }: { onTap: () => void; x: number; y: number }) {
  return (
    <button
      className="animate-pop absolute z-20 flex h-11 items-center gap-1.5 rounded-full bg-indigo-600 px-4 text-sm font-semibold text-white shadow-lg"
      style={{ left: Math.max(8, x), top: Math.max(8, y) }}
      onClick={onTap}
      data-testid="tap-to-type"
    >
      <span aria-hidden="true">⌨</span> Tap to type
    </button>
  );
}

/** Zoom controls (Task B.2): the accessible alternative to pinching, thumb-sized. */
export function ZoomCluster({ onIn, onOut, onFit, on100, zoom }: { onIn: () => void; onOut: () => void; onFit: () => void; on100: () => void; zoom: number }) {
  const b = "grid h-11 w-11 place-items-center rounded-xl border border-slate-300 bg-white/90 text-base shadow backdrop-blur disabled:opacity-40 dark:border-slate-600 dark:bg-slate-900/90";
  return (
    <div className="pointer-events-auto flex flex-col gap-1.5" role="group" aria-label="Zoom">
      <button className={b} onClick={onIn} aria-label="Zoom in">＋</button>
      <button className="grid h-11 w-11 place-items-center rounded-xl border border-slate-300 bg-white/90 text-[10px] tabular-nums shadow backdrop-blur dark:border-slate-600 dark:bg-slate-900/90" onClick={on100} aria-label={`Zoom ${Math.round(zoom * 100)} percent. Tap for 100%`}>{Math.round(zoom * 100)}%</button>
      <button className={b} onClick={onOut} aria-label="Zoom out">−</button>
      <button className={b} onClick={onFit} aria-label="Fit width">⇔</button>
    </div>
  );
}
