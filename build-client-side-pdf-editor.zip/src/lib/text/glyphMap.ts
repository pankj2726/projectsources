/**
 * Text hierarchy (TASKS-02 Task 2, revised):
 *
 *     Glyph → Word → LINE SEGMENT (the EDIT UNIT) → Paragraph (optional reflow) → Column/Block
 *
 * Glyphs and words are INTERNAL (hit-testing, caret placement, search, diffing). The editable object is the line
 * segment ("unit"): consecutive text on one baseline, in one column/cell, with no hard boundary inside it.
 * Hard boundaries stop neighbour bleed; soft boundaries (spaces – including justified/stretched ones – style changes,
 * super/subscripts, kerning) never split a unit, so sentences are not fragmented.
 *
 * Everything lives in PAGE SPACE (pt, origin top-left of the crop box, y down, page /Rotate ignored) – the space editor
 * objects use – so `lib/model/coords.ts` stays the only place that handles rotation and zoom. Pure and DOM-free.
 *
 * LIMITATION (docs/KNOWN_LIMITATIONS.md KL-GLYPH): pdf.js exposes no per-glyph advances, so an item's measured width is
 * distributed over its characters with a proportional-width table. Item/word/unit extents are exact; letter boundaries
 * inside a word can be off by a fraction of a glyph.
 */
import type { FontFamily } from "../model/objects";

export interface Pt {
  x: number;
  y: number;
}
export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

/** One pdf.js text item, converted to page space (no merging). */
export interface RawItem {
  str: string;
  x: number;
  baseline: number;
  /** total advance of the item (pt) */
  w: number;
  size: number;
  /** radians, PDF orientation (counter-clockwise, y up) */
  angle: number;
  fontName: string;
  family: FontFamily;
  bold: boolean;
  italic: boolean;
  /** original font name without the subset prefix ("" = pdf.js had not resolved it) */
  fontLabel?: string;
  /** the built-in fonts cannot reproduce the original face, so a fallback is used */
  substituted?: boolean;
  /** fill colour detected from the page's operators ("#rrggbb"); undefined = unknown, the sidebar then samples pixels */
  color?: string;
}

/** A ruling line / cell border in page space (axis-aligned). */
export interface Rule {
  kind: "v" | "h";
  x0: number;
  y0: number;
  x1: number;
  y1: number;
}

export interface Glyph {
  /** index in `map.glyphs`; ids are assigned in READING ORDER */
  id: number;
  char: string;
  itemIndex: number;
  /** oriented polygon: top-left, top-right, bottom-right, bottom-left (glyph's own frame) */
  quad: [Pt, Pt, Pt, Pt];
  /** tight axis-aligned ink box (x-height / cap-height based, NOT the full line height) */
  ink: Rect;
  origin: Pt;
  advance: number;
  baseline: number;
  size: number;
  angle: number;
  wordId: number; // -1 for whitespace
  lineId: number; // = unit id
  columnId: number;
  space: boolean;
  mark: boolean;
  fontName: string;
  family: FontFamily;
  bold: boolean;
  italic: boolean;
}

/** A line segment = THE edit unit. */
export interface LineInfo {
  id: number;
  columnId: number;
  /** glyph ids of the unit, leading/trailing whitespace trimmed */
  glyphIds: number[];
  bbox: Rect;
  baseline: number;
  /** dominant font size */
  size: number;
  family: FontFamily;
  bold: boolean;
  italic: boolean;
  rotated: boolean;
  /** the unit as one string; a virtual space is inserted where words are separated by a gap but no space glyph */
  text: string;
  /** per code point of `text`: glyph id, or -1 for a virtual space */
  charGlyph: number[];
  /** left origin of the first glyph / right edge of the last (pt) */
  x0: number;
  x1: number;
  paraId: number;
}

export interface Paragraph {
  id: number;
  unitIds: number[];
  columnId: number;
  bbox: Rect;
  /** median baseline-to-baseline distance */
  pitch: number;
}

export interface BoundaryNote {
  x: number;
  y: number;
  hard: boolean;
  /** e.g. "gap 31pt > 2×size", "different column", "table cell border" */
  reason: string;
}

export interface GlyphMap {
  glyphs: Glyph[];
  /** line segments (edit units) in reading order */
  lines: LineInfo[];
  units: LineInfo[];
  /** wordId → glyph ids (internal) */
  words: number[][];
  paragraphs: Paragraph[];
  boundaries: BoundaryNote[];
}

export interface BuildOptions {
  rules?: Rule[];
}

const ASC = 0.8;
const DESC = 0.2;
const WORD_GAP_EM = 0.5;
const MARK_RE = /\p{M}/u;
const ZERO_WIDTH_RE = /[\u200b-\u200f\u2060\ufeff]/;

export const isSpaceChar = (ch: string) => /^\s$/u.test(ch);
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
const median = (a: number[]) => {
  const s = [...a].sort((x, y) => x - y);
  const m = s.length >> 1;
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
};

// ---------- width model ----------
const NARROW = new Set("iljtfIr'.,:;!|`’‘ ".split(""));
export function charWeight(ch: string): number {
  if (MARK_RE.test(ch) || ZERO_WIDTH_RE.test(ch)) return 0;
  if (ch === " " || ch === "\u00a0") return 0.28;
  if (NARROW.has(ch)) return 0.27;
  if (/[mM]/.test(ch)) return 0.85;
  if (/[wW]/.test(ch)) return 0.78;
  if (/[0-9]/.test(ch)) return 0.556;
  if (/[A-Z]/.test(ch)) return 0.68;
  if (/[\u2e80-\u9fff\uac00-\ud7af\uff00-\uffef]/.test(ch)) return 1;
  if (/[a-z]/.test(ch)) return 0.5;
  return 0.55;
}

/** Width estimate used when no canvas is available (tests, workers). The browser passes a real measure instead. */
export function estimateWidth(text: string, size: number): number {
  let w = 0;
  for (const ch of text) w += charWeight(ch) * size * 1.08;
  return w;
}

function inkExtent(ch: string): [number, number] {
  let top = 0.54;
  let bottom = 0.02;
  if (/[A-Z0-9bdfhklt!?()[\]{}/|"'&%$#@ß]/.test(ch) || /[^\u0000-\u024f]/.test(ch)) top = 0.76;
  if (/[.,:;·•_-]/.test(ch)) top = 0.14;
  if (/[gjpqyQ,;()[\]{}|/@]/.test(ch)) bottom = 0.22;
  if (/[\u0900-\u097f]/.test(ch)) bottom = 0.25;
  return [top, bottom];
}

// ---------- glyph construction ----------
interface Cand extends Omit<Glyph, "id" | "wordId" | "lineId" | "columnId"> {
  rotated: boolean;
}

function explode(item: RawItem, itemIndex: number): Cand[] {
  const chars = [...item.str];
  const weights = chars.map(charWeight);
  const total = weights.reduce((a, b) => a + b, 0);
  if (total <= 0) return [];
  const a = item.angle;
  const t = { x: Math.cos(a), y: -Math.sin(a) };
  const n = { x: -Math.sin(a), y: -Math.cos(a) };
  const at = (s: number, up: number): Pt => ({ x: item.x + t.x * s + n.x * up, y: item.baseline + t.y * s + n.y * up });
  const rotated = Math.abs(a) > 0.05;
  const out: Cand[] = [];
  let s = 0;
  chars.forEach((ch, i) => {
    const adv = (weights[i] / total) * item.w;
    const s0 = s;
    const s1 = s + adv;
    s = s1;
    const [top, bottom] = inkExtent(ch);
    const corners = [at(s0, top * item.size), at(s1, top * item.size), at(s1, -bottom * item.size), at(s0, -bottom * item.size)];
    const xs = corners.map((c) => c.x);
    const ys = corners.map((c) => c.y);
    out.push({
      char: ch,
      itemIndex,
      quad: [at(s0, ASC * item.size), at(s1, ASC * item.size), at(s1, -DESC * item.size), at(s0, -DESC * item.size)],
      ink: { x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys) },
      origin: at(s0, 0),
      advance: adv,
      baseline: item.baseline,
      size: item.size,
      angle: a,
      space: isSpaceChar(ch),
      mark: weights[i] === 0,
      fontName: item.fontName,
      family: item.family,
      bold: item.bold,
      italic: item.italic,
      rotated,
    });
  });
  return out;
}

interface Seg {
  glyphs: Cand[];
  bbox: Rect;
}
const unionRect = (rs: Rect[]): Rect => {
  const x0 = Math.min(...rs.map((r) => r.x));
  const y0 = Math.min(...rs.map((r) => r.y));
  const x1 = Math.max(...rs.map((r) => r.x + r.w));
  const y1 = Math.max(...rs.map((r) => r.y + r.h));
  return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
};
const toSeg = (glyphs: Cand[]): Seg => ({ glyphs, bbox: unionRect(glyphs.map((g) => g.ink)) });

interface Cluster {
  kept: Cand[];
  cuts: Map<number, string>;
  tab: { idx: number; x: number; y: number }[];
}

const r1 = (n: number) => Math.round(n * 10) / 10;

/** Segment one baseline cluster, recording every hard / soft boundary decision with its reason. */
function segmentCluster(kept: Cand[], rules: Rule[], notes: BoundaryNote[]): Cluster {
  const cl: Cluster = { kept, cuts: new Map(), tab: [] };
  // the line's OWN space-width distribution: stretched-but-uniform (justified) spaces are not boundaries
  const gaps: number[] = [];
  let pr: Cand | null = null;
  for (const g of kept) {
    if (g.space || g.mark) continue;
    if (pr) {
      const gap = g.origin.x - (pr.origin.x + pr.advance);
      if (gap > 0.12 * Math.max(g.size, pr.size)) gaps.push(gap);
    }
    pr = g;
  }
  const med = gaps.length ? median(gaps) : 0.28 * (kept[0]?.size ?? 10);
  // justified line: ≥ 3 gaps and ≥ 75% of them within ±25% of the median → the spaces are STRETCHED BUT UNIFORM, so they
  // are not boundaries even beyond 2× font size (a column gutter is a lone outlier among small gaps, never uniform)
  const uniform = gaps.length >= 3 && gaps.filter((x) => Math.abs(x - med) <= 0.25 * med).length >= 0.75 * gaps.length;

  let prev: Cand | null = null;
  kept.forEach((g, idx) => {
    if (g.space || g.mark) return;
    if (prev) {
      const size = Math.max(g.size, prev.size);
      const lo = Math.min(g.size, prev.size);
      const gap = g.origin.x - (prev.origin.x + prev.advance);
      const thr = Math.max(clamp(3 * med, size, 2 * size), uniform ? 1.6 * med : 0);
      const base = Math.abs(g.baseline - prev.baseline);
      const supsub = lo <= 0.85 * size && gap < 0.3 * size && base >= 0.05 * size && base <= 0.9 * size;
      const at = { x: g.origin.x, y: g.baseline };
      const band0 = Math.min(g.baseline, prev.baseline) - ASC * size;
      const band1 = Math.max(g.baseline, prev.baseline) + DESC * size;
      const right = prev.origin.x + prev.advance;
      const rule = rules.find((r) => r.kind === "v" && r.x0 > right - 0.5 && r.x0 < g.origin.x + 0.5 && r.y0 < band1 && r.y1 > band0);
      let reason = "";
      if (rule) reason = `table cell border (vertical rule at x=${r1(rule.x0)})`;
      else if (gap > thr) reason = gap > 2 * size ? `gap ${r1(gap)}pt > 2×size (${r1(2 * size)}pt)` : `gap ${r1(gap)}pt > 3×median space (${r1(3 * med)}pt)`;
      else if (size / lo > 1.25 && !supsub) reason = `font size change ${Math.round((size / lo - 1) * 100)}%`;
      else if (base > 0.3 * size && !supsub) reason = `different baseline (Δ${r1(base)}pt)`;
      if (reason) {
        cl.cuts.set(idx, reason);
        notes.push({ ...at, hard: true, reason });
      } else {
        if (gap >= 0.8 * size) cl.tab.push({ idx, x: g.origin.x, y: g.baseline });
        if (supsub) notes.push({ ...at, hard: false, reason: "superscript/subscript attached to its word" });
        else if (gap > 0.45 * size) notes.push({ ...at, hard: false, reason: `wide gap ${r1(gap)}pt kept (justified spacing, median space ${r1(med)}pt)` });
        else if (prev.fontName !== g.fontName || prev.bold !== g.bold || prev.italic !== g.italic) notes.push({ ...at, hard: false, reason: "style change inside a sentence kept (same unit)" });
      }
    }
    prev = g;
  });
  return cl;
}

export function buildGlyphMap(items: RawItem[], opts: BuildOptions = {}): GlyphMap {
  const rules = opts.rules ?? [];
  const notes: BoundaryNote[] = [];
  const cands: Cand[] = [];
  items.forEach((it, i) => {
    if (it.str) cands.push(...explode(it, i));
  });
  const segs: Seg[] = [];

  // rotated / skewed items: each item is its own unit (different rotation / writing direction = hard boundary)
  const byItem = new Map<number, Cand[]>();
  for (const c of cands) if (c.rotated) byItem.set(c.itemIndex, [...(byItem.get(c.itemIndex) ?? []), c]);
  for (const g of byItem.values()) {
    segs.push(toSeg(g));
    notes.push({ x: g[0].origin.x, y: g[0].baseline, hard: true, reason: "different rotation / writing direction" });
  }

  // axis-aligned: cluster by baseline (tolerant of super/subscripts), then split at HARD boundaries only
  const axis = cands.filter((c) => !c.rotated).sort((a, b) => a.baseline - b.baseline);
  const groups: { baseline: number; size: number; glyphs: Cand[] }[] = [];
  for (const g of axis) {
    const last = groups[groups.length - 1];
    if (last && Math.abs(g.baseline - last.baseline) <= 0.45 * Math.max(g.size, last.size)) {
      last.glyphs.push(g);
      if (g.size > last.size) {
        last.size = g.size;
        last.baseline = g.baseline;
      }
    } else groups.push({ baseline: g.baseline, size: g.size, glyphs: [g] });
  }
  const clusters: Cluster[] = groups.map((c) => {
    const sorted = [...c.glyphs].sort((a, b) => a.origin.x - b.origin.x);
    const kept: Cand[] = []; // drop exact duplicates (fake-bold double strikes, stacked invisible text layers)
    for (const g of sorted) {
      let dup = false;
      for (let j = kept.length - 1; j >= 0 && g.origin.x - kept[j].origin.x < 0.1 * g.size; j--) {
        if (kept[j].char === g.char && Math.abs(kept[j].baseline - g.baseline) < 0.3 * g.size) dup = true;
      }
      if (!dup) kept.push(g);
    }
    return segmentCluster(kept, rules, notes);
  });

  // tabular alignment: the same x starts a column gap in ≥ 3 rows → a column boundary even if the gap is "small"
  const tab = clusters.flatMap((c, ci) => c.tab.map((t) => ({ ...t, ci }))).sort((a, b) => a.x - b.x);
  for (let i = 0; i < tab.length; ) {
    let j = i;
    while (j + 1 < tab.length && tab[j + 1].x - tab[i].x <= 1) j++;
    const grp = tab.slice(i, j + 1);
    const rows = new Set(grp.map((t) => t.ci));
    if (rows.size >= 3) {
      for (const t of grp) {
        const reason = `tabular alignment (${rows.size} rows share a column edge at x=${r1(t.x)})`;
        if (!clusters[t.ci].cuts.has(t.idx)) {
          clusters[t.ci].cuts.set(t.idx, reason);
          notes.push({ x: t.x, y: t.y, hard: true, reason });
        }
      }
    }
    i = j + 1;
  }
  for (const c of clusters) {
    const idxs = [...c.cuts.keys()].sort((a, b) => a - b);
    let start = 0;
    for (const ci of idxs) {
      if (ci > start) segs.push(toSeg(c.kept.slice(start, ci)));
      start = ci;
    }
    if (start < c.kept.length) segs.push(toSeg(c.kept.slice(start)));
  }
  if (!segs.length) return { glyphs: [], lines: [], units: [], words: [], paragraphs: [], boundaries: notes };

  // ---- reading order: bands split by page-wide segments; columns inside a band by x-overlap ----
  const minX = Math.min(...segs.map((s) => s.bbox.x));
  const maxX = Math.max(...segs.map((s) => s.bbox.x + s.bbox.w));
  const pageW = maxX - minX;
  const cy = (s: Seg) => s.bbox.y + s.bbox.h / 2;
  const wide = segs.filter((s) => s.bbox.w > 0.6 * pageW).sort((a, b) => cy(a) - cy(b));
  const narrow = segs.filter((s) => !(s.bbox.w > 0.6 * pageW));
  const bands: Seg[][] = Array.from({ length: wide.length + 1 }, () => []);
  for (const s of narrow) {
    let b = 0;
    while (b < wide.length && cy(wide[b]) < cy(s)) b++;
    bands[b].push(s);
  }
  const ordered: Seg[] = [];
  for (let b = 0; b < bands.length; b++) {
    const list = bands[b];
    const parent = list.map((_, i) => i);
    const find = (i: number): number => (parent[i] === i ? i : (parent[i] = find(parent[i])));
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const A = list[i].bbox;
        const B = list[j].bbox;
        if (A.x < B.x + B.w - 1 && B.x < A.x + A.w - 1) parent[find(i)] = find(j);
      }
    }
    const grp = new Map<number, Seg[]>();
    list.forEach((s, i) => grp.set(find(i), [...(grp.get(find(i)) ?? []), s]));
    const cols = [...grp.values()].sort((a, c2) => Math.min(...a.map((s) => s.bbox.x)) - Math.min(...c2.map((s) => s.bbox.x)));
    for (const col of cols) {
      col.sort((a, c2) => cy(a) - cy(c2) || a.bbox.x - c2.bbox.x);
      ordered.push(...col);
    }
    if (b < wide.length) ordered.push(wide[b]);
  }

  // ---- assign ids / units / words ----
  const glyphs: Glyph[] = [];
  const lines: LineInfo[] = [];
  const words: number[][] = [];
  let columnId = 0;
  let prevBox: Rect | null = null;
  ordered.forEach((seg, lineId) => {
    if (prevBox) {
      const overlap = Math.max(0, Math.min(prevBox.x + prevBox.w, seg.bbox.x + seg.bbox.w) - Math.max(prevBox.x, seg.bbox.x));
      if (overlap < 0.3 * Math.min(prevBox.w, seg.bbox.w)) {
        columnId++;
        notes.push({ x: seg.bbox.x, y: seg.bbox.y, hard: true, reason: "different column (< 30% horizontal overlap with the previous line)" });
      }
    }
    prevBox = seg.bbox;
    const ids: number[] = [];
    let wordId = -1;
    let startNew = true;
    let prev: Cand | null = null;
    for (const g of seg.glyphs) {
      let w = -1;
      if (!g.space) {
        let gap = 0;
        if (prev) {
          const tx = Math.cos(g.angle);
          const ty = -Math.sin(g.angle);
          gap = (g.origin.x - prev.origin.x) * tx + (g.origin.y - prev.origin.y) * ty - prev.advance;
        }
        if (!g.mark && (startNew || !prev || gap > WORD_GAP_EM * Math.max(prev.size, g.size))) {
          wordId = words.length;
          words.push([]);
        }
        if (wordId < 0) {
          wordId = words.length;
          words.push([]);
        }
        w = wordId;
        startNew = false;
        prev = g;
      } else startNew = true;
      const id = glyphs.length;
      const { rotated: _r, ...rest } = g;
      void _r;
      glyphs.push({ ...rest, id, wordId: w, lineId, columnId });
      if (w >= 0) words[w].push(id);
      ids.push(id);
    }
    // trim whitespace at the ends, then build the unit string (virtual space between gap-separated words)
    let a = 0;
    let b = ids.length;
    while (a < b && glyphs[ids[a]].space) a++;
    while (b > a && glyphs[ids[b - 1]].space) b--;
    const core = ids.slice(a, b);
    const charGlyph: number[] = [];
    let text = "";
    let last: Glyph | null = null;
    for (const id of core) {
      const g = glyphs[id];
      if (last && !last.space && !g.space && !g.mark && g.wordId !== last.wordId && g.wordId >= 0 && last.wordId >= 0) {
        text += " ";
        charGlyph.push(-1);
      }
      text += g.char;
      charGlyph.push(id);
      last = g;
    }
    const real = core.map((i) => glyphs[i]).filter((g) => !g.space);
    const first = real[0] ?? glyphs[core[0] ?? ids[0]];
    const sizes = real.map((g) => g.size);
    lines.push({
      id: lineId,
      columnId,
      glyphIds: core,
      bbox: seg.bbox,
      baseline: seg.glyphs[0].baseline,
      size: sizes.length ? median(sizes) : first.size,
      family: first.family,
      bold: first.bold,
      italic: first.italic,
      rotated: Math.abs(first.angle) > 0.05,
      text,
      charGlyph,
      x0: first.origin.x,
      x1: Math.max(...(real.length ? real : [first]).map((g) => g.origin.x + g.advance)),
      paraId: -1,
    });
  });
  const paragraphs = buildParagraphs(lines);
  return { glyphs, lines, units: lines, words, paragraphs, boundaries: notes };
}

/** Paragraph = consecutive units, same column + style + size, normal leading, and a previous line that reaches across the column. */
function buildParagraphs(units: LineInfo[]): Paragraph[] {
  const colExtent = new Map<number, { x0: number; x1: number }>();
  for (const u of units) {
    const e = colExtent.get(u.columnId);
    colExtent.set(u.columnId, { x0: Math.min(e?.x0 ?? Infinity, u.x0), x1: Math.max(e?.x1 ?? -Infinity, u.x1) });
  }
  const paras: Paragraph[] = [];
  let cur: LineInfo[] = [];
  const flush = () => {
    if (!cur.length) return;
    const id = paras.length;
    const pitches = cur.slice(1).map((u, i) => u.baseline - cur[i].baseline);
    const bbox = cur.reduce<Rect>((r, u) => (r.w < 0 ? { ...u.bbox } : { x: Math.min(r.x, u.bbox.x), y: Math.min(r.y, u.bbox.y), w: Math.max(r.x + r.w, u.bbox.x + u.bbox.w) - Math.min(r.x, u.bbox.x), h: Math.max(r.y + r.h, u.bbox.y + u.bbox.h) - Math.min(r.y, u.bbox.y) }), { x: 0, y: 0, w: -1, h: 0 });
    paras.push({ id, unitIds: cur.map((u) => u.id), columnId: cur[0].columnId, bbox, pitch: pitches.length ? median(pitches) : cur[0].size * 1.2 });
    for (const u of cur) u.paraId = id;
    cur = [];
  };
  for (const u of units) {
    const p = cur[cur.length - 1];
    let join = false;
    if (p && !u.rotated && !p.rotated && u.columnId === p.columnId) {
      const pitch = u.baseline - p.baseline;
      const ext = colExtent.get(u.columnId)!;
      const colW = Math.max(1, ext.x1 - ext.x0);
      join =
        Math.abs(u.size - p.size) <= 0.1 * p.size &&
        u.family === p.family &&
        u.bold === p.bold &&
        u.italic === p.italic &&
        pitch >= 0.9 * p.size &&
        pitch <= 1.7 * p.size &&
        Math.abs(u.x0 - p.x0) <= 3 * p.size &&
        p.x1 - p.x0 >= 0.6 * colW;
    }
    if (!join) flush();
    cur.push(u);
  }
  flush();
  return paras;
}

// ---------- hit testing ----------
export const inkCenter = (g: Glyph): Pt => ({ x: g.ink.x + g.ink.w / 2, y: g.ink.y + g.ink.h / 2 });

/**
 * The unit under a point. Called on pointerdown ONLY (never on pointermove). The x tolerance (≤ 2 pt) applies along the
 * baseline only; vertically the point must be inside the line's own ascent/descent band, so gaps between lines,
 * gutters and blank margins return null.
 */
export function unitAt(map: GlyphMap, p: Pt, tol = 2): LineInfo | null {
  const t = Math.min(tol, 2);
  let best: LineInfo | null = null;
  let bestCost = Infinity;
  for (const u of map.units) {
    if (!u.glyphIds.length) continue;
    let inside: boolean;
    let cost: number;
    if (u.rotated) {
      inside = p.x >= u.bbox.x - t && p.x <= u.bbox.x + u.bbox.w + t && p.y >= u.bbox.y - t && p.y <= u.bbox.y + u.bbox.h + t;
      cost = Math.hypot(p.x - (u.bbox.x + u.bbox.w / 2), p.y - (u.bbox.y + u.bbox.h / 2));
    } else {
      inside = p.x >= u.x0 - t && p.x <= u.x1 + t && p.y >= u.baseline - ASC * u.size && p.y <= u.baseline + DESC * u.size;
      cost = Math.abs(p.y - (u.baseline - 0.3 * u.size));
    }
    if (inside && cost < bestCost) {
      best = u;
      bestCost = cost;
    }
  }
  return best;
}

/** Caret position (code-point index in `unit.text`) nearest to a point: the glyph boundary closest to p.x. */
export function caretIndexAt(map: GlyphMap, unit: LineInfo, p: Pt): number {
  for (let i = 0; i < unit.charGlyph.length; i++) {
    const id = unit.charGlyph[i];
    if (id < 0) continue;
    const g = map.glyphs[id];
    if (p.x < g.origin.x + g.advance / 2) return i;
  }
  return unit.charGlyph.length;
}

/** Re-derive a unit's string from its glyphs (guard 1 compares this with the editor's "original text"). */
export function unitTextOf(map: GlyphMap, unit: LineInfo): string {
  let text = "";
  let last: Glyph | null = null;
  for (const id of unit.glyphIds) {
    const g = map.glyphs[id];
    if (last && !last.space && !g.space && !g.mark && g.wordId !== last.wordId && g.wordId >= 0 && last.wordId >= 0) text += " ";
    text += g.char;
    last = g;
  }
  return text;
}

export function paragraphText(map: GlyphMap, para: Paragraph): string {
  return para.unitIds.map((i) => map.units[i].text).join(" ");
}

// ---------- cover geometry (guards 2 + 3) ----------
export type CoverResult = { ok: true; covers: Rect[] } | { ok: false; reason: string };

const overlapArea = (a: Rect, b: Rect) => Math.max(0, Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x)) * Math.max(0, Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y));
const EPS = 0.01;

/**
 * One cover rectangle per line of the given glyphs, built from their tight ink boxes, padded by ≤ 1 pt and clipped away
 * from every glyph NOT in `ids`. If a foreign glyph overlaps the target's own ink the edit is BLOCKED and the offending
 * text is named – a cover is never applied over text outside the edited range.
 */
export function computeCovers(map: GlyphMap, ids: number[], pad = 1): CoverResult {
  const target = new Set(ids);
  const byLine = new Map<number, Glyph[]>();
  for (const id of ids) {
    const g = map.glyphs[id];
    byLine.set(g.lineId, [...(byLine.get(g.lineId) ?? []), g]);
  }
  const covers: Rect[] = [];
  for (const gs of byLine.values()) {
    const inkable = gs.filter((g) => !g.space);
    const T = unionRect((inkable.length ? inkable : gs).map((g) => g.ink));
    let L = T.x - pad;
    let R = T.x + T.w + pad;
    let U = T.y - pad;
    let D = T.y + T.h + pad;
    for (const n of map.glyphs) {
      if (target.has(n.id) || n.space || n.advance <= 0) continue;
      const ni = n.ink;
      if (overlapArea(ni, T) > EPS) {
        const word = n.wordId >= 0 ? map.words[n.wordId].map((i) => map.glyphs[i].char).join("") : n.char;
        return { ok: false, reason: `The text "${word}" overlaps the part you are editing and would be hidden. Edit a smaller part.` };
      }
      if (overlapArea(ni, { x: L, y: U, w: R - L, h: D - U }) <= EPS) continue;
      if (ni.x >= T.x + T.w - EPS) R = Math.min(R, ni.x);
      else if (ni.x + ni.w <= T.x + EPS) L = Math.max(L, ni.x + ni.w);
      else if (ni.y >= T.y + T.h - EPS) D = Math.min(D, ni.y);
      else if (ni.y + ni.h <= T.y + EPS) U = Math.max(U, ni.y + ni.h);
      else return { ok: false, reason: "Neighbouring text is in the way of this edit." };
    }
    covers.push({ x: L, y: U, w: R - L, h: D - U });
  }
  return { ok: true, covers };
}
