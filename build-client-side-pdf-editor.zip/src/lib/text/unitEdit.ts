/**
 * Minimal-diff, structure-preserving edit commit (TASKS-02 Task 2 §2.5). Pure and DOM-free.
 *
 *  1. diff old vs new unit string at character level → changed range;
 *  2. the range is widened to whole WORDS only when the change touches the inside of a word, so unchanged words keep
 *     their exact original glyphs, fonts and positions (they are not covered and not redrawn);
 *  3. STYLE counts as a change: a formatted range (spans) is redrawn too, and a changed base style / move / spacing
 *     redraws the whole unit – otherwise "make this word bold" would silently do nothing;
 *  4. only the changed glyphs are covered (tight, clipped away from every glyph outside the range);
 *  5. if the new text is a different width, ONLY the trailing words of the same unit are re-set and shifted – never past
 *     the next hard boundary (the next unit on the row / the page margin);
 *  6. no room → shrink-to-fit (≥ minScale), overflow, or skip, with a clear message – never a silent overlap;
 *  7. no change at all → nothing; the replacement is real text drawn as ONE line of runs.
 */
import { createObject, wrapText, type PdfObject, type RunStyle, type Span, type TextAlign } from "../model/objects";
import { computeCovers, estimateWidth, paragraphText, unitTextOf, type GlyphMap, type LineInfo, type Paragraph, type Rect } from "./glyphMap";
import { cps, effSize, splitRuns } from "./styleModel";

export type Measure = (text: string, size: number, style: { family: PdfObject["family"]; bold?: boolean; italic?: boolean }) => number;
export type OverflowMode = "shrink" | "overflow" | "skip";

export interface StyleInput {
  base: RunStyle;
  /** per-range overrides, in code points of the NEW unit text */
  spans: Span[];
  /** the base style or the extras differ from the page's own, so unchanged words must be redrawn as well */
  baseChanged: boolean;
  extras?: { bg?: string; opacity?: number; charSpacing?: number; wordSpacing?: number; dx?: number; dy?: number; rotation?: number; locked?: boolean; align?: TextAlign; lineHeight?: number; boxW?: number | null };
}

export interface PlanCtx {
  pageId: string;
  pageW: number;
  colors?: { bg: string; fg: string };
  existing?: PdfObject | null;
  overflow?: OverflowMode;
  /** retry after "Allow overflow" */
  allowOverflow?: boolean;
  minScale?: number;
  measure?: Measure;
  /** the text the editor believed it was editing (guard 1) */
  origText?: string;
  /** formatting chosen in the text sidebar (undefined = keep the page's own look) */
  style?: StyleInput;
}

export type UnitPlan = { ok: true; obj: PdfObject | null; unchanged: boolean; notes: string[] } | { ok: false; error: string; canOverflow?: boolean };

const isSpace = (c: string | undefined) => c === undefined || /^\s$/u.test(c);
const defaultMeasure: Measure = (t, size) => estimateWidth(t, size);
const nSpaces = (s: string) => (s.match(/ /g) ?? []).length;

/**
 * Width of one line of text with per-range styles and spacing. The planner AND the on-screen text box use this one function,
 * so the frame's size and the exported text's size cannot disagree.
 */
export function unitTextWidth(text: string, base: RunStyle, spans: Span[], sp: { charSpacing?: number; wordSpacing?: number }, measure: Measure = defaultMeasure): number {
  const cs = sp.charSpacing ?? 0;
  const ws = sp.wordSpacing ?? 0;
  return splitRuns(text, base, spans).reduce((a, r) => a + measure(r.text, effSize(r.style), { family: r.style.family, bold: r.style.bold, italic: r.style.italic }) + cs * cps(r.text).length + ws * nSpaces(r.text), 0);
}

/**
 * Changed range of `a` (old) → `b` (new). `a` is widened to word boundaries only when the change touches the inside of
 * a word; pure insertions at a word boundary stay pure insertions (no neighbour is re-set).
 * Returns old range [from, toOld) and the replacing slice of the new text [from, toNew).
 */
export function diffRange(oldCP: string[], newCP: string[]): { from: number; toOld: number; toNew: number } {
  let p = 0;
  const max = Math.min(oldCP.length, newCP.length);
  while (p < max && oldCP[p] === newCP[p]) p++;
  let s = 0;
  while (s < max - p && oldCP[oldCP.length - 1 - s] === newCP[newCP.length - 1 - s]) s++;
  let from = p;
  let toOld = oldCP.length - s;
  let toNew = newCP.length - s;
  const leftInside = from > 0 && !isSpace(oldCP[from - 1]) && (!isSpace(newCP[from]) && newCP[from] !== undefined ? true : !isSpace(oldCP[from]) && oldCP[from] !== undefined);
  if (leftInside) while (from > 0 && !isSpace(oldCP[from - 1])) from--;
  const rightInside = toOld < oldCP.length && !isSpace(oldCP[toOld]) && ((toOld > 0 && !isSpace(oldCP[toOld - 1])) || (toNew > 0 && !isSpace(newCP[toNew - 1])));
  if (rightInside) {
    while (toOld < oldCP.length && !isSpace(oldCP[toOld])) {
      toOld++;
      toNew++;
    }
  }
  return { from, toOld, toNew };
}

/** First real glyph at or after char index i (page-space x of that glyph), or the unit's right edge. */
function xAt(map: GlyphMap, u: LineInfo, i: number): number {
  for (let k = i; k < u.charGlyph.length; k++) if (u.charGlyph[k] >= 0) return map.glyphs[u.charGlyph[k]].origin.x;
  return u.x1;
}

/** Nearest foreign glyph to the right of the unit on the same row = its hard right boundary (page margin otherwise). */
export function rightLimit(map: GlyphMap, u: LineInfo, pageW: number): number {
  let lim = pageW - 18;
  for (const g of map.glyphs) {
    if (g.lineId === u.id || g.space || g.mark) continue;
    if (g.ink.y >= u.bbox.y + u.bbox.h || g.ink.y + g.ink.h <= u.bbox.y) continue;
    if (g.ink.x >= u.x1 - 1) lim = Math.min(lim, g.ink.x - 2);
  }
  return lim;
}

/** What the unit currently reads (original text with an earlier edit applied). */
export function effectiveUnitText(unit: LineInfo, existing?: PdfObject | null): string {
  if (!existing || existing.unitKey !== `u${unit.id}` || existing.unitFull === undefined) return unit.text;
  const full = cps(existing.unitFull);
  return full.slice(0, existing.unitA ?? 0).join("") + (existing.text ?? "") + full.slice(existing.unitEnd ?? full.length).join("");
}

export function effectiveParagraphText(map: GlyphMap, para: Paragraph, existing?: PdfObject | null): string {
  return existing && existing.unitKey === `p${para.id}` && existing.logical !== undefined ? existing.logical : paragraphText(map, para);
}

/**
 * Spans of the WHOLE unit text as they apply to an earlier edit's replaced fragment (so re-opening a styled edit shows its
 * formatting). Only the fragment's own spans are known; the rest of the line has the base style.
 */
export function effectiveUnitSpans(unit: LineInfo, existing?: PdfObject | null): Span[] {
  if (!existing || existing.unitKey !== `u${unit.id}` || !existing.spans?.length) return [];
  const a = existing.unitA ?? 0;
  return existing.spans.map((s) => ({ a: s.a + a, b: s.b + a, s: s.s }));
}

const pct = (n: number) => `${Math.round(n * 100)}%`;
const rebase = (spans: Span[], from: number, len: number): Span[] => spans.map((s) => ({ a: Math.max(0, s.a - from), b: Math.min(len, s.b - from), s: s.s })).filter((s) => s.a < s.b);

/** Plan the edit of ONE unit. `newTextRaw` is the full new text of the unit. */
export function planUnitEdit(map: GlyphMap, unit: LineInfo, newTextRaw: string, ctx: PlanCtx): UnitPlan {
  if (unit.rotated) return { ok: false, error: "Rotated or skewed text can't be edited in place. Use Whiteout + Text box instead." };
  // guard 1: the editor's original text must equal the unit's glyphs
  const actual = unitTextOf(map, unit);
  if (actual !== unit.text || (ctx.origText !== undefined && ctx.origText !== effectiveUnitText(unit, ctx.existing) && ctx.origText !== unit.text)) {
    return { ok: false, error: "The text being edited no longer matches the page text. Nothing was changed; click the line again." };
  }
  const measure = ctx.measure ?? defaultMeasure;
  const sty = ctx.style;
  const newText = newTextRaw.replace(/\s*[\r\n]+\s*/g, " ");
  const styled = !!sty && (sty.baseChanged || sty.spans.length > 0);
  // no change (relative to the ORIGINAL unit) → nothing to draw; an earlier edit of this unit is reverted
  if (newText === unit.text && !styled) return { ok: true, obj: null, unchanged: true, notes: [] };

  const oldCP = cps(unit.text);
  const newCP = cps(newText);
  let { from, toOld, toNew } = diffRange(oldCP, newCP);
  if (sty?.baseChanged) {
    from = 0; // the base style / position changed: every word is redrawn
    toOld = oldCP.length;
    toNew = newCP.length;
  } else if (sty && sty.spans.length) {
    // a formatted range must be redrawn even if its characters did not change
    const sMin = Math.max(0, Math.min(...sty.spans.map((s) => s.a)));
    const sMax = Math.min(newCP.length, Math.max(...sty.spans.map((s) => s.b)));
    if (newText === unit.text) {
      // characters identical: the changed range is EXACTLY the formatted range. (Unioning with the empty diff, which sits at the
      // end of the line, would redraw every word after the formatted one.)
      from = sMin;
      toNew = sMax;
      toOld = sMax;
    } else {
      const shift = toNew - toOld;
      if (sMin < from) from = sMin;
      if (sMax > toNew) {
        toNew = sMax;
        toOld = Math.max(from, Math.min(oldCP.length, toNew - shift));
      }
    }
  }

  const g0 = map.glyphs[unit.charGlyph.slice(from).find((id) => id >= 0) ?? unit.charGlyph.filter((id) => id >= 0).pop() ?? unit.glyphIds[0]];
  const base: RunStyle = sty?.base ?? { family: g0.family, size: unit.size, bold: g0.bold, italic: g0.italic, underline: false, strike: false, script: "none", color: ctx.existing?.color ?? ctx.colors?.fg ?? "#000000" };
  const ex = sty?.extras ?? {};
  const cs = ex.charSpacing ?? 0;
  const ws = ex.wordSpacing ?? 0;
  const size = base.size;
  const widthOf = (text: string, spans: Span[]) => unitTextWidth(text, base, spans, { charSpacing: cs, wordSpacing: ws }, measure);

  const rangeIds = unit.charGlyph.slice(from, toOld).filter((id) => id >= 0);
  const x = xAt(map, unit, from);
  const fragCP = newCP.slice(from, toNew);
  const frag = fragCP.join("");
  const fragSpans = rebase(sty?.spans ?? [], from, fragCP.length);
  const oldRight = rangeIds.length ? Math.max(...rangeIds.map((id) => map.glyphs[id]).filter((g) => !g.space).map((g) => g.ink.x + g.ink.w), x) : x;
  const delta = widthOf(frag, fragSpans) - (oldRight - x);

  // trailing words of THIS unit are re-set and shifted only when the width changed
  const includeTrailing = toOld < oldCP.length && Math.abs(delta) > 0.5;
  const coverEnd = includeTrailing ? oldCP.length : toOld;
  const text = frag + (includeTrailing ? oldCP.slice(toOld).join("") : "");
  const coverIds = unit.charGlyph.slice(from, coverEnd).filter((id) => id >= 0);

  let covers: Rect[] = [];
  if (coverIds.length) {
    const c = computeCovers(map, coverIds);
    if (!c.ok) return { ok: false, error: c.reason };
    covers = c.covers; // guards 2+3: only glyphs inside the range, clipped away from everything else
  }
  if (!text && !covers.length) return { ok: true, obj: null, unchanged: true, notes: [] };

  const notes: string[] = [];
  let fontSize = size;
  let outSpans = fragSpans;
  const runW = widthOf(text, fragSpans);
  const dx0 = ex.dx ?? 0;
  const dy0 = ex.dy ?? 0;
  let limit = rightLimit(map, unit, ctx.pageW);
  if (dx0 || dy0) limit = ctx.pageW - 6; // the user placed it on purpose: the old neighbour is no longer next to it
  // the text box the user drew / typed a width for (frame handle or sidebar) is a limit too: shrink-to-fit applies
  if (ex.boxW != null) limit = Math.min(limit, unit.x0 - 1 + dx0 + ex.boxW - 1);
  const xp = x + dx0;
  if (xp + runW > limit + 0.5) {
    const avail = limit - xp;
    const scale = avail / Math.max(1, runW);
    const mode: OverflowMode = ctx.allowOverflow ? "overflow" : (ctx.overflow ?? "shrink");
    if (mode === "overflow") notes.push("The text runs past the space available and may touch neighbouring content.");
    else if (mode === "shrink" && scale >= (ctx.minScale ?? 0.6)) {
      fontSize = size * scale;
      outSpans = fragSpans.map((s) => (s.s.size ? { ...s, s: { ...s.s, size: s.s.size * scale } } : s));
      notes.push(`Shrunk to ${pct(scale)} to fit the space available.`);
    } else if (mode === "shrink") {
      return { ok: false, canOverflow: true, error: `No room: the text would have to shrink to ${pct(scale)} (minimum ${pct(ctx.minScale ?? 0.6)}) before it hits the neighbouring text ${Math.max(0, Math.round(avail))} pt away.` };
    } else return { ok: false, error: "No space for the longer text (skipped as chosen)." };
  }

  const y0 = unit.bbox.y;
  const dx = ex.dx ?? 0;
  const dy = ex.dy ?? 0;
  const o = createObject("textedit", ctx.pageId, x + dx, y0 + dy, Math.max((runW * fontSize) / size, 4), Math.max(unit.bbox.h, 4));
  Object.assign(o, {
    text,
    origText: oldCP.slice(from, coverEnd).join(""),
    unitKey: `u${unit.id}`,
    unitFull: unit.text,
    unitA: from,
    unitEnd: coverEnd,
    covers,
    fontSize,
    family: base.family,
    bold: base.bold,
    italic: base.italic,
    underline: base.underline,
    strike: base.strike,
    script: base.script,
    spans: outSpans.length ? outSpans : undefined,
    charSpacing: cs || undefined,
    wordSpacing: ws || undefined,
    opacity: ex.opacity ?? 1,
    rotation: ex.rotation ?? 0,
    locked: ex.locked || undefined,
    dx: dx || undefined,
    dy: dy || undefined,
    restyled: styled || undefined,
    color: base.color,
    bg: ex.bg ?? ctx.existing?.bg ?? ctx.colors?.bg ?? "#ffffff",
    baseline: unit.baseline - y0,
    fill: null,
  });
  return { ok: true, obj: o, unchanged: false, notes };
}

/** Optional "reflow paragraph" mode: the whole paragraph is replaced by ONE wrapped text object. Per-range spans do not apply here. */
export function planParagraphEdit(map: GlyphMap, para: Paragraph, newTextRaw: string, ctx: PlanCtx): UnitPlan {
  const units = para.unitIds.map((i) => map.units[i]);
  if (units.some((u) => u.rotated)) return { ok: false, error: "Rotated or skewed text can't be edited in place." };
  const measure = ctx.measure ?? defaultMeasure;
  const sty = ctx.style;
  const oldText = paragraphText(map, para);
  const newText = newTextRaw.replace(/[ \t]+$/gm, "");
  if (newText === oldText && !sty?.baseChanged) return { ok: true, obj: null, unchanged: true, notes: [] };

  const ids = units.flatMap((u) => u.glyphIds).filter((id) => !map.glyphs[id].space);
  const c = computeCovers(map, ids);
  if (!c.ok) return { ok: false, error: c.reason };
  const first = units[0];
  const ex = sty?.extras ?? {};
  const base: RunStyle = sty?.base ?? { family: first.family, size: first.size, bold: first.bold, italic: first.italic, underline: false, strike: false, script: "none", color: ctx.existing?.color ?? ctx.colors?.fg ?? "#000000" };
  const cs = ex.charSpacing ?? 0;
  const ws = ex.wordSpacing ?? 0;
  const pitch = ex.lineHeight ?? para.pitch;
  const x0 = Math.min(...units.map((u) => u.x0));
  const W = ex.boxW ?? Math.max(...units.map((u) => u.x1)) - x0; // a width dragged on the frame (or typed in the sidebar) reflows the paragraph
  const lineW = (s: string) => measure(s, base.size, base) + cs * cps(s).length + ws * nSpaces(s);
  const lines = wrapText(newText, W, lineW);
  const extra = lines.length - units.length;
  const last = units[units.length - 1];
  if (extra > 0) {
    const below: Rect = { x: x0, y: last.baseline + 0.2 * last.size, w: W, h: extra * pitch };
    const inPara = new Set(ids);
    for (const g of map.glyphs) {
      if (inPara.has(g.id) || g.space) continue;
      if (g.ink.x < below.x + below.w && g.ink.x + g.ink.w > below.x && g.ink.y < below.y + below.h && g.ink.y + g.ink.h > below.y) {
        return { ok: false, error: `Not enough room below the paragraph for ${extra} more line${extra === 1 ? "" : "s"}: other content is in the way.` };
      }
    }
  }
  const y0 = first.bbox.y;
  const o = createObject("textedit", ctx.pageId, x0 + (ex.dx ?? 0), y0 + (ex.dy ?? 0), Math.max(W, 4), Math.max((lines.length - 1) * pitch + first.bbox.h, 4));
  Object.assign(o, {
    text: lines.join("\n"),
    logical: newText,
    origText: oldText,
    unitKey: `p${para.id}`,
    lineHeight: pitch,
    covers: c.covers,
    fontSize: base.size,
    family: base.family,
    bold: base.bold,
    italic: base.italic,
    underline: base.underline,
    strike: base.strike,
    script: base.script,
    align: ex.align ?? "left",
    charSpacing: cs || undefined,
    wordSpacing: ws || undefined,
    opacity: ex.opacity ?? 1,
    rotation: ex.rotation ?? 0,
    locked: ex.locked || undefined,
    dx: ex.dx || undefined,
    dy: ex.dy || undefined,
    restyled: sty?.baseChanged || undefined,
    color: base.color,
    bg: ex.bg ?? ctx.existing?.bg ?? ctx.colors?.bg ?? "#ffffff",
    baseline: first.baseline - y0,
    fill: null,
  });
  return { ok: true, obj: o, unchanged: false, notes: extra < 0 ? [] : extra > 0 ? [`The paragraph grew by ${extra} line${extra === 1 ? "" : "s"}.`] : [] };
}
