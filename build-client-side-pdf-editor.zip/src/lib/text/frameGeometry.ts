/**
 * Active text box ("frame") geometry (TASKS-02 §2.4C, F45). Pure and DOM-free so every handle can be unit-tested.
 *
 * All coordinates are PAGE SPACE (pt, origin top-left of the crop box, y down) – the space `lib/model/coords.ts` converts to
 * the screen – so page rotation, CropBox offset, zoom and scroll need no code here. The frame rotates about a PIVOT, which is
 * the centre of the box of the text object that will be exported (export rotates an object about its own centre), so what the
 * frame shows is exactly where the text lands.
 */
import { rotateAbout } from "../model/coords";
import type { Pt, Rect } from "./glyphMap";

export type Box = Rect;
export type HandleId = "nw" | "n" | "ne" | "e" | "se" | "s" | "sw" | "w";

/** Screen-pixel constants (the frame is drawn in page space, so they are divided by zoom: look is constant at every zoom). */
export const FRAME_PAD_PX = 3; // visual-only padding around the unit; never affects cover / removal geometry
export const STROKE_PX = 1.5;
export const OUTER_STROKE_PX = 3.5; // white halo under the accent line so it reads on dark, light and image backgrounds
export const HANDLE_PX = 9;
export const BORDER_HIT_PX = 12;
export const ROTATE_OFFSET_PX = 24;
export const GRIP_PX = 16;
export const GRIP_OFFSET_PX = 26;

export const HANDLES: { id: HandleId; hx: 0 | 0.5 | 1; hy: 0 | 0.5 | 1; label: string }[] = [
  { id: "nw", hx: 0, hy: 0, label: "Resize top-left corner" },
  { id: "n", hx: 0.5, hy: 0, label: "Resize top edge" },
  { id: "ne", hx: 1, hy: 0, label: "Resize top-right corner" },
  { id: "e", hx: 1, hy: 0.5, label: "Resize right edge" },
  { id: "se", hx: 1, hy: 1, label: "Resize bottom-right corner" },
  { id: "s", hx: 0.5, hy: 1, label: "Resize bottom edge" },
  { id: "sw", hx: 0, hy: 1, label: "Resize bottom-left corner" },
  { id: "w", hx: 0, hy: 0.5, label: "Resize left edge" },
];
export const ROTATE_LABEL = "Rotate text box";
export const MOVE_LABEL = "Move text box";
export const BORDER_LABEL = "Text box border. Arrow keys move the text, Escape returns to typing.";

/** Direction of each handle from the box centre, clockwise degrees from east (screen, y down). */
const DIR: Record<HandleId, number> = { e: 0, se: 45, s: 90, sw: 135, w: 180, nw: 225, n: 270, ne: 315 };

/** Resize cursor that matches the handle's direction AFTER the box (page rotation + text rotation) has been rotated. */
export function cursorFor(id: HandleId, totalRotationDeg: number): string {
  const a = (((DIR[id] + totalRotationDeg) % 180) + 180) % 180;
  return ["ew-resize", "nwse-resize", "ns-resize", "nesw-resize"][Math.round(a / 45) % 4];
}

export const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
export const snapAngle = (deg: number, step = 15) => Math.round(deg / step) * step;
/** → (-180, 180] */
export const normDeg = (d: number) => {
  const x = ((d % 360) + 360) % 360;
  return x > 180 ? x - 360 : x;
};
/** Angle of `p` seen from `pivot`, clockwise, 0° = straight up. */
export const angleAt = (pivot: Pt, p: Pt): number => normDeg((Math.atan2(p.y - pivot.y, p.x - pivot.x) * 180) / Math.PI + 90);
export const rotateVec = (v: Pt, deg: number): Pt => {
  const t = (deg * Math.PI) / 180;
  return { x: v.x * Math.cos(t) - v.y * Math.sin(t), y: v.x * Math.sin(t) + v.y * Math.cos(t) };
};
/** Pointer in the box's own (un-rotated) frame. */
export const toLocal = (p: Pt, pivot: Pt, rotation: number): Pt => rotateAbout(p, pivot, -rotation);

export const pivotOf = (objBox: Box, dx: number, dy: number): Pt => ({ x: objBox.x + dx + objBox.w / 2, y: objBox.y + dy + objBox.h / 2 });

export function insideBox(p: Pt, box: Box, pivot: Pt, rotation: number, pad = 0): boolean {
  const q = toLocal(p, pivot, rotation);
  return q.x >= box.x - pad && q.x <= box.x + box.w + pad && q.y >= box.y - pad && q.y <= box.y + box.h + pad;
}

export interface FrameShape {
  kind: "unit" | "para";
  /** the unit's ORIGINAL rect (1 pt inset around its line band) */
  rect: Rect;
  baseline: number;
  /** current font size ÷ detected font size (line mode: the box scales about the baseline, exactly like the exported text) */
  scale: number;
  width: number;
  /** paragraph height (line mode derives it) */
  height: number;
  dx: number;
  dy: number;
}
export function frameBox(f: FrameShape): Box {
  if (f.kind === "unit") {
    const k = f.scale;
    return { x: f.rect.x + f.dx, y: f.baseline - (f.baseline - f.rect.y) * k + f.dy, w: f.width, h: f.rect.h * k };
  }
  return { x: f.rect.x + f.dx, y: f.rect.y + f.dy, w: f.width, h: f.height };
}

export interface ResizeStart {
  box: Box;
  pivot: Pt;
  rotation: number;
  kind: "unit" | "para";
  /** base font size when the gesture began */
  size: number;
  /** width of the text at that size, plus the 2 pt inset (line mode) */
  naturalW: number;
  lineHeight: number;
  boxW: number | null;
  dx: number;
  dy: number;
  minScale: number;
}
export interface FramePatch {
  dx: number;
  dy: number;
  boxW: number | null;
  /** font-size factor relative to the size at the start of the gesture */
  scale: number;
  lineHeight: number;
}

/**
 * What dragging a handle does (spec §2.4C):
 *  - e / w, or a corner WITHOUT Shift → box width. Paragraph: the text reflows. Line: a width below the text's natural width
 *    applies shrink-to-fit (never below `minScale`); a wider box just gives the text room (it does not grow the text).
 *  - corner WITH Shift → font size scales proportionally, anchored at the opposite corner.
 *  - n / s → line mode: font size (height follows the font); paragraph mode: line spacing.
 * Everything is computed in the box's own frame, so rotated boxes resize along their own axes.
 */
export function resizeBy(s: ResizeStart, id: HandleId, pointer: Pt, shift: boolean): FramePatch {
  const h = HANDLES.find((x) => x.id === id)!;
  const q = toLocal(pointer, s.pivot, s.rotation);
  const { x: L, y: T, w, h: H } = s.box;
  const R = L + w;
  const B = T + H;
  let nL = L;
  let scale = 1;
  let boxW = s.boxW;
  let lineHeight = s.lineHeight;
  const corner = h.hx !== 0.5 && h.hy !== 0.5;

  if (corner && shift) {
    const rw = (h.hx === 0 ? R - q.x : q.x - L) / w;
    const rh = (h.hy === 0 ? B - q.y : q.y - T) / H;
    const ratio = clamp(Math.abs(rw - 1) >= Math.abs(rh - 1) ? rw : rh, 0.2, 8);
    const nw = w * ratio;
    scale = ratio;
    if (h.hx === 0) nL = R - nw;
    if (s.kind === "para") {
      lineHeight = s.lineHeight * ratio;
      boxW = nw;
    } else if (s.boxW !== null) boxW = s.boxW * ratio;
  } else if (h.hx === 0.5) {
    const ratio = clamp((h.hy === 0 ? B - q.y : q.y - T) / H, 0.2, 8);
    if (s.kind === "unit") {
      scale = ratio;
      if (s.boxW !== null) boxW = s.boxW * ratio;
    } else lineHeight = clamp(s.lineHeight * ratio, 0.6 * s.size, 4 * s.size);
  } else {
    const minW = s.kind === "unit" ? Math.max(4, s.minScale * s.naturalW) : Math.max(24, 2 * s.size);
    nL = h.hx === 0 ? Math.min(q.x, R - minW) : L;
    const nR = h.hx === 1 ? Math.max(q.x, L + minW) : R;
    const newW = nR - nL;
    boxW = newW;
    if (s.kind === "unit") scale = Math.min(1, newW / s.naturalW);
  }
  // moving the left edge translates the text rigidly along the box's own (rotated) x axis
  const d = rotateVec({ x: nL - L, y: 0 }, s.rotation);
  return { dx: s.dx + d.x, dy: s.dy + d.y, boxW, scale, lineHeight };
}

/** Rotation after dragging the rotate handle: relative to where the gesture began (no jump), optionally snapped to 15°. */
export function rotateTo(pivot: Pt, startPointer: Pt, pointer: Pt, startRotation: number, shift: boolean): number {
  const r = normDeg(startRotation + normDeg(angleAt(pivot, pointer) - angleAt(pivot, startPointer)));
  return Math.round((shift ? snapAngle(r) : r) * 10) / 10;
}
