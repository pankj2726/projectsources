/**
 * Edit-session store (TASKS-02 §2.4A / §2.4C). THE reason the text sidebar disappeared: panel visibility used to follow the
 * object selection, and the one-click inline editor never selects anything. The session is its own state, opened in the
 * SAME tick as the inline editor, closed only when the edit closes, never driven by hover. The text box frame (F45) and the
 * sidebar are two views of this one store, so a handle drag updates the sidebar's Box fields live and vice versa.
 */
import { create } from "zustand";
import { textDefaults, type RunStyle, type Span, type TextAlign, type TextDefaults } from "../model/objects";
import { applyToRange, cps, reconcileSpans, setBase, u16ToCp, sameStyle, type RunKey } from "./styleModel";
import type { FramePatch } from "./frameGeometry";

export interface Detected {
  /** original font name with the subset prefix stripped ("" = unknown) */
  fontLabel: string;
  substituted: boolean;
  fontEstimated: boolean;
  sizeEstimated: boolean;
  color: string;
  colorEstimated: boolean;
  style: RunStyle;
}

export interface Extras {
  bg: string;
  opacity: number;
  align: TextAlign;
  /** baseline-to-baseline distance (pt) – paragraph mode */
  lineHeight: number;
  charSpacing: number;
  wordSpacing: number;
  dx: number;
  dy: number;
  rotation: number;
  locked: boolean;
  /** box width the user set (frame handle or sidebar); null = the box follows the text */
  boxW: number | null;
}

interface Snap {
  base: RunStyle;
  spans: Span[];
  extras: Extras;
}

export interface EditSession {
  key: string;
  pageId: string;
  kind: "unit" | "para";
  unitId: number;
  /** mirror of the editor text (kept in sync by the inline editor and by the sidebar's Text box) */
  text: string;
  /** the text when the editor opened (guard 1 compares the page with this; the sidebar's "Original: …" shows it) */
  orig: string;
  detected: Detected;
  detectedExtras: Extras;
  base: RunStyle;
  spans: Span[];
  extras: Extras;
  /** selection in code points */
  sel: { a: number; b: number };
  /** selection in UTF-16 units, to restore the caret exactly when focus returns to the editor */
  selU16: { s: number; e: number };
  /** live size of the text box frame (pt), written by the layer so the sidebar can show it */
  boxW: number;
  boxH: number;
  hasExisting: boolean;
  initial: Snap;
  past: Snap[];
  future: Snap[];
  lastTag: string;
  lastPush: number;
  /** a frame drag is in progress: every change inside it belongs to ONE undo step */
  gesture: boolean;
  /** TASKS-03 Task D: original formatting is LOCKED by default – style controls and box handles are read-only */
  locked: boolean;
  /** characters typed that the original font cannot encode (Task D.3 chip) */
  substituted: string[];
}

const DEFAULTS_KEY = "qf-text-defaults";
function loadDefaults(): TextDefaults {
  try {
    const raw = localStorage.getItem(DEFAULTS_KEY);
    if (raw) return { ...textDefaults, ...(JSON.parse(raw) as Partial<TextDefaults>) };
  } catch {
    /* storage unavailable or corrupt: fall back */
  }
  return { ...textDefaults };
}
Object.assign(textDefaults, typeof window !== "undefined" ? loadDefaults() : {});

const snapOf = (s: Pick<EditSession, "base" | "spans" | "extras">): Snap => ({ base: s.base, spans: s.spans, extras: s.extras });
const COALESCE_MS = 700;

interface State {
  session: EditSession | null;
  defaults: TextDefaults;
  recent: string[];
  /** "Remember unlocked" (Task D.2) */
  rememberUnlock: boolean;
  /** `locked` defaults to ON (true) and `substituted` to [] unless the caller says otherwise. */
  begin(s: Omit<EditSession, "past" | "future" | "lastTag" | "lastPush" | "initial" | "gesture" | "locked" | "substituted">): void;
  end(): void;
  setText(t: string): void;
  /** The sidebar's Text box: replace the text and drop the caret at the end. */
  setTextFromSidebar(t: string): void;
  setSel(u16s: number, u16e: number): void;
  setSel(u16s: number, u16e: number): void;
  patchRun(p: Partial<RunStyle>): void;
  patchExtras(p: Partial<Extras>): void;
  /** frame resize: restores the size / spans the gesture started from, applies the scale, and writes the box fields */
  applyFrame(start: { base: RunStyle; spans: Span[] }, patch: FramePatch): void;
  beginGesture(): void;
  endGesture(): void;
  setBox(w: number, h: number): void;
  undo(): void;
  redo(): void;
  resetFormatting(): void;
  matchOriginalFont(): void;
  setDefaults(p: Partial<TextDefaults>): void;
  addRecent(hex: string): void;
  /** Task D.3: record characters that needed a substitute font. */
  noteSubstituted(chars: string[]): void;
  /** Task D: unlock / relock the formatting of the CURRENT edit (auto-relocks when the edit ends). */
  setLocked(v: boolean): void;
  setRememberUnlock(v: boolean): void;
}

type History = Pick<EditSession, "past" | "future" | "lastTag" | "lastPush">;
function push(s: EditSession, tag: string): History {
  if (s.gesture) return { past: s.past, future: s.future, lastTag: s.lastTag, lastPush: s.lastPush }; // already recorded by beginGesture()
  const now = performance.now();
  const coalesce = tag === s.lastTag && now - s.lastPush < COALESCE_MS && s.past.length > 0;
  return { past: coalesce ? s.past : [...s.past, snapOf(s)].slice(-60), future: [], lastTag: tag, lastPush: now };
}

const r2 = (n: number) => Math.round(n * 100) / 100;

export const useEditSession = create<State>((set, get) => ({
  session: null,
  defaults: loadDefaults(),
  rememberUnlock: (() => {
    try {
      return localStorage.getItem("qf-format-unlock") === "1";
    } catch {
      return false;
    }
  })(),
  recent: (() => {
    try {
      return JSON.parse(localStorage.getItem("qf-recent-colors") ?? "[]") as string[];
    } catch {
      return [];
    }
  })(),
  begin: (s) => set({ session: { ...s, locked: get().rememberUnlock ? false : true, substituted: [], past: [], future: [], lastTag: "", lastPush: 0, gesture: false, initial: { base: s.base, spans: s.spans, extras: s.extras } } }),
  end: () => set({ session: null, rememberUnlock: get().rememberUnlock }),
  setLocked(v: boolean) {
    const s = get().session;
    if (!s) return;
    set({ session: { ...s, locked: v } });
    if (!v && get().rememberUnlock) {
      try {
        localStorage.setItem("qf-format-unlock", "1");
      } catch {
        /* ignore */
      }
    }
  },
  noteSubstituted(chars: string[]) {
    const s = get().session;
    if (!s || !chars.length) return;
    const all = [...new Set([...s.substituted, ...chars])];
    set({ session: { ...s, substituted: all } });
  },
  setText(t) {
    const s = get().session;
    if (!s || s.text === t) return;
    const len = cps(t).length;
    set({ session: { ...s, text: t, spans: reconcileSpans(s.text, t, s.spans), sel: { a: Math.min(s.sel.a, len), b: Math.min(s.sel.b, len) } } });
  },
  setTextFromSidebar(t) {
    get().setText(t);
    const s = get().session;
    if (s) set({ session: { ...s, selU16: { s: t.length, e: t.length } } });
  },
  setSel(u16s, u16e) {
    const s = get().session;
    if (!s) return;
    const a = u16ToCp(s.text, Math.min(u16s, u16e));
    const b = u16ToCp(s.text, Math.max(u16s, u16e));
    if (a === s.sel.a && b === s.sel.b && s.selU16.s === u16s && s.selU16.e === u16e) return;
    set({ session: { ...s, sel: { a, b }, selU16: { s: u16s, e: u16e } } });
  },
  patchRun(p) {
    const s = get().session;
    if (!s) return;
    const tag = `run:${Object.keys(p).sort().join(",")}`;
    const { a, b } = s.sel;
    let next: { base: RunStyle; spans: Span[] };
    if (a === b) next = setBase(s.base, s.spans, p); // caret only: the whole unit and newly typed text
    else next = { base: s.base, spans: applyToRange(cps(s.text).length, s.base, s.spans, a, b, p) }; // range: only the selection
    set({ session: { ...s, ...next, ...push(s, tag) } });
    if (p.color) get().addRecent(p.color);
  },
  patchExtras(p) {
    const s = get().session;
    if (!s) return;
    set({ session: { ...s, extras: { ...s.extras, ...p }, ...push(s, `extras:${Object.keys(p).sort().join(",")}`) } });
  },
  applyFrame(start, patch) {
    const s = get().session;
    if (!s) return;
    const f = patch.scale;
    const base = f === 1 ? start.base : { ...start.base, size: r2(start.base.size * f) };
    const spans = f === 1 ? start.spans : start.spans.map((sp) => (sp.s.size ? { ...sp, s: { ...sp.s, size: r2(sp.s.size * f) } } : sp));
    const extras = { ...s.extras, dx: r2(patch.dx), dy: r2(patch.dy), boxW: patch.boxW === null ? null : r2(patch.boxW), lineHeight: r2(patch.lineHeight) };
    set({ session: { ...s, base, spans, extras, ...push(s, "frame") } });
  },
  beginGesture() {
    const s = get().session;
    if (!s || s.gesture) return;
    set({ session: { ...s, past: [...s.past, snapOf(s)].slice(-60), future: [], gesture: true, lastTag: "" } });
  },
  endGesture() {
    const s = get().session;
    if (!s || !s.gesture) return;
    const prev = s.past[s.past.length - 1];
    const unchanged = !!prev && JSON.stringify(prev) === JSON.stringify(snapOf(s)); // a click without a drag leaves no undo step
    set({ session: { ...s, gesture: false, past: unchanged ? s.past.slice(0, -1) : s.past, lastTag: "" } });
  },
  setBox(w, h) {
    const s = get().session;
    if (!s || (Math.abs(s.boxW - w) < 0.05 && Math.abs(s.boxH - h) < 0.05)) return;
    set({ session: { ...s, boxW: w, boxH: h } });
  },
  undo() {
    const s = get().session;
    if (!s || !s.past.length) return;
    const prev = s.past[s.past.length - 1];
    set({ session: { ...s, ...prev, past: s.past.slice(0, -1), future: [snapOf(s), ...s.future], lastTag: "" } });
  },
  redo() {
    const s = get().session;
    if (!s || !s.future.length) return;
    const [nx, ...rest] = s.future;
    set({ session: { ...s, ...nx, past: [...s.past, snapOf(s)], future: rest, lastTag: "" } });
  },
  resetFormatting() {
    const s = get().session;
    if (!s) return;
    set({ session: { ...s, base: s.detected.style, spans: [], extras: s.detectedExtras, ...push(s, "reset") } });
  },
  matchOriginalFont() {
    const s = get().session;
    if (!s) return;
    get().patchRun({ family: s.detected.style.family, bold: s.detected.style.bold, italic: s.detected.style.italic });
  },
  setDefaults(p) {
    const defaults = { ...get().defaults, ...p };
    Object.assign(textDefaults, defaults);
    try {
      localStorage.setItem(DEFAULTS_KEY, JSON.stringify(defaults));
    } catch {
      /* ignore */
    }
    set({ defaults });
  },
  addRecent(hex) {
    const recent = [hex, ...get().recent.filter((c) => c !== hex)].slice(0, 8);
    try {
      localStorage.setItem("qf-recent-colors", JSON.stringify(recent));
    } catch {
      /* ignore */
    }
    set({ recent });
  },
  setRememberUnlock(v: boolean) {
    try {
      if (v) localStorage.setItem("qf-format-unlock", "1");
      else localStorage.removeItem("qf-format-unlock");
    } catch {
      /* ignore */
    }
    set({ rememberUnlock: v });
  },
}));

/** Has the user changed anything since the editor opened? (text is compared by the caller) */
export function styleDirty(s: EditSession): boolean {
  return !sameStyle(s.base, s.initial.base) || JSON.stringify(s.spans) !== JSON.stringify(s.initial.spans) || JSON.stringify(s.extras) !== JSON.stringify(s.initial.extras);
}

/** Does the style differ from what the page already has, so that unchanged words must be redrawn too? */
export function styleDiffersFromOriginal(s: EditSession): { baseChanged: boolean; hasSpans: boolean } {
  const e = s.extras;
  const d = s.detectedExtras;
  const moved = e.dx !== 0 || e.dy !== 0 || e.rotation !== 0;
  // a line's box width is only a LIMIT (shrink-to-fit), so it does not redraw unchanged words; a paragraph's width reflows it
  const extrasChanged = e.charSpacing !== d.charSpacing || e.wordSpacing !== d.wordSpacing || e.opacity !== d.opacity || e.bg !== d.bg || (s.kind === "para" && (e.align !== d.align || e.lineHeight !== d.lineHeight || e.boxW !== d.boxW));
  return { baseChanged: !sameStyle(s.base, s.detected.style) || moved || extrasChanged, hasSpans: s.spans.length > 0 };
}

export const RUN_PROP_LABEL: Record<RunKey, string> = { family: "font", size: "size", bold: "bold", italic: "italic", underline: "underline", strike: "strikethrough", script: "super/subscript", color: "colour" };

// ---------------- cross-component hooks ----------------
let focusFn: (() => void) | null = null;
/** The inline editor registers how to refocus itself (with its caret/selection restored). */
export const registerEditorFocus = (f: (() => void) | null) => {
  focusFn = f;
};
export const focusEditor = () => focusFn?.();

let lastChromePointer = 0;
/**
 * Called on every pointer-down inside the sidebar OR the text box frame ("editor chrome"). The editor ignores a blur that
 * follows within `ms`, so using chrome never commits or closes the edit.
 */
export const markSidebarPointer = () => {
  lastChromePointer = performance.now();
};
export const markChromePointer = markSidebarPointer;
export const sidebarRecentlyUsed = (ms = 600): boolean => performance.now() - lastChromePointer < ms;
