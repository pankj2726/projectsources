import type { Box } from "../model/coords";
import type { SourceDoc } from "../model/commands";
import { extractRawItems, extractRules, getSourceDoc } from "../pdf/render";
import { extractTextFillColors } from "../pdf/textColors";
import { buildGlyphMap, type GlyphMap, type RawItem } from "./glyphMap";

/** A glyph map that also remembers the raw items it was built from (font label, detected colour, …) for the text sidebar. */
export interface PageMap extends GlyphMap {
  items: RawItem[];
}

/** Per-source-page glyph map cache, shared by click-to-edit and Find & Replace. Sources are immutable, so entries never go stale. */
const cache = new Map<string, Promise<PageMap>>();

export function getGlyphMap(src: SourceDoc, srcIndex: number, cropBox: Box): Promise<PageMap> {
  const key = `${src.id}:${srcIndex}:${cropBox.join(",")}`;
  let p = cache.get(key);
  if (!p) {
    p = getSourceDoc(src).then(async (pdf) => {
      const geo = { cropBox, rotation: 0 };
      // The operator list must load FIRST: pdf.js only resolves real font names (page.commonObjs) once the page's fonts are loaded,
      // and the sidebar shows the original font name. The second call is served from pdf.js's own cache.
      const rules = await extractRules(pdf, srcIndex, geo);
      const [items, colors] = await Promise.all([extractRawItems(pdf, srcIndex, geo), extractTextFillColors(pdf, srcIndex)]);
      // exactly one text colour on the page → exact for every unit; otherwise the sidebar samples pixels and says "estimated"
      if (colors.reliable && colors.distinct.length === 1) for (const it of items) it.color = colors.distinct[0];
      const map = buildGlyphMap(items, { rules }); // rules = table cell borders → hard boundaries
      return Object.assign(map, { items });
    });
    cache.set(key, p);
    p.catch(() => cache.delete(key));
  }
  return p;
}

export function pruneTextCache(keepSourceIds: string[]) {
  for (const k of cache.keys()) if (!keepSourceIds.some((id) => k.startsWith(`${id}:`))) cache.delete(k);
}
