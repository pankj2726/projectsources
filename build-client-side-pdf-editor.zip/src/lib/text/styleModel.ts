/**
 * Text style model (TASKS-02 §2.4A). Pure and DOM-free: shared by the sidebar, the inline editor, the SVG preview and the
 * PDF export, so what you see is what is written.
 *
 * An edit unit has ONE base style plus optional per-range overrides ("spans", in code points). Range-aware formatting
 * edits spans; a caret-only change edits the base (and clears that property from every span so the whole unit follows).
 */
import { wrapText, type FontFamily, type PdfObject, type RunStyle, type Span, type SpanStyle } from "../model/objects";

export const SCRIPT_SCALE = 0.65;
export const SUP_RISE = 0.33;
export const SUB_DROP = 0.12;
export const RUN_KEYS = ["family", "size", "bold", "italic", "underline", "strike", "script", "color"] as const;
export type RunKey = (typeof RUN_KEYS)[number];

export const cps = (s: string): string[] => Array.from(s);
export const u16ToCp = (text: string, i: number): number => Array.from(text.slice(0, Math.max(0, i))).length;
export const cpToU16 = (text: string, n: number): number => Array.from(text).slice(0, Math.max(0, n)).join("").length;

export function baseStyleOf(o: Pick<PdfObject, "family" | "fontSize" | "bold" | "italic" | "underline" | "strike" | "script" | "color">): RunStyle {
  return { family: o.family ?? "sans", size: o.fontSize ?? 12, bold: !!o.bold, italic: !!o.italic, underline: !!o.underline, strike: !!o.strike, script: o.script ?? "none", color: o.color ?? "#000000" };
}

export const sameStyle = (a: RunStyle, b: RunStyle): boolean => RUN_KEYS.every((k) => a[k] === b[k]);
const sameSpanStyle = (a: SpanStyle, b: SpanStyle): boolean => {
  const ka = Object.keys(a) as RunKey[];
  return ka.length === Object.keys(b).length && ka.every((k) => a[k] === b[k]);
};

function merge(base: RunStyle, s: SpanStyle): RunStyle {
  const out = { ...base } as Record<string, unknown>;
  for (const k of RUN_KEYS) if (s[k] !== undefined) out[k] = s[k];
  return out as unknown as RunStyle;
}

/** Style of every character. */
export function perChar(len: number, base: RunStyle, spans: Span[]): RunStyle[] {
  const out: RunStyle[] = Array.from({ length: len }, () => ({ ...base }));
  for (const sp of spans) for (let i = Math.max(0, sp.a); i < Math.min(len, sp.b); i++) out[i] = merge(out[i], sp.s);
  return out;
}

/** Collapse per-character styles back into spans (only differences from `base` are stored). */
export function spansFrom(chars: RunStyle[], base: RunStyle): Span[] {
  const out: Span[] = [];
  let cur: Span | null = null;
  chars.forEach((c, i) => {
    const diff: Record<string, unknown> = {};
    for (const k of RUN_KEYS) if (c[k] !== base[k]) diff[k] = c[k];
    if (!Object.keys(diff).length) {
      cur = null;
      return;
    }
    if (cur && sameSpanStyle(cur.s, diff as SpanStyle)) cur.b = i + 1;
    else {
      cur = { a: i, b: i + 1, s: diff as SpanStyle };
      out.push(cur);
    }
  });
  return out;
}

const defined = (p: SpanStyle): SpanStyle => Object.fromEntries(Object.entries(p).filter(([, v]) => v !== undefined)) as SpanStyle;

/** Range-aware change: only [a, b) is restyled. */
export function applyToRange(len: number, base: RunStyle, spans: Span[], a: number, b: number, patch: SpanStyle): Span[] {
  const chars = perChar(len, base, spans);
  const p = defined(patch);
  for (let i = Math.max(0, a); i < Math.min(len, b); i++) chars[i] = merge(chars[i], p);
  return spansFrom(chars, base);
}

/** Caret-only change: the whole unit follows, so the changed properties are removed from every span. */
export function setBase(base: RunStyle, spans: Span[], patch: SpanStyle): { base: RunStyle; spans: Span[] } {
  const p = defined(patch);
  const keys = Object.keys(p) as RunKey[];
  const next = merge(base, p);
  const cleaned = spans
    .map((sp) => ({ ...sp, s: Object.fromEntries(Object.entries(sp.s).filter(([k]) => !keys.includes(k as RunKey))) as SpanStyle }))
    .filter((sp) => Object.keys(sp.s).length > 0);
  return { base: next, spans: cleaned };
}

/** Value of one property over [a, b) (whole text when a === b). `mixed` is true when the range holds more than one value. */
export function rangeValue<K extends RunKey>(len: number, base: RunStyle, spans: Span[], a: number, b: number, key: K): { value: RunStyle[K]; mixed: boolean } {
  const from = a === b ? 0 : a;
  const to = a === b ? len : b;
  if (len === 0 || from >= to) return { value: base[key], mixed: false };
  const chars = perChar(len, base, spans);
  const first = chars[from][key];
  for (let i = from + 1; i < to; i++) if (chars[i][key] !== first) return { value: first, mixed: true };
  return { value: first, mixed: false };
}

export interface Run {
  text: string;
  style: RunStyle;
}
export function splitRuns(text: string, base: RunStyle, spans: Span[]): Run[] {
  if (!spans.length) return [{ text, style: base }];
  const cp = cps(text);
  const chars = perChar(cp.length, base, spans);
  const runs: Run[] = [];
  cp.forEach((ch, i) => {
    const last = runs[runs.length - 1];
    if (last && sameStyle(last.style, chars[i])) last.text += ch;
    else runs.push({ text: ch, style: chars[i] });
  });
  return runs.length ? runs : [{ text: "", style: base }];
}

/** Keep spans attached to the right characters when the text is edited (prefix/suffix diff). Typing inside a span extends it. */
export function reconcileSpans(oldText: string, newText: string, spans: Span[]): Span[] {
  if (!spans.length || oldText === newText) return spans;
  const o = cps(oldText);
  const n = cps(newText);
  const max = Math.min(o.length, n.length);
  let p = 0;
  while (p < max && o[p] === n[p]) p++;
  let s = 0;
  while (s < max - p && o[o.length - 1 - s] === n[n.length - 1 - s]) s++;
  const removedEnd = o.length - s;
  const added = n.length - s - p;
  const delta = added - (removedEnd - p);
  const start = (x: number) => (x < p ? x : x >= removedEnd ? x + delta : p + added);
  const end = (x: number) => (x <= p ? x : x >= removedEnd ? x + delta : p);
  const out: Span[] = [];
  for (const sp of spans) {
    const a = Math.max(0, start(sp.a));
    const b = Math.min(n.length, end(sp.b));
    if (a < b) out.push({ a, b, s: sp.s });
  }
  return out;
}

export type CaseMode = "upper" | "lower" | "title";
export function transformCase(t: string, mode: CaseMode): string {
  if (mode === "upper") return t.toLocaleUpperCase();
  if (mode === "lower") return t.toLocaleLowerCase();
  return t.toLocaleLowerCase().replace(/(^|[^\p{L}\p{N}'’])(\p{L})/gu, (_m, pre: string, c: string) => pre + c.toLocaleUpperCase());
}

// ---------------- colours ----------------
export function normalizeHex(input: string): string | null {
  const t = input.trim().toLowerCase();
  let m = /^#?([0-9a-f]{6})$/.exec(t);
  if (m) return `#${m[1]}`;
  m = /^#?([0-9a-f])([0-9a-f])([0-9a-f])$/.exec(t);
  if (m) return `#${m[1]}${m[1]}${m[2]}${m[2]}${m[3]}${m[3]}`;
  m = /^(?:rgb\()?\s*(\d{1,3})\s*[, ]\s*(\d{1,3})\s*[, ]\s*(\d{1,3})\s*\)?$/.exec(t);
  if (m) {
    const [r, g, b] = [m[1], m[2], m[3]].map((x) => Math.min(255, parseInt(x, 10)));
    return rgbToHex(r, g, b);
  }
  return null;
}
export const rgbToHex = (r: number, g: number, b: number): string => "#" + [r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, "0")).join("");
export const hexToRgb = (hex: string): [number, number, number] => {
  const h = normalizeHex(hex) ?? "#000000";
  return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
};
/** Naive DeviceGray / DeviceCMYK → RGB for DISPLAY (no ICC profile). */
export const grayToRgb = (g: number): string => rgbToHex(g * 255, g * 255, g * 255);
export const cmykToRgb = (c: number, m: number, y: number, k: number): string => rgbToHex(255 * (1 - c) * (1 - k), 255 * (1 - m) * (1 - k), 255 * (1 - y) * (1 - k));

// ---------------- fonts ----------------
export const stripSubsetPrefix = (n: string): string => n.replace(/^[A-Z]{6}\+/, "");
/** The built-in fonts are Helvetica / Times / Courier; Arial, Times New Roman, Courier New and Liberation are metric-compatible. */
export const isStandardFontName = (n: string): boolean => /^(helvetica|arial|times|courier|symbol|zapfdingbats|liberation|nimbus)/i.test(stripSubsetPrefix(n).replace(/[\s_]/g, ""));
export const FAMILY_LABEL: Record<FontFamily, string> = { sans: "Sans (Helvetica)", serif: "Serif (Times)", mono: "Mono (Courier)" };
export const familyFromLabel = (label: string): FontFamily | null => (Object.entries(FAMILY_LABEL).find(([, l]) => l.toLowerCase() === label.trim().toLowerCase())?.[0] as FontFamily | undefined) ?? null;

// ---------------- layout shared by SVG preview and PDF export ----------------
export const effSize = (st: RunStyle): number => (st.script === "none" ? st.size : st.size * SCRIPT_SCALE);
export const riseOf = (st: RunStyle): number => (st.script === "sup" ? SUP_RISE * st.size : st.script === "sub" ? -SUB_DROP * st.size : 0);
const spaces = (s: string): number => (s.match(/ /g) ?? []).length;

export type RunMeasure = (text: string, f: { family: FontFamily; bold: boolean; italic: boolean; size: number }) => number;
export interface PlacedRun {
  text: string;
  style: RunStyle;
  size: number;
  /** x from the object's left edge (pt) */
  x: number;
  /** raised above the baseline (pt, negative = lowered) */
  rise: number;
  width: number;
  charSpacing: number;
  wordSpacing: number;
}
export interface PlacedLine {
  runs: PlacedRun[];
  /** baseline distance from the object's top (pt) */
  baseline: number;
  width: number;
}
export interface RunLayout {
  lines: PlacedLine[];
  lineHeight: number;
}

/** Lay out a text / textedit object into positioned runs. `sanitize` lets export strip glyphs the font cannot encode before measuring. */
export function layoutRuns(o: PdfObject, measure: RunMeasure, sanitize: (s: string) => string = (s) => s): RunLayout {
  const base = baseStyleOf(o);
  const cs = o.charSpacing ?? 0;
  const ws = o.wordSpacing ?? 0;
  const text = o.text ?? "";
  const runW = (r: Run): number => {
    const t = sanitize(r.text);
    return measure(t, { family: r.style.family, bold: r.style.bold, italic: r.style.italic, size: effSize(r.style) }) + cs * cps(t).length + ws * spaces(t);
  };
  const lh = o.lineHeight ?? base.size * 1.2;
  const first = o.type === "textedit" ? (o.baseline ?? base.size * 0.9) : 2 + base.size * 0.88;
  const wrapped = o.type === "text" ? wrapText(text, Math.max(10, o.w - 4), (s) => runW({ text: s, style: base })) : text.split(/\r?\n/);
  const useSpans = !!o.spans?.length && wrapped.length === 1;
  const align = o.align ?? "left";
  const padL = o.type === "text" ? 2 : 0;
  const aligned = o.type === "text" || wrapped.length > 1 || !!o.unitKey?.startsWith("p");
  const lines: PlacedLine[] = wrapped.map((ln, k) => {
    const src: Run[] = useSpans ? splitRuns(ln, base, o.spans!) : [{ text: ln, style: base }];
    const natural = src.reduce((a, r) => a + runW(r), 0);
    let startX = padL;
    let extra = 0;
    if (aligned) {
      if (align === "center") startX = (o.w - natural) / 2;
      else if (align === "right") startX = o.w - natural - (o.type === "text" ? 2 : 0);
      else if (align === "justify" && k < wrapped.length - 1) {
        const sp = spaces(sanitize(ln));
        if (sp > 0 && o.w - padL > natural) extra = (o.w - padL - natural) / sp;
      }
    }
    let x = startX;
    const runs = src.map((r) => {
      const width = runW(r) + extra * spaces(sanitize(r.text));
      const pr: PlacedRun = { text: r.text, style: r.style, size: effSize(r.style), x, rise: riseOf(r.style), width, charSpacing: cs, wordSpacing: ws + extra };
      x += width;
      return pr;
    });
    return { runs, baseline: first + k * lh, width: x - startX };
  });
  return { lines, lineHeight: lh };
}
