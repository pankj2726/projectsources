/**
 * Find & Replace controller (TASKS-02 Task 3). Replacement uses the SAME minimal-diff commit as click-to-edit
 * (`planUnitEdit`): matches are grouped by their own line segment, only the matched characters change, unchanged words
 * stay exactly where they are, and the line stays one continuous text unit. Replace All is ONE undoable command.
 */
import { create } from "zustand";
import { replaceObjects, type DocData } from "../model/commands";
import { useEditor } from "../model/docState";
import type { PdfObject } from "../model/objects";
import { getSourceDoc, sampleColorsForRects } from "../pdf/render";
import { CancelledError } from "../workers/client";
import { measure as canvasMeasure } from "../../components/viewer/textLayout";
import { inkCenter, type Glyph, type GlyphMap, type Rect } from "./glyphMap";
import { applyCase, compileQuery, DEFAULT_FIND, type FindOptions } from "./matcher";
import { matchTexts } from "./matchTexts";
import { getGlyphMap, pruneTextCache } from "./pageText";
import { buildSearchIndex, spanGlyphIds } from "./searchIndex";
import { effectiveUnitText, planUnitEdit, type Measure, type StyleInput } from "./unitEdit";
import { baseStyleOf } from "./styleModel";

/** Replace keeps the formatting the user already gave a line (font, size, colour, underline, spacing, opacity). Lines with per-range formatting fall back to the page's own style (KL-FR-4). */
function styleOfExisting(e: PdfObject | null): StyleInput | undefined {
  if (!e || e.spans?.length) return undefined;
  return { base: baseStyleOf(e), spans: [], baseChanged: !!e.restyled, extras: { bg: e.bg, opacity: e.opacity, charSpacing: e.charSpacing, wordSpacing: e.wordSpacing, dx: e.dx, dy: e.dy, rotation: e.rotation, locked: e.locked } };
}

export type Scope = "page" | "selected" | "all";
export type Overflow = "shrink" | "overflow" | "skip";

export interface Match {
  pageId: string;
  pageIndex: number;
  glyphIds: number[];
  text: string;
  /** one highlight rectangle per line (page space) */
  rects: Rect[];
}
export interface SkippedItem {
  page: number;
  text: string;
  reason: string;
}

interface FindState {
  open: boolean;
  mode: "find" | "replace";
  query: string;
  replacement: string;
  opts: FindOptions;
  scope: Scope;
  overflow: Overflow;
  matches: Match[];
  current: number;
  busy: boolean;
  progress: number;
  label: string;
  error: string | null;
  summary: string | null;
  skipped: SkippedItem[];
  noTextPages: number;
  set(p: Partial<FindState>): void;
}

export const useFind = create<FindState>((set) => ({
  open: false,
  mode: "find",
  query: "",
  replacement: "",
  opts: DEFAULT_FIND,
  scope: "all",
  overflow: "shrink",
  matches: [],
  current: -1,
  busy: false,
  progress: 0,
  label: "",
  error: null,
  summary: null,
  skipped: [],
  noTextPages: 0,
  set: (p) => set(p),
}));

let token = 0;
let cancelRequested = false;
export const cancelFind = () => {
  cancelRequested = true;
};

const measure: Measure = (t, size, st) => canvasMeasure({ family: st.family, bold: st.bold, italic: st.italic, fontSize: size }, t);

function deadFor(objs: PdfObject[]): (g: Glyph) => boolean {
  const rects = objs.filter((o) => o.type === "textedit").flatMap((o) => o.covers ?? [{ x: o.x - 1, y: o.y - 1, w: o.w + 2, h: o.h + 2 }]);
  if (!rects.length) return () => false;
  return (g) => {
    const c = inkCenter(g);
    return rects.some((r) => c.x >= r.x && c.x <= r.x + r.w && c.y >= r.y && c.y <= r.y + r.h);
  };
}

function scopePages(doc: DocData, scope: Scope, current: number, selectedIds: string[]) {
  const all = doc.pages.map((page, index) => ({ page, index }));
  if (scope === "all") return all;
  if (scope === "selected" && selectedIds.length) return all.filter((x) => selectedIds.includes(x.page.id));
  return all.filter((x) => x.index === Math.min(current, all.length - 1));
}

function lineRects(map: GlyphMap, ids: number[]): Rect[] {
  const by = new Map<number, Glyph[]>();
  for (const id of ids) {
    const g = map.glyphs[id];
    if (g.space) continue;
    by.set(g.lineId, [...(by.get(g.lineId) ?? []), g]);
  }
  return [...by.values()].map((gs) => {
    const x0 = Math.min(...gs.map((g) => g.ink.x));
    const y0 = Math.min(...gs.map((g) => g.ink.y));
    return { x: x0, y: y0, w: Math.max(...gs.map((g) => g.ink.x + g.ink.w)) - x0, h: Math.max(...gs.map((g) => g.ink.y + g.ink.h)) - y0 };
  });
}

/** Search the chosen scope. Progress + cancel; returns the match list (also stored for highlighting). */
export async function runSearch(o: { keepCurrent?: boolean; keepSummary?: boolean } = {}): Promise<Match[]> {
  const f = useFind.getState();
  const st = useEditor.getState();
  const doc = st.doc;
  const clear = (error: string | null) => useFind.setState({ matches: [], current: -1, error, busy: false, noTextPages: 0, ...(o.keepSummary ? {} : { summary: null, skipped: [] }) });
  if (!doc) return [];
  if (!f.query.trim()) {
    clear(null);
    return [];
  }
  const c = compileQuery(f.query, f.opts);
  if (!c.ok) {
    clear(c.error || null);
    return [];
  }
  const id = ++token;
  cancelRequested = false;
  pruneTextCache(Object.keys(doc.sources));
  useFind.setState({ busy: true, progress: 0, label: "Reading text", error: null, ...(o.keepSummary ? {} : { summary: null, skipped: [] }) });
  try {
    const pages = scopePages(doc, f.scope, st.currentPage, st.selectedPages);
    const per: { index: number; pageId: string; map: GlyphMap; idx: ReturnType<typeof buildSearchIndex>; dead: (g: Glyph) => boolean }[] = [];
    let noText = 0;
    for (let k = 0; k < pages.length; k++) {
      if (cancelRequested || id !== token) throw new CancelledError();
      const { page, index } = pages[k];
      if (!page.sourceId) {
        noText++;
        continue;
      }
      const map = await getGlyphMap(doc.sources[page.sourceId], page.srcIndex, page.cropBox);
      if (!map.glyphs.length) {
        noText++;
        continue;
      }
      const dead = deadFor(doc.objects.filter((x) => x.pageId === page.id));
      per.push({ index, pageId: page.id, map, idx: buildSearchIndex(map, dead), dead });
      if (k % 4 === 0) useFind.setState({ progress: ((k + 1) / pages.length) * 0.85, label: `Reading page ${k + 1} of ${pages.length}` });
    }
    useFind.setState({ progress: 0.9, label: "Matching" });
    const spans = await matchTexts(per.map((p) => p.idx.text), f.query, f.opts);
    if (cancelRequested || id !== token) throw new CancelledError();
    const matches: Match[] = [];
    per.forEach((p, i) => {
      for (const sp of spans[i]) {
        const ids = spanGlyphIds(p.idx, p.map, sp, p.dead);
        if (ids.length) matches.push({ pageId: p.pageId, pageIndex: p.index, glyphIds: ids, text: p.idx.text.slice(sp.start, sp.end), rects: lineRects(p.map, ids) });
      }
    });
    const cur = useFind.getState().current;
    useFind.setState({ matches, current: matches.length ? (o.keepCurrent && cur >= 0 ? Math.min(cur, matches.length - 1) : 0) : -1, noTextPages: noText, busy: false, progress: 1 });
    return matches;
  } catch (e) {
    if (id !== token && !(e instanceof CancelledError)) return [];
    useFind.setState({ busy: false, matches: [], current: -1, error: e instanceof CancelledError ? null : e instanceof Error ? e.message : "Search failed", summary: e instanceof CancelledError ? "Search cancelled." : null });
    return [];
  }
}

export function goTo(i: number) {
  const { matches } = useFind.getState();
  if (!matches.length) return;
  const k = ((i % matches.length) + matches.length) % matches.length; // wrap-around
  useFind.setState({ current: k });
  if (matches[k].pageIndex !== useEditor.getState().currentPage) window.dispatchEvent(new CustomEvent("qf-jump", { detail: matches[k].pageIndex }));
}
export const next = () => goTo(useFind.getState().current + 1);
export const prev = () => goTo(useFind.getState().current - 1);

// ---------------------------------------------------------------- replace
interface Plan {
  remove: string[];
  add: PdfObject[];
  replaced: number;
  skipped: SkippedItem[];
  unchanged: number;
  shrunk: number;
  overflowed: number;
}
interface Sub {
  from: number;
  to: number;
  text: string;
  match: Match;
}

async function planReplace(doc: DocData, matches: Match[], replacement: string, onPage: (k: number, n: number) => void): Promise<Plan> {
  const f = useFind.getState();
  const plan: Plan = { remove: [], add: [], replaced: 0, skipped: [], unchanged: 0, shrunk: 0, overflowed: 0 };
  const byPage = new Map<string, Match[]>();
  for (const m of matches) byPage.set(m.pageId, [...(byPage.get(m.pageId) ?? []), m]);
  let k = 0;
  for (const [pageId, group] of byPage) {
    if (cancelRequested) throw new CancelledError();
    onPage(k++, byPage.size);
    const page = doc.pages.find((p) => p.id === pageId);
    if (!page?.sourceId) continue;
    const src = doc.sources[page.sourceId];
    const map = await getGlyphMap(src, page.srcIndex, page.cropBox);
    const pageW = Math.abs(page.cropBox[2] - page.cropBox[0]);
    const edits = doc.objects.filter((o) => o.pageId === pageId && o.type === "textedit");

    // 1. group the matches by their own line segment
    const perUnit = new Map<number, Sub[]>();
    for (const m of group) {
      const units = new Set(m.glyphIds.map((id) => map.glyphs[id].lineId));
      if (units.size !== 1) {
        plan.skipped.push({ page: m.pageIndex + 1, text: m.text, reason: "The match spans several lines or columns; edit it by hand." });
        continue;
      }
      const uid = [...units][0];
      const unit = map.units[uid];
      const idxs = m.glyphIds.map((id) => unit.charGlyph.indexOf(id)).filter((i) => i >= 0);
      if (!idxs.length) continue;
      const text = f.opts.caseAware ? applyCase(m.text, replacement) : replacement;
      perUnit.set(uid, [...(perUnit.get(uid) ?? []), { from: Math.min(...idxs), to: Math.max(...idxs) + 1, text, match: m }]);
    }
    if (!perUnit.size) continue;

    // 2. background / ink colours around every unit that gets a NEW edit (one render per page)
    const fresh = [...perUnit.keys()].filter((uid) => !edits.some((o) => o.unitKey === `u${uid}`));
    let colors = new Map<number, { bg: string; fg: string }>();
    if (fresh.length) {
      try {
        const rects = fresh.map((uid) => {
          const u = map.units[uid];
          return { x: u.x0 - 1, y: u.baseline - 0.8 * u.size, w: u.x1 - u.x0 + 2, h: u.size };
        });
        const cs = await sampleColorsForRects(await getSourceDoc(src), page.srcIndex, rects);
        colors = new Map(fresh.map((uid, i) => [uid, cs[i]]));
      } catch {
        /* keep white / black defaults */
      }
    }

    // 3. one minimal-diff edit per unit; all matches of the unit are applied to its (effective) text together
    for (const [uid, subs] of perUnit) {
      const unit = map.units[uid];
      const para = map.paragraphs[unit.paraId];
      const fail = (reason: string) => {
        for (const s of subs) plan.skipped.push({ page: s.match.pageIndex + 1, text: s.match.text, reason });
      };
      if (para && edits.some((o) => o.unitKey === `p${para.id}`)) {
        fail("This line belongs to a paragraph that was edited as a whole.");
        continue;
      }
      const existing = edits.find((o) => o.unitKey === `u${uid}`) ?? null;
      const eff = effectiveUnitText(unit, existing);
      const cp = Array.from(eff);
      // matches only cover glyphs that are not hidden by an earlier edit, so their indices are valid in the effective text
      for (const s of [...subs].sort((a, b) => b.from - a.from)) cp.splice(s.from, s.to - s.from, ...Array.from(s.text));
      const res = planUnitEdit(map, unit, cp.join(""), { pageId, pageW, existing, colors: colors.get(uid), overflow: f.overflow, measure, origText: eff, style: styleOfExisting(existing) });
      if (!res.ok) {
        fail(res.error);
        continue;
      }
      if (existing) plan.remove.push(existing.id);
      if (res.obj) plan.add.push(res.obj);
      else plan.unchanged += subs.length;
      plan.replaced += subs.length;
      for (const n of res.notes) {
        if (/^Shrunk/.test(n)) plan.shrunk++;
        else plan.overflowed++;
      }
    }
  }
  return plan;
}

async function applyReplace(matches: Match[], all: boolean) {
  const st = useEditor.getState();
  const doc = st.doc;
  const f = useFind.getState();
  if (!doc || !matches.length) return;
  cancelRequested = false;
  useFind.setState({ busy: true, progress: 0, label: "Replacing", summary: null, skipped: [] });
  let summary: string;
  let skipped: SkippedItem[] = [];
  try {
    const plan = await planReplace(doc, matches, f.replacement, (k, n) => useFind.setState({ progress: (k + 1) / n, label: `Replacing on page ${k + 1} of ${n}` }));
    if (cancelRequested) throw new CancelledError();
    if (plan.add.length || plan.remove.length) st.exec(replaceObjects(plan.remove, plan.add, all ? "Replace all" : "Replace")); // ONE undo step
    skipped = plan.skipped;
    const extras = [plan.unchanged ? `${plan.unchanged} already identical` : "", plan.shrunk ? `${plan.shrunk} shrunk to fit` : "", plan.overflowed ? `${plan.overflowed} overflow their space` : ""].filter(Boolean);
    summary = `Replaced ${plan.replaced}, skipped ${plan.skipped.length} (no space or blocked), 0 errors.${extras.length ? ` ${extras.join(", ")}.` : ""} One undo reverts all.`;
  } catch (e) {
    summary = e instanceof CancelledError ? "Cancelled – nothing was changed." : `Replace failed, nothing was changed: ${e instanceof Error ? e.message : "unknown error"}`;
  }
  useFind.setState({ busy: false, summary, skipped });
  await runSearch({ keepCurrent: true, keepSummary: true });
}

export async function replaceCurrent() {
  const { matches, current } = useFind.getState();
  if (current < 0 || !matches[current]) return;
  await applyReplace([matches[current]], false);
}

export async function replaceAll() {
  const ms = await runSearch({ keepSummary: true }); // always plan from a fresh match list
  await applyReplace(ms, true);
}
