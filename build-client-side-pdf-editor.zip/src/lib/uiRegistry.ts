/**
 * UI feature checklist (TASKS-02 §2.4B regression guard). Every entry is something a user can see and click; the vitest
 * suite checks the registry against the code, and tests/e2e/ui-checklist.spec.ts checks it against the running app.
 * ANY change that removes one of these fails the build – "changing an interaction must not silently remove existing UI".
 */
export interface UiItem {
  /** feature id from docs/TRACEABILITY.md */
  feature: string;
  /** how to find it in the running editor */
  where: "toolbar-tool" | "header-button" | "tools-menu" | "page-toolbar" | "tab" | "sidebar";
  /** accessible name (string = exact label, as rendered) */
  name: string;
  /** toolbar tool id, when where === "toolbar-tool" */
  toolId?: string;
}

export const UI_CHECKLIST: UiItem[] = [
  { feature: "F06", where: "toolbar-tool", name: "Text (T)", toolId: "text" },
  { feature: "F07", where: "toolbar-tool", name: "Highlight (M)", toolId: "highlight" },
  { feature: "F07", where: "toolbar-tool", name: "Underline (U)", toolId: "underline" },
  { feature: "F07", where: "toolbar-tool", name: "Strike (S)", toolId: "strike" },
  { feature: "F08", where: "toolbar-tool", name: "Draw (D)", toolId: "draw" },
  { feature: "F09", where: "toolbar-tool", name: "Rectangle (R)", toolId: "rect" },
  { feature: "F09", where: "toolbar-tool", name: "Ellipse (O)", toolId: "ellipse" },
  { feature: "F09", where: "toolbar-tool", name: "Line (L)", toolId: "line" },
  { feature: "F09", where: "toolbar-tool", name: "Arrow (A)", toolId: "arrow" },
  { feature: "F10", where: "toolbar-tool", name: "Image (I)", toolId: "image" },
  { feature: "F11", where: "toolbar-tool", name: "Note (N)", toolId: "note" },
  { feature: "F12", where: "toolbar-tool", name: "Select (V)", toolId: "select" },
  { feature: "F12", where: "toolbar-tool", name: "Eraser (X)", toolId: "eraser" },
  { feature: "F13", where: "toolbar-tool", name: "Edit text (E)", toolId: "edittext" },
  { feature: "F14", where: "toolbar-tool", name: "Whiteout (W)", toolId: "whiteout" },
  { feature: "F15", where: "toolbar-tool", name: "Redact (K)", toolId: "redact" },
  { feature: "F24", where: "toolbar-tool", name: "Field (F)", toolId: "field" },
  { feature: "F26", where: "toolbar-tool", name: "Sign (G)", toolId: "signature" },
  { feature: "F04", where: "header-button", name: "Undo" },
  { feature: "F04", where: "header-button", name: "Redo" },
  { feature: "F05", where: "header-button", name: "⇩ Download" },
  { feature: "F41", where: "header-button", name: "Find and replace (Ctrl+F)" },
  { feature: "F33", where: "tools-menu", name: "Edit metadata" },
  { feature: "F18", where: "tools-menu", name: "Merge PDF" },
  { feature: "F19", where: "tools-menu", name: "Split PDF" },
  { feature: "F20", where: "tools-menu", name: "Crop PDF" },
  { feature: "F21", where: "tools-menu", name: "Page numbers & Bates" },
  { feature: "F22", where: "tools-menu", name: "Add watermark" },
  { feature: "F30", where: "tools-menu", name: "Compress PDF" },
  { feature: "F31", where: "tools-menu", name: "Protect PDF" },
  { feature: "F34", where: "tools-menu", name: "OCR PDF" },
  { feature: "F16", where: "page-toolbar", name: "Rotate selected pages right" },
  { feature: "F16", where: "page-toolbar", name: "Delete selected pages" },
  { feature: "F16", where: "page-toolbar", name: "Duplicate selected pages" },
  { feature: "F17", where: "page-toolbar", name: "Insert blank page" },
  { feature: "F23", where: "tab", name: "Forms" },
  { feature: "F12", where: "tab", name: "Properties" },
];

/** Parts of the ACTIVE text box (F45) that must exist while an edit is open: 8 resize handles, rotate, move grip, border. */
export const TEXT_FRAME_CONTROLS = [
  "Resize top-left corner",
  "Resize top edge",
  "Resize top-right corner",
  "Resize right edge",
  "Resize bottom-right corner",
  "Resize bottom edge",
  "Resize bottom-left corner",
  "Resize left edge",
  "Rotate text box",
  "Move text box",
] as const;

/** Controls the text sidebar must always offer (F44). The e2e suite looks each up by accessible label. */
export const TEXT_SIDEBAR_CONTROLS = [
  "Edit text content",
  "Reset text to the original",
  "Box width",
  "Font family",
  "Font size",
  "Bold",
  "Italic",
  "Underline",
  "Strikethrough",
  "Superscript",
  "Subscript",
  "Text colour",
  "Text colour hex",
  "Background fill",
  "Opacity",
  "Align left",
  "Align center",
  "Align right",
  "Justify",
  "Line spacing",
  "Character spacing",
  "Word spacing",
  "UPPERCASE",
  "lowercase",
  "Title Case",
  "Offset X",
  "Offset Y",
  "Rotation",
  "Bring to front",
  "Send to back",
  "Lock position",
  "Duplicate text",
  "Delete text edit",
  "Undo format change",
  "Redo format change",
  "Reset formatting",
] as const;
