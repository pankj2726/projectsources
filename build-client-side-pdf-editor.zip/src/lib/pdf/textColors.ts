/**
 * Fill colours that text is shown with, read from the page's operator list.
 *
 * pdf.js converts DeviceGray / DeviceCMYK / ICC fills to a "#rrggbb" string BEFORE it emits the operator
 * (verified in pdf.worker.mjs: every fill op becomes OPS.setFillRGBColor with a hex string), so the ORIGINAL colour space is
 * not recoverable here (docs/KNOWN_LIMITATIONS.md KL-COLORSPACE). What we can do is report the colour the viewer shows.
 *
 * Text items cannot be matched one-to-one with show-text operators (one operator may yield several items), so the result is
 * a SET: when the page shows all of its text in exactly one colour that colour is exact for every unit; otherwise the sidebar
 * falls back to a pixel sample and says "estimated".
 */
import * as pdfjs from "pdfjs-dist/legacy/build/pdf.mjs";
import type { PdfDoc } from "./render";

export interface PageTextColors {
  distinct: string[];
  /** every fill seen at a show-text operator came from a plain RGB/gray/CMYK operator (no pattern / separation / unknown colour space) */
  reliable: boolean;
}

export async function extractTextFillColors(doc: PdfDoc, srcIndex: number): Promise<PageTextColors> {
  const out = new Set<string>();
  let reliable = true;
  try {
    const page = await doc.getPage(srcIndex + 1);
    const { fnArray, argsArray } = await page.getOperatorList();
    const OPS = pdfjs.OPS as Record<string, number>;
    const show = new Set([OPS.showText, OPS.showSpacedText, OPS.nextLineShowText, OPS.nextLineSetSpacingShowText]);
    let fill: string | null = "#000000";
    const stack: (string | null)[] = [];
    for (let i = 0; i < fnArray.length; i++) {
      const fn = fnArray[i];
      const args = argsArray[i] as unknown;
      if (fn === OPS.save) stack.push(fill);
      else if (fn === OPS.restore) fill = stack.pop() ?? fill;
      else if (fn === OPS.setFillRGBColor) {
        if (typeof (args as unknown[])?.[0] === "string") fill = (args as string[])[0].toLowerCase();
        else if (Array.isArray(args) && args.length >= 3) fill = "#" + (args as number[]).slice(0, 3).map((v) => Math.round(v).toString(16).padStart(2, "0")).join("");
        else fill = null;
      } else if (fn === OPS.setFillColorSpace || fn === OPS.setFillColor || fn === OPS.setFillColorN || fn === OPS.setFillTransparent) fill = fill; // converted to RGB above when resolvable
      else if (show.has(fn)) {
        if (fill && /^#[0-9a-f]{6}$/.test(fill)) out.add(fill);
        else reliable = false;
      }
    }
  } catch {
    reliable = false;
  }
  return { distinct: [...out], reliable };
}
