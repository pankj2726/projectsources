/**
 * Styled text drawing for export (worker-safe: no DOM). Uses the SAME layout function as the on-screen preview
 * (`layoutRuns`), so positions, spacing, underline and sub/superscripts in the downloaded file match what the user saw.
 */
import { setCharacterSpacing, setWordSpacing, rgb, degrees, type PDFFont, type PDFPage } from "@cantoo/pdf-lib";
import { standardFontName } from "../fonts/fontMap";
import type { Pt } from "../model/coords";
import { hexToRgb01, type PdfObject } from "../model/objects";
import { baseStyleOf, layoutRuns, splitRuns, type RunMeasure } from "../text/styleModel";

export async function drawStyledText(
  page: PDFPage,
  o: PdfObject,
  getFont: (name: string) => Promise<PDFFont>,
  /** object-local offset (from the box's top-left, y down) → PDF-space point, honouring the object's rotation */
  place: (lx: number, ly: number) => Pt,
  sanitize: (s: string) => string
): Promise<void> {
  const base = baseStyleOf(o);
  // every font a run can use, resolved BEFORE the (synchronous) layout needs to measure
  const names = new Set<string>([standardFontName(base.family, base.bold, base.italic)]);
  if (o.spans?.length) for (const r of splitRuns(o.text ?? "", base, o.spans)) names.add(standardFontName(r.style.family, r.style.bold, r.style.italic));
  const fonts = new Map<string, PDFFont>();
  for (const n of names) fonts.set(n, await getFont(n));
  const fontOf = (f: { family: PdfObject["family"]; bold: boolean; italic: boolean }) => fonts.get(standardFontName(f.family, f.bold, f.italic)) ?? fonts.get(standardFontName(base.family, base.bold, base.italic))!;
  const measure: RunMeasure = (t, f) => fontOf(f).widthOfTextAtSize(t, f.size);

  const L = layoutRuns(o, measure, sanitize);
  const rot = degrees(-o.rotation);
  for (const ln of L.lines) {
    for (const r of ln.runs) {
      const s = sanitize(r.text);
      if (!s) continue;
      const [cr, cg, cb] = hexToRgb01(r.style.color);
      const color = rgb(cr, cg, cb);
      const p = place(r.x, ln.baseline - r.rise);
      // Tc / Tw are text-state operators: set before the text, reset after, so nothing else on the page is affected
      if (r.charSpacing) page.pushOperators(setCharacterSpacing(r.charSpacing));
      if (r.wordSpacing) page.pushOperators(setWordSpacing(r.wordSpacing));
      page.drawText(s, { x: p.x, y: p.y, size: r.size, font: fontOf(r.style), color, rotate: rot, opacity: o.opacity });
      if (r.charSpacing) page.pushOperators(setCharacterSpacing(0));
      if (r.wordSpacing) page.pushOperators(setWordSpacing(0));
      const thickness = Math.max(0.5, r.size / 16);
      if (r.style.underline) page.drawLine({ start: place(r.x, ln.baseline - r.rise + r.size * 0.12), end: place(r.x + r.width, ln.baseline - r.rise + r.size * 0.12), thickness, color, opacity: o.opacity });
      if (r.style.strike) page.drawLine({ start: place(r.x, ln.baseline - r.rise - r.size * 0.3), end: place(r.x + r.width, ln.baseline - r.rise - r.size * 0.3), thickness, color, opacity: o.opacity });
    }
  }
}
