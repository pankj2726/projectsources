import type { Pt } from "./coords";

export type ObjType =
  | "text"
  | "highlight"
  | "underline"
  | "strike"
  | "draw"
  | "rect"
  | "ellipse"
  | "line"
  | "arrow"
  | "image"
  | "note"
  | "whiteout"
  | "redact"
  | "textedit"
  | "field";

export type FontFamily = "sans" | "serif" | "mono";
export type FieldKind = "text" | "checkbox" | "radio" | "dropdown" | "date";
export type TextAlign = "left" | "center" | "right" | "justify";
export type Script = "none" | "sup" | "sub";

/** Everything that can differ between two runs of text inside one edit unit. */
export interface RunStyle {
  family: FontFamily;
  size: number;
  bold: boolean;
  italic: boolean;
  underline: boolean;
  strike: boolean;
  script: Script;
  color: string;
}
export type SpanStyle = Partial<RunStyle>;
/** Style override for the code-point range [a, b) of an object's text. */
export interface Span {
  a: number;
  b: number;
  s: SpanStyle;
}

/** One flat shape for every editor object; `type` decides which optional props are used. Geometry is PAGE SPACE (pt). */
export interface PdfObject {
  id: string;
  pageId: string;
  type: ObjType;
  x: number;
  y: number;
  w: number;
  h: number;
  /** clockwise degrees about the box centre */
  rotation: number;
  opacity: number;
  // appearance
  color: string; // stroke / text colour (#rrggbb)
  fill: string | null; // fill colour or null
  strokeWidth: number;
  // text-ish
  text?: string;
  fontSize?: number;
  family?: FontFamily;
  bold?: boolean;
  italic?: boolean;
  underline?: boolean;
  strike?: boolean;
  script?: Script;
  /** extra space after every character / every space (pt) */
  charSpacing?: number;
  wordSpacing?: number;
  align?: TextAlign;
  /** per-range style overrides (single-line edits only) */
  spans?: Span[];
  /** the object restyles text whose characters did not change (so it must still be drawn) */
  restyled?: boolean;
  /** position lock: the selection tool will not move / resize it */
  locked?: boolean;
  /** offset of an edited line from its original position (pt), kept so a re-edit starts from the same place */
  dx?: number;
  dy?: number;
  // freehand / line / arrow: points normalised 0..1 inside the box
  pts?: Pt[];
  // image / signature
  dataUrl?: string;
  // textedit
  origText?: string;
  /**
   * exact cover rectangles (page space) for the edited glyphs, one per line. An empty array means "cover nothing"
   * (pure insertion); `undefined` (objects created before covers existed) falls back to the object's box.
   */
  covers?: { x: number; y: number; w: number; h: number }[];
  /** edit unit this object replaces: "u<unitId>" (line segment) or "p<paraId>" (reflowed paragraph) */
  unitKey?: string;
  /** the unit's ORIGINAL text, and the code-point range [unitA, unitEnd) that `text` replaces */
  unitFull?: string;
  unitA?: number;
  unitEnd?: number;
  /** paragraph edits: the new paragraph as typed (before wrapping) */
  logical?: string;
  /** baseline-to-baseline distance for multi-line edits (pt); default 1.2 × font size */
  lineHeight?: number;
  bg?: string;
  baseline?: number; // baseline offset from box top (pt)
  // form field
  fieldKind?: FieldKind;
  fieldName?: string;
  options?: string[];
  // metadata
  label?: string;
}

let counter = 0;
export function uid(prefix = "o"): string {
  counter += 1;
  return `${prefix}${Date.now().toString(36)}${counter.toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}

export function baseObject(type: ObjType, pageId: string, x: number, y: number, w: number, h: number): PdfObject {
  return {
    id: uid("o"),
    pageId,
    type,
    x,
    y,
    w,
    h,
    rotation: 0,
    opacity: 1,
    color: "#111827",
    fill: null,
    strokeWidth: 2,
  };
}

/** Defaults for the NEXT new text box. Edited from the text sidebar when no text is being edited (F44). */
export interface TextDefaults {
  family: FontFamily;
  size: number;
  bold: boolean;
  italic: boolean;
  underline: boolean;
  strike: boolean;
  color: string;
  opacity: number;
  align: TextAlign;
}
export const textDefaults: TextDefaults = { family: "sans", size: 16, bold: false, italic: false, underline: false, strike: false, color: "#111827", opacity: 1, align: "left" };

/** Defaults for each tool when an object is first created. */
export function createObject(type: ObjType, pageId: string, x: number, y: number, w: number, h: number): PdfObject {
  const o = baseObject(type, pageId, x, y, w, h);
  switch (type) {
    case "text": {
      const d = textDefaults;
      return { ...o, text: "Text", fontSize: d.size, family: d.family, bold: d.bold, italic: d.italic, underline: d.underline, strike: d.strike, align: d.align, color: d.color, opacity: d.opacity };
    }
    case "highlight":
      return { ...o, color: "#facc15", fill: "#facc15", opacity: 0.4 };
    case "underline":
      return { ...o, color: "#dc2626", strokeWidth: 1.5 };
    case "strike":
      return { ...o, color: "#dc2626", strokeWidth: 1.5 };
    case "draw":
      return { ...o, color: "#2563eb", strokeWidth: 2.5, pts: [] };
    case "rect":
      return { ...o, color: "#dc2626", strokeWidth: 2 };
    case "ellipse":
      return { ...o, color: "#2563eb", strokeWidth: 2 };
    case "line":
      return { ...o, color: "#111827", strokeWidth: 2.5, pts: [{ x: 0, y: 0 }, { x: 1, y: 1 }] };
    case "arrow":
      return { ...o, color: "#111827", strokeWidth: 2.5, pts: [{ x: 0, y: 0 }, { x: 1, y: 1 }] };
    case "note":
      return { ...o, w: 24, h: 24, color: "#eab308", fill: "#fde047", text: "Note" };
    case "whiteout":
      return { ...o, color: "#ffffff", fill: "#ffffff", strokeWidth: 0 };
    case "redact":
      return { ...o, color: "#000000", fill: "#000000", strokeWidth: 0 };
    case "field":
      return { ...o, fieldKind: "text", fieldName: "field", options: [], strokeWidth: 1, color: "#2563eb" };
    default:
      return o;
  }
}

export function hexToRgb01(hex: string): [number, number, number] {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return [0, 0, 0];
  const n = parseInt(m[1], 16);
  return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
}

export function boxesIntersect(
  a: { x: number; y: number; w: number; h: number },
  b: { x: number; y: number; w: number; h: number }
): boolean {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}

/** Object kinds that can carry readable text / image data and therefore must not survive under a redaction. */
export const CONTENT_BEARING: ObjType[] = ["text", "textedit", "note", "image", "field"];

/** Word-wrap with an injected measure function so screen (canvas) and export (pdf-lib) share one algorithm. */
export function wrapText(text: string, maxWidth: number, measure: (s: string) => number): string[] {
  const out: string[] = [];
  for (const para of text.split(/\r?\n/)) {
    if (para === "") {
      out.push("");
      continue;
    }
    let line = "";
    for (const word of para.split(/(\s+)/)) {
      const test = line + word;
      if (line !== "" && measure(test.trimEnd()) > maxWidth) {
        out.push(line.trimEnd());
        line = word.trimStart();
      } else {
        line = test;
      }
    }
    out.push(line.trimEnd());
  }
  return out;
}
