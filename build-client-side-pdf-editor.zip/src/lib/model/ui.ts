import { create } from "zustand";
import type { PanelId } from "../tools";

const read = (k: string) => {
  try {
    return localStorage.getItem(k) === "1";
  } catch {
    return false;
  }
};
const write = (k: string, v: boolean) => {
  try {
    localStorage.setItem(k, v ? "1" : "0");
  } catch {
    /* storage disabled */
  }
};

interface UiState {
  rightTab: "props" | "forms";
  leftOpen: boolean;
  rightOpen: boolean;
  toolPanel: PanelId | null;
  exportOpen: boolean;
  signatureOpen: boolean;
  tourOpen: boolean;
  /** Edit-text setting: draw an outline under the pointer over editable text. OFF by default (spec §2.4). */
  hoverHighlight: boolean;
  /** Edit-text setting: click opens the whole PARAGRAPH (reflow) instead of the line. OFF by default. */
  paragraphMode: boolean;
  set(p: Partial<UiState>): void;
  setHoverHighlight(v: boolean): void;
  setParagraphMode(v: boolean): void;
}

export const useUi = create<UiState>((set) => ({
  rightTab: "props",
  leftOpen: typeof window !== "undefined" ? window.innerWidth >= 1024 : true,
  rightOpen: typeof window !== "undefined" ? window.innerWidth >= 1024 : true,
  toolPanel: null,
  exportOpen: false,
  signatureOpen: false,
  tourOpen: false,
  hoverHighlight: typeof window !== "undefined" ? read("qf-hover-hl") : false,
  paragraphMode: typeof window !== "undefined" ? read("qf-para-mode") : false,
  set: (p) => set(p),
  setHoverHighlight: (v) => {
    write("qf-hover-hl", v);
    set({ hoverHighlight: v });
  },
  setParagraphMode: (v) => {
    write("qf-para-mode", v);
    set({ paragraphMode: v });
  },
}));
