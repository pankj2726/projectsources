/** Android file in / out and share (TASKS-03 Task F, F52). */
import { toast } from "./toast";

export interface SaveResult {
  how: "picker" | "download" | "share" | "none";
  error?: string;
}

type SavePicker = (o: { suggestedName: string; types: { description: string; accept: Record<string, string[]> }[] }) => Promise<{ createWritable(): Promise<{ write(b: BlobPart): Promise<void>; close(): Promise<void> }> }>;
const picker = (): SavePicker | undefined => (window as unknown as { showSaveFilePicker?: SavePicker }).showSaveFilePicker;

export const canShareFiles = (bytes: Uint8Array, filename: string): boolean => {
  try {
    const f = new File([bytes as BlobPart], filename, { type: "application/pdf" });
    return typeof navigator.canShare === "function" && navigator.canShare({ files: [f] });
  } catch {
    return false;
  }
};

/**
 * Save a PDF the Android way:
 *  1. `showSaveFilePicker` when it exists (desktop Chromium only – NOT on Android),
 *  2. otherwise a Blob + anchor download (works in Chrome, Samsung Internet, Firefox),
 *  3. or the Share sheet via `navigator.share({files})` when the caller asks for it.
 * `hint` is shown afterwards because Android gives no reliable "where did it go" signal.
 */
export async function savePdf(bytes: Uint8Array, filename: string, prefer: "download" | "share" = "download", hint = "Saved to Downloads"): Promise<SaveResult> {
  if (prefer === "share" && canShareFiles(bytes, filename)) {
    try {
      const file = new File([bytes as BlobPart], filename, { type: "application/pdf" });
      await navigator.share({ files: [file], title: filename });
      return { how: "share" };
    } catch (e) {
      if ((e as Error)?.name === "AbortError") return { how: "none" };
      return { how: "none", error: (e as Error).message };
    }
  }
  const p = picker();
  if (p) {
    try {
      const h = await p({ suggestedName: filename, types: [{ description: "PDF document", accept: { "application/pdf": [".pdf"] } }] });
      const w = await h.createWritable();
      await w.write(bytes as BlobPart);
      await w.close();
      return { how: "picker" };
    } catch (e) {
      if ((e as Error)?.name === "AbortError") return { how: "none" };
      // fall through to the download path
    }
  }
  try {
    const url = URL.createObjectURL(new Blob([bytes as BlobPart], { type: "application/pdf" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.rel = "noopener";
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
    if (hint) toast(hint);
    return { how: "download" };
  } catch (e) {
    return { how: "none", error: (e as Error).message || "The browser blocked the download." };
  }
}

/** Share an already-built blob (used by the tools that produce ZIPs / images). */
export async function shareBlob(blob: Blob, filename: string, title = filename): Promise<SaveResult> {
  try {
    const file = new File([blob], filename, { type: blob.type });
    if (typeof navigator.canShare !== "function" || !navigator.canShare({ files: [file] })) return { how: "none", error: "This browser cannot share files." };
    await navigator.share({ files: [file], title });
    return { how: "share" };
  } catch (e) {
    if ((e as Error)?.name === "AbortError") return { how: "none" };
    return { how: "none", error: (e as Error).message };
  }
}

/** Register the service worker (offline after the first visit). No-op when unsupported. */
export async function registerServiceWorker(): Promise<boolean> {
  if (!("serviceWorker" in navigator) || location.protocol === "blob:") return false;
  try {
    await navigator.serviceWorker.register("./sw.js", { scope: "./" });
    return true;
  } catch {
    return false;
  }
}

/** Non-intrusive install prompt (beforeinstallprompt). Returns a "install" trigger or null. */
export function watchInstallPrompt(onReady: () => void): () => void {
  const h = (e: Event) => {
    e.preventDefault();
    (window as unknown as { __pfInstall: Event }).__pfInstall = e;
    onReady();
  };
  window.addEventListener("beforeinstallprompt", h);
  return () => window.removeEventListener("beforeinstallprompt", h);
}
export async function promptInstall(): Promise<"accepted" | "dismissed" | "unavailable"> {
  const e = (window as unknown as { __pfInstall?: Event & { prompt(): Promise<void>; userChoice: Promise<{ outcome: string }> } }).__pfInstall;
  if (!e?.prompt) return "unavailable";
  await e.prompt();
  const { outcome } = await e.userChoice;
  return outcome === "accepted" ? "accepted" : "dismissed";
}
export const isStandalone = (): boolean => window.matchMedia("(display-mode: standalone)").matches || (navigator as { standalone?: boolean }).standalone === true;
