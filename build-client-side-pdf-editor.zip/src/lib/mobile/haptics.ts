/** Haptics (Task G): short vibration on key events where supported, silent elsewhere. */
let enabled = true;
try {
  enabled = localStorage.getItem("qf-haptics") !== "off";
} catch {
  /* storage unavailable */
}
export const setHaptics = (on: boolean) => {
  enabled = on;
  try {
    localStorage.setItem("qf-haptics", on ? "on" : "off");
  } catch {
    /* ignore */
  }
};
export const hapticsEnabled = () => enabled;

export type Buzz = "tap" | "toggle" | "error";
const PATTERNS: Record<Buzz, number | number[]> = { tap: 8, toggle: 14, error: [12, 40, 12] };

/** Fire-and-forget; never throws (unsupported browsers, user gesture requirements). */
export function buzz(kind: Buzz = "tap") {
  if (!enabled) return;
  try {
    navigator.vibrate?.(PATTERNS[kind]);
  } catch {
    /* not supported / blocked */
  }
}
