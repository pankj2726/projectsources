/**
 * Pinch / pan geometry (TASKS-03 Task B). Pure and DOM-free so every invariant can be unit-tested.
 *
 * The viewer is a NATIVE scroll container (pages are laid out in CSS px at the current zoom) plus ONE CSS transform that is
 * only alive during a gesture. That gives the spec's I2 ("during a gesture only a GPU transform changes") while keeping
 * Android's native, battery-friendly scrolling for one-finger panning, and `touch-action: pan-x pan-y` disables the
 * browser's own pinch-zoom so ours is the only one.
 */
export interface Focal {
  /** focal point in CONTENT coordinates (independent of scroll) */
  x: number;
  y: number;
  /** focal point in the container's client coordinates */
  cx: number;
  cy: number;
}

export const MIN_ZOOM = 0.25;
export const MAX_ZOOM = 5;
export const DOUBLE_TAP_ZOOM = 2;
export const DOUBLE_TAP_MS = 300;
/** snap to fit-width within ±5% */
export const FIT_SNAP = 0.05;

export const clampZoom = (z: number, max = MAX_ZOOM): number => Math.min(max, Math.max(MIN_ZOOM, z));
/** fit-width zoom for a page width in pt inside a container width in px */
export const fitWidthZoom = (pagePt: number, containerPx: number, pad = 32): number => (pagePt > 0 && containerPx > 0 ? Math.max(MIN_ZOOM, (containerPx - pad) / pagePt) : 1);
export const nearFit = (z: number, fit: number): boolean => Math.abs(z - fit) <= FIT_SNAP * Math.max(fit, 0.2);

/** Where the fingers are, in content coordinates. */
export function focalOf(clientX: number, clientY: number, rect: { left: number; top: number }, scrollX: number, scrollY: number): Focal {
  return { x: scrollX + (clientX - rect.left), y: scrollY + (clientY - rect.top), cx: clientX - rect.left, cy: clientY - rect.top };
}

/** Midpoint of two touches, in client coordinates. */
export const midpoint = (a: { clientX: number; clientY: number }, b: { clientX: number; clientY: number }) => ({
  x: (a.clientX + b.clientX) / 2,
  y: (a.clientY + b.clientY) / 2,
});
export const distance = (a: { clientX: number; clientY: number }, b: { clientX: number; clientY: number }) => Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);

/**
 * Scroll offsets that keep the focal point under the fingers while the content is visually scaled by `ratio`
 * (with `transform-origin` at the focal content point). Fractional on purpose (invariant I7).
 */
export function scrollForFocal(f: Focal, ratio: number): { scrollX: number; scrollY: number } {
  return { scrollX: f.x * ratio - f.cx, scrollY: f.y * ratio - f.cy };
}

/** The same content point after the layout zoom changes from `from` to `to` (fractional; invariant I7). */
export const contentPointAfter = (x: number, from: number, to: number): number => (x * to) / from;

/** Scroll offsets after the gesture that keep the focal point where it was on screen (invariant: focal drift ≤ 1 px). */
export function scrollAfterZoom(f: Focal, base: number, target: number): { scrollX: number; scrollY: number } {
  return { scrollX: contentPointAfter(f.x, base, target) - f.cx, scrollY: contentPointAfter(f.y, base, target) - f.cy };
}

/** Rubber-band resistance at the ends: full movement inside the range, then a decaying fraction. */
export function rubberBand(overflow: number, extent: number, dim = 260): number {
  const o = Math.max(-1, Math.min(1, overflow / Math.max(1, extent)));
  return (1 - 1 / (o * dim + 1)) * extent;
}

export interface TapInfo {
  moved: number;
  ms: number;
  fingers: number;
}
/** A tap = < slop px of movement, < 300 ms, one finger. Anything else is a pan / pinch (Task C.1). */
export const isTap = (t: TapInfo, slopPx = 10, maxMs = 300): boolean => t.fingers === 1 && t.moved < slopPx && t.ms < maxMs;

/**
 * Fat-finger hit-test slop in PAGE POINTS (Task C.1): 8–12 dp on screen, converted through the current zoom so the
 * tolerance is the same physical size at every zoom level.
 */
export const tapSlopPt = (slopDp = 10, zoom = 1): number => Math.max(2, slopDp / Math.max(zoom, 0.01));

/** Device-memory tier (Task E): 0 = unknown → assume mid-range. */
export const memoryTier = (deviceMemoryGb?: number): "low" | "mid" | "high" => (deviceMemoryGb === undefined ? "mid" : deviceMemoryGb <= 2 ? "low" : deviceMemoryGb <= 4 ? "mid" : "high");
export const MAX_ZOOM_FOR_TIER: Record<ReturnType<typeof memoryTier>, number> = { low: 2.5, mid: 3.5, high: 5 };
/** Hard cap on raster pixels per page (Task E): tile rendering is not implemented, so the cap lowers effective zoom. */
export const PIXEL_CAP: Record<ReturnType<typeof memoryTier>, number> = { low: 4_000_000, mid: 9_000_000, high: 16_000_000 };
