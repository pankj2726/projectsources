/**
 * Tiny toast bus for the mobile layer (Task F: "Saved to Downloads", Task G: plain-language errors).
 * Kept separate from the editor store so non-editor screens can use it.
 */
type Handler = (text: string, kind?: "info" | "error") => void;
let h: Handler | null = null;
export const setToastHandler = (fn: Handler | null) => {
  h = fn;
};
export const toast = (text: string, kind: "info" | "error" = "info") => h?.(text, kind);
