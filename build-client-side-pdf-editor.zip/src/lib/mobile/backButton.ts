/**
 * Android Back button / back gesture (TASKS-03 Task A, F55).
 *
 * The browser's history is used as a MODE STACK: opening a mode pushes a history entry; Back pops it and closes the topmost
 * mode instead of leaving the page. Order (Task A): close keyboard → close editor → close sheet → leave tool → leave page.
 * The page is never left while a mode is open, so work cannot be lost (autosave, F36, covers the rest).
 */
export type ModeKind = "keyboard" | "editor" | "sheet" | "tool" | "find" | "dialog";

export interface BackMode {
  kind: ModeKind;
  /** close this mode; return false if it refuses (e.g. the editor has an error) so Back is not swallowed */
  close(): boolean;
}

const stack: BackMode[] = [];
let armed = false;

export const pushMode = (m: BackMode): (() => void) => {
  stack.push(m);
  window.history.pushState({ pfMode: stack.length }, "");
  arm();
  return () => {
    const i = stack.indexOf(m);
    if (i >= 0) {
      stack.splice(i, 1);
      if (window.history.state?.pfMode) window.history.back();
    }
  };
};

function arm() {
  if (armed) return;
  armed = true;
  window.addEventListener("popstate", onPop);
}

function onPop() {
  const top = stack[stack.length - 1];
  if (!top) return; // nothing of ours open: let the browser leave the page
  if (top.close() === false) {
    // the mode refused to close: put the entry back so Back does not leave the page either
    window.history.pushState({ pfMode: stack.length }, "");
    return;
  }
  stack.pop();
}

/** Remove every mode (used when the document closes). */
export const clearModes = () => {
  stack.length = 0;
};

export const modeDepth = () => stack.length;
