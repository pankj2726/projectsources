import type { ToolId } from "./model/docState";

export interface ToolButtonDef {
  id: ToolId | "image";
  label: string;
  icon: string;
  key: string;
}

/** Toolbar contents. Kept in a pure module so the UI-checklist test (and the Playwright suite) can read it without React. */
export const TOOL_BUTTONS: ToolButtonDef[] = [
  { id: "select", label: "Select", icon: "➤", key: "V" },
  { id: "hand", label: "Pan", icon: "✋", key: "H" },
  { id: "edittext", label: "Edit text", icon: "✎", key: "E" },
  { id: "text", label: "Text", icon: "T", key: "T" },
  { id: "highlight", label: "Highlight", icon: "▮", key: "M" },
  { id: "underline", label: "Underline", icon: "U̲", key: "U" },
  { id: "strike", label: "Strike", icon: "S̶", key: "S" },
  { id: "draw", label: "Draw", icon: "✍", key: "D" },
  { id: "rect", label: "Rectangle", icon: "▭", key: "R" },
  { id: "ellipse", label: "Ellipse", icon: "◯", key: "O" },
  { id: "line", label: "Line", icon: "╱", key: "L" },
  { id: "arrow", label: "Arrow", icon: "→", key: "A" },
  { id: "image", label: "Image", icon: "🖼", key: "I" },
  { id: "note", label: "Note", icon: "🗒", key: "N" },
  { id: "signature", label: "Sign", icon: "🖊", key: "G" },
  { id: "field", label: "Field", icon: "☐", key: "F" },
  { id: "whiteout", label: "Whiteout", icon: "▯", key: "W" },
  { id: "redact", label: "Redact", icon: "⬛", key: "K" },
  { id: "eraser", label: "Eraser", icon: "⌫", key: "X" },
];
