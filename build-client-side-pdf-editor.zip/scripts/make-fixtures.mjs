// Generates the license-safe fixture corpus (blueprint §9) into tests/fixtures/ using pdf-lib only.
// Usage: node scripts/make-fixtures.mjs
// NOT YET RUN in the authoring environment (no shell) – see docs/KNOWN_LIMITATIONS.md KL-ENV-1.
// Fixtures that need real-world files (scanned image-only, non-Latin embedded fonts, subset fonts, large images,
// linearized, attachments) must be added by hand: see tests/fixtures/README.md.
import { mkdirSync, writeFileSync } from "node:fs";
import { PDFDocument, StandardFonts, degrees } from "@cantoo/pdf-lib";

const out = "tests/fixtures";
mkdirSync(out, { recursive: true });
const save = (name, bytes) => (writeFileSync(`${out}/${name}`, bytes), console.log("wrote", name, bytes.length));

async function text(pages, size = [595.28, 841.89]) {
  const d = await PDFDocument.create();
  const f = await d.embedFont(StandardFonts.Helvetica);
  for (let i = 0; i < pages; i++) {
    const p = d.addPage(size);
    p.drawText(`Fixture page ${i + 1} – confidential-token-${i + 1}`, { x: 50, y: size[1] - 80, size: 18, font: f });
    p.drawText("The quick brown fox jumps over the lazy dog.", { x: 50, y: size[1] - 120, size: 12, font: f });
  }
  return d;
}

save("simple.pdf", await (await text(1)).save());
save("multi-page-300.pdf", await (await text(300)).save());

{
  const d = await text(3);
  [90, 180, 270].forEach((r, i) => d.getPage(i).setRotation(degrees(r)));
  save("rotated.pdf", await d.save());
}
{
  const d = await PDFDocument.create();
  [[595, 842], [842, 595], [300, 300], [612, 792]].forEach(([w, h], i) => d.addPage([w, h]).drawText(`size ${w}x${h}`, { x: 20, y: h - 40, size: 14 }));
  save("mixed-sizes.pdf", await d.save());
}
{
  const d = await text(2);
  d.getPage(0).setCropBox(50, 100, 400, 500);
  save("cropbox.pdf", await d.save());
}
{
  const d = await text(2);
  d.encrypt({ userPassword: "user123", ownerPassword: "owner123", permissions: { printing: true, copying: false } });
  save("encrypted.pdf", await d.save({ useObjectStreams: false }));
}
{
  const d = await PDFDocument.create();
  const page = d.addPage([595, 400]);
  const form = d.getForm();
  const name = form.createTextField("full_name");
  name.addToPage(page, { x: 50, y: 330, width: 250, height: 24 });
  form.createCheckBox("agree").addToPage(page, { x: 50, y: 280, width: 18, height: 18 });
  const dd = form.createDropdown("country");
  dd.addOptions(["India", "Brazil", "Japan"]);
  dd.addToPage(page, { x: 50, y: 230, width: 200, height: 24 });
  const rg = form.createRadioGroup("plan");
  rg.addOptionToPage("free", page, { x: 50, y: 180, width: 16, height: 16 });
  rg.addOptionToPage("pro", page, { x: 120, y: 180, width: 16, height: 16 });
  save("acroform.pdf", await d.save());
}
// layout.pdf + layout.truth.json: ONE page with every boundary case + the hand-labelled expected line segments.
// tests/e2e/edittext.spec.ts clicks every word and asserts the opened unit equals the truth exactly.
{
  const W = 400;
  const H = 300;
  const d = await PDFDocument.create();
  const page = d.addPage([W, H]);
  const reg = await d.embedFont(StandardFonts.Helvetica);
  const bold = await d.embedFont(StandardFonts.HelveticaBold);
  const truth = { size: [W, H], units: [] };
  /** draws consecutive parts on one baseline (y measured from the TOP) and records the unit + its words */
  const line = (parts, x, baseline, size) => {
    let cx = x;
    let text = "";
    const words = [];
    for (const { t, font = reg, sz = size, dy = 0 } of parts) {
      page.drawText(t, { x: cx, y: H - baseline + dy, size: sz, font });
      for (const m of t.matchAll(/\S+/g)) {
        words.push({ text: m[0], x: cx + font.widthOfTextAtSize(t.slice(0, m.index), sz), w: font.widthOfTextAtSize(m[0], sz), baseline: baseline - dy, size: sz, start: text.length + m.index });
      }
      text += t;
      cx += font.widthOfTextAtSize(t, sz);
    }
    truth.units.push({ text, words });
  };
  line([{ t: "Quarterly Report", font: bold }], 40, 40, 18); // heading
  line([{ t: "The quarterly " }, { t: "report", font: bold }, { t: " is due on Friday" }], 40, 70, 11); // mixed styles, one sentence
  { // justified: every word drawn separately with STRETCHED but uniform spaces
    const words = ["The", "committee", "approved", "the", "annual", "budget"];
    const total = words.reduce((s, w) => s + reg.widthOfTextAtSize(w, 11), 0);
    const gap = (320 - total) / (words.length - 1);
    let cx = 40;
    let text = "";
    const ws = [];
    words.forEach((w, i) => {
      page.drawText(w, { x: cx, y: H - 95, size: 11, font: reg });
      const ww = reg.widthOfTextAtSize(w, 11);
      ws.push({ text: w, x: cx, w: ww, baseline: 95, size: 11, start: text.length });
      text += w + (i < words.length - 1 ? " " : "");
      cx += ww + gap;
    });
    truth.units.push({ text, words: ws });
  }
  line([{ t: "Left column first line" }], 40, 125, 10); // two columns: words next to the gutter must not bleed
  line([{ t: "left column second line" }], 40, 137, 10);
  line([{ t: "Right column first line" }], 220, 125, 10);
  line([{ t: "right column second line" }], 220, 137, 10);
  for (const [i, [a, b]] of [["Apples", "10"], ["Pears", "20"], ["Kiwis", "30"]].entries()) { // table with ruling lines
    line([{ t: a }], 40, 175 + i * 12, 10);
    line([{ t: b }], 120, 175 + i * 12, 10);
  }
  page.drawLine({ start: { x: 110, y: H - 163 }, end: { x: 110, y: H - 206 }, thickness: 0.6 });
  page.drawLine({ start: { x: 36, y: H - 163 }, end: { x: 160, y: H - 163 }, thickness: 0.6 });
  page.drawLine({ start: { x: 36, y: H - 206 }, end: { x: 160, y: H - 206 }, thickness: 0.6 });
  line([{ t: "Energy E=mc" }, { t: "2", sz: 7, dy: 4 }], 40, 235, 11); // superscript stays attached
  line([{ t: "1 Source: finance team, March" }], 40, 280, 7); // small footnote = its own unit
  save("layout.pdf", await d.save());
  writeFileSync(`${out}/layout.truth.json`, JSON.stringify(truth, null, 1));
  console.log("wrote layout.truth.json", truth.units.length, "units");
}
// gray-text.pdf / cmyk-text.pdf: ONE colour on the page, written with DeviceGray / DeviceCMYK operators. pdf.js reports them as
// RGB hex (it converts before emitting the operator), so tests/e2e/textsidebar.spec.ts checks the colour is detected, not "estimated".
{
  const { grayscale, cmyk } = await import("@cantoo/pdf-lib");
  for (const [name, color] of [["gray-text.pdf", grayscale(0.4)], ["cmyk-text.pdf", cmyk(1, 0, 0, 0)]]) {
    const d = await PDFDocument.create();
    const page = d.addPage([300, 120]);
    const f = await d.embedFont(StandardFonts.Helvetica);
    page.drawText("Coloured ink line", { x: 40, y: 60, size: 14, font: f, color });
    save(name, await d.save());
  }
}
// frame-bg.pdf: ONE line of text on a light, a dark and a striped "image-like" background (tests/e2e/textframe.spec.ts checks the
// frame is visible on all three). para.pdf: a 4-line paragraph for the paragraph-mode frame tests.
{
  const { rgb } = await import("@cantoo/pdf-lib");
  const d = await PDFDocument.create();
  const page = d.addPage([300, 300]);
  const f = await d.embedFont(StandardFonts.Helvetica);
  page.drawText("Light background line", { x: 30, y: 250, size: 14, font: f, color: rgb(0.08, 0.08, 0.08) });
  page.drawRectangle({ x: 0, y: 110, width: 300, height: 80, color: rgb(0.08, 0.08, 0.1) });
  page.drawText("Dark background line", { x: 30, y: 145, size: 14, font: f, color: rgb(1, 1, 1) });
  const stripes = [rgb(0.76, 0.37, 0.24), rgb(0.92, 0.86, 0.74), rgb(0.23, 0.47, 0.66), rgb(0.1, 0.4, 0.3)];
  for (let i = 0; i < 50; i++) page.drawRectangle({ x: i * 6, y: 10, width: 6, height: 80, color: stripes[i % stripes.length] });
  page.drawText("Image background line", { x: 30, y: 45, size: 14, font: f, color: rgb(0, 0, 0) });
  save("frame-bg.pdf", await d.save());
}
{
  const d = await PDFDocument.create();
  const page = d.addPage([300, 200]);
  const f = await d.embedFont(StandardFonts.Helvetica);
  ["The committee reviewed the proposal and agreed", "that the budget should be approved before the", "end of the quarter, subject to a final check by", "the finance team and the external auditors."].forEach((l, i) => page.drawText(l, { x: 20, y: 160 - i * 12, size: 10, font: f }));
  save("para.pdf", await d.save());
}
save("corrupt-truncated.pdf", (await (await text(3)).save()).slice(0, 700));
writeFileSync(`${out}/not-a-pdf.pdf`, "This is plain text pretending to be a PDF.\n");
