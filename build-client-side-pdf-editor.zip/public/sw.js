/* PageFlex service worker (TASKS-03 Task F): offline after the first visit.
 * The build inlines everything into one HTML file, so caching that document caches the whole app shell.
 * PDF content is never cached here: documents only ever live in memory / IndexedDB, never on a server.
 */
const CACHE = "pageflex-v1";
const SHELL = ["./", "./index.html", "./manifest.webmanifest"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET" || new URL(req.url).origin !== self.location.origin) return; // never touch CDN requests (cmaps, OCR data)
  // navigations: network first so a deploy is picked up, cache as the offline fallback
  if (req.mode === "navigate") {
    e.respondWith(fetch(req).then((r) => (r.ok ? caches.open(CACHE).then((c) => (c.put("./index.html", r.clone()), r)) : r)).catch(() => caches.match("./index.html").then((r) => r ?? Response.error())));
    return;
  }
  e.respondWith(caches.match(req).then((hit) => hit ?? fetch(req).then((r) => (r.ok && req.url.startsWith(self.location.origin) ? caches.open(CACHE).then((c) => (c.put(req, r.clone()), r)) : r))));
});
