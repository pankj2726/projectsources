/**
 * TASKS-02 Task 2 gate (revised) – the edit UNIT is the line segment; one click opens an inline editor; no hover UI.
 * NOT RUN (no browsers here). Needs: node scripts/make-fixtures.mjs  (layout.pdf, layout.truth.json, multi-page-300.pdf)
 *   npx playwright test tests/e2e/edittext.spec.ts --project=chromium --project=firefox --project=webkit
 * The synthetic equivalents live in src/tests/glyphMap.test.ts and src/tests/unitEdit.test.ts.
 * NOT covered here (still open, see docs/KNOWN_LIMITATIONS.md): scanned/OCR fixture, rotated and CropBox pages,
 * pixel-diff of neighbours, content-stream glyph removal.
 */
import { readFileSync } from "node:fs";
import { expect, test, type Page } from "@playwright/test";

const BASE = process.env.BASE_URL ?? "http://localhost:4173";
interface Word {
  text: string;
  x: number;
  w: number;
  baseline: number;
  size: number;
  start: number;
}
interface Truth {
  size: [number, number];
  units: { text: string; words: Word[] }[];
}
const truth: Truth = JSON.parse(readFileSync("tests/fixtures/layout.truth.json", "utf8"));
const LAYER = 'svg[aria-label="Click text to edit it"]';

async function openLayout(page: Page, query = "e2e=1&debug=text", fixture = "layout.pdf") {
  await page.goto(`${BASE}/?${query}`);
  await page.setInputFiles('input[type="file"]', `tests/fixtures/${fixture}`);
  await expect(page.getByRole("document")).toBeVisible();
  await page.evaluate(() => localStorage.setItem("qf-tour", "done"));
  const skip = page.getByRole("button", { name: "Skip" });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.keyboard.press("e");
  await expect(page.getByTestId("text-regions")).toHaveAttribute("d", /M/); // the text map is ready
}
const screenOf = async (page: Page, wx: number, wy: number) => {
  const b = (await page.locator("[data-page-index='0']").boundingBox())!;
  const k = b.width / truth.size[0];
  return { x: b.x + wx * k, y: b.y + wy * k };
};
const centre = (w: Word) => ({ x: w.x + w.w / 2, y: w.baseline - 0.3 * w.size });
const unit = (prefix: string) => truth.units.find((u) => u.text.startsWith(prefix))!;
const objs = (page: Page) =>
  page.evaluate(() => (window as unknown as { __qf: { useEditor: { getState(): { doc: { objects: Record<string, unknown>[] } } } } }).__qf.useEditor.getState().doc.objects.filter((o) => o.type === "textedit"));

test("unit grouping: clicking ANY word opens exactly its own line segment (no fragmentation, no bleed)", async ({ page }) => {
  await openLayout(page);
  for (const u of truth.units) {
    for (const w of u.words) {
      const p = await screenOf(page, centre(w).x, centre(w).y);
      await page.mouse.click(p.x, p.y);
      await expect(page.getByTestId("active-unit-text")).toHaveText(u.text);
      await page.keyboard.press("Escape");
      await expect(page.getByTestId("inline-editor")).toHaveCount(0);
    }
  }
});

test("ONE click opens the inline editor: visible, focused, with no prior mousemove and no second click", async ({ page }) => {
  await openLayout(page, "e2e=1");
  const w = unit("The quarterly").words[1];
  const p = await screenOf(page, centre(w).x, centre(w).y);
  await page.locator(LAYER).first().dispatchEvent("pointerdown", { clientX: p.x, clientY: p.y, button: 0, pointerType: "mouse" });
  await expect(page.getByTestId("inline-editor")).toBeFocused({ timeout: 500 });
  await expect(page.getByTestId("inline-editor")).toHaveValue("The quarterly report is due on Friday");
});

test("no hover UI: moving across all text adds no overlay element and no highlight", async ({ page }) => {
  await openLayout(page, "e2e=1");
  const layer = page.locator(`${LAYER} > g`);
  const before = await layer.locator("*").count();
  for (const u of truth.units) for (const w of u.words) {
    const p = await screenOf(page, centre(w).x, centre(w).y);
    await page.mouse.move(p.x, p.y);
  }
  expect(await layer.locator("*").count()).toBe(before);
  await expect(page.getByTestId("hover-highlight")).toHaveCount(0);
  await expect(page.getByTestId("inline-editor")).toHaveCount(0);
});

test("the caret lands within one glyph of the click", async ({ page }) => {
  await openLayout(page, "e2e=1");
  const u = unit("The quarterly");
  const w = u.words[1]; // "quarterly"
  const p = await screenOf(page, w.x + w.w * 0.5, centre(w).y);
  await page.mouse.click(p.x, p.y);
  const sel = await page.getByTestId("inline-editor").evaluate((el) => (el as HTMLInputElement).selectionStart);
  expect(Math.abs((sel ?? -99) - (w.start + Math.round(w.text.length * 0.5)))).toBeLessThanOrEqual(1);
});

test("clicking another unit commits the first and opens the second in one action", async ({ page }) => {
  await openLayout(page, "e2e=1&debug=text");
  const a = unit("The quarterly").words[0];
  const b = unit("Left column first").words[0];
  const pa = await screenOf(page, centre(a).x, centre(a).y);
  await page.mouse.click(pa.x, pa.y);
  await page.getByTestId("inline-editor").fill("A The quarterly report is due on Friday");
  const pb = await screenOf(page, centre(b).x, centre(b).y);
  await page.mouse.click(pb.x, pb.y);
  expect(await objs(page)).toHaveLength(1);
  await expect(page.getByTestId("active-unit-text")).toHaveText(unit("Left column first").text);
});

test("clicking blank space commits and closes without opening anything", async ({ page }) => {
  await openLayout(page, "e2e=1");
  const w = unit("The quarterly").words[0];
  const p = await screenOf(page, centre(w).x, centre(w).y);
  await page.mouse.click(p.x, p.y);
  await page.getByTestId("inline-editor").fill("Edited sentence one");
  const blank = await screenOf(page, 380, 20);
  await page.mouse.click(blank.x, blank.y);
  await expect(page.getByTestId("inline-editor")).toHaveCount(0);
  expect(await objs(page)).toHaveLength(1);
});

test("structure: editing one word leaves the other words in place; the edit is ONE undo step", async ({ page }) => {
  await openLayout(page, "e2e=1");
  const u = unit("The quarterly");
  const [the, quarterly] = u.words;
  const p = await screenOf(page, centre(quarterly).x, centre(quarterly).y);
  await page.mouse.click(p.x, p.y);
  await page.getByTestId("inline-editor").fill("The annual report is due on Friday");
  await page.keyboard.press("Enter");
  const o = (await objs(page)) as { text: string; unitA: number; covers: { x: number }[] }[];
  expect(o).toHaveLength(1);
  expect(o[0].unitA).toBe(4); // "The " is untouched
  expect(o[0].text.startsWith("annual")).toBe(true);
  expect(o[0].covers[0].x).toBeGreaterThan(the.x + the.w - 0.5); // never covers the unchanged word before it
  expect(o[0].covers[0].x).toBeGreaterThanOrEqual(quarterly.x - 1.5);
  await page.keyboard.press("Control+z");
  expect(await objs(page)).toHaveLength(0); // the whole edit is a single command
});

test("Escape cancels; an unchanged line does nothing", async ({ page }) => {
  await openLayout(page, "e2e=1");
  const w = unit("The quarterly").words[0];
  const p = await screenOf(page, centre(w).x, centre(w).y);
  await page.mouse.click(p.x, p.y);
  await page.getByTestId("inline-editor").fill("nope");
  await page.keyboard.press("Escape");
  expect(await objs(page)).toHaveLength(0);
  await page.mouse.click(p.x, p.y);
  await page.keyboard.press("Enter");
  expect(await objs(page)).toHaveLength(0);
});

test("edited document downloads and the post-edit check passes (no rollback)", async ({ page }) => {
  await openLayout(page, "e2e=1");
  const w = unit("The quarterly").words[1];
  const p = await screenOf(page, centre(w).x, centre(w).y);
  await page.mouse.click(p.x, p.y);
  await page.getByTestId("inline-editor").fill("The annual report is due on Friday");
  await page.keyboard.press("Enter");
  await page.getByRole("button", { name: /^⇩ Download/ }).click();
  const [dl] = await Promise.all([page.waitForEvent("download"), page.getByRole("button", { name: /export & download/i }).click()]);
  expect((await dl.suggestedFilename()).endsWith(".pdf")).toBe(true);
  await expect(page.getByText(/Re-parsed with pdf\.js: 1 page/)).toBeVisible();
  await expect(page.getByText(/text outside your edit changed/)).toHaveCount(0);
});

test("AUDIT: Ctrl+Z undoes the DOCUMENT edit after committing from the sidebar (focus must leave the text field)", async ({ page }) => {
  await open(page, "layout.pdf", "e2e=1");
  const u = unit("Left column first");
  await clickWord(page, u.words[0]);
  const box = page.getByTestId("sidebar-text");
  await box.fill("A completely different sentence");
  await box.press("Enter"); // commit from the sidebar
  await expect(page.getByTestId("inline-editor")).toHaveCount(0);
  expect(await objs(page)).toHaveLength(1);
  // focus must NOT still be inside the (now closed) text field, otherwise the browser undoes the typing in it
  const where = await page.evaluate(() => {
    const el = document.activeElement as HTMLElement | null;
    return { testid: el?.dataset?.testid ?? "", inSidebar: !!el?.closest("[data-text-sidebar]"), isViewer: el?.dataset.testid === "viewer" };
  });
  expect(where.testid).not.toBe("sidebar-text");
  expect(where.inSidebar).toBe(false);
  await page.keyboard.press("Control+z"); // the document undo
  expect(await objs(page)).toHaveLength(0); // the edit is gone
  await page.keyboard.press("Control+Shift+z"); // and back
  expect(await objs(page)).toHaveLength(1);
});

test("AUDIT: Ctrl+Z undoes the document edit after committing on the page, and the toolbar buttons work too", async ({ page }) => {
  await open(page, "layout.pdf", "e2e=1");
  const u = unit("Left column first");
  await clickWord(page, u.words[0]);
  await page.getByTestId("inline-editor").fill("A completely different sentence");
  await page.keyboard.press("Enter");
  expect(await objs(page)).toHaveLength(1);
  await page.getByRole("button", { name: "Undo", exact: true }).first().click(); // toolbar (desktop) or top bar (mobile)
  expect(await objs(page)).toHaveLength(0);
  await page.getByRole("button", { name: "Redo", exact: true }).first().click();
  expect(await objs(page)).toHaveLength(1);
  await page.keyboard.press("Control+z");
  expect(await objs(page)).toHaveLength(0);
});

test("AUDIT: while the formatting is LOCKED, Ctrl/Cmd+B does not restyle (Task D)", async ({ page }) => {
  await open(page, "layout.pdf", "e2e=1");
  await clickWord(page, unit("Left column first").words[0]);
  await expect(page.getByTestId("lock-toggle")).toHaveAttribute("aria-pressed", "false"); // locked by default
  const mod = process.platform === "darwin" ? "Meta" : "Control";
  await page.keyboard.press(`${mod}+b`);
  await expect(page.getByRole("button", { name: "Bold", exact: true })).toHaveAttribute("aria-pressed", "false");
  await page.getByTestId("lock-toggle").click(); // unlock
  await expect(page.getByTestId("lock-toggle")).toHaveAttribute("aria-pressed", "true");
  await page.keyboard.press(`${mod}+b`);
  await expect(page.getByRole("button", { name: "Bold", exact: true })).toHaveAttribute("aria-pressed", "true");
});

test.describe("touch", () => {
  test.use({ hasTouch: true });
  test("a tap opens the inline editor", async ({ page }) => {
    await openLayout(page, "e2e=1");
    const w = unit("The quarterly").words[1];
    const p = await screenOf(page, centre(w).x, centre(w).y);
    await page.touchscreen.tap(p.x, p.y);
    await expect(page.getByTestId("inline-editor")).toBeVisible();
  });
});

test("opens in < 100 ms on a 300-page document", async ({ page }) => {
  await page.goto(`${BASE}/?e2e=1`);
  await page.setInputFiles('input[type="file"]', "tests/fixtures/multi-page-300.pdf");
  await expect(page.getByRole("document")).toBeVisible();
  await page.evaluate(() => localStorage.setItem("qf-tour", "done"));
  const skip = page.getByRole("button", { name: "Skip" });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.keyboard.press("e");
  await expect(page.getByTestId("text-regions").first()).toHaveAttribute("d", /M/);
  const b = (await page.locator("[data-page-index='0']").boundingBox())!;
  const k = b.width / 595.28;
  const ms = await page.evaluate(
    ({ x, y }) =>
      new Promise<number>((res) => {
        const svg = document.querySelector('svg[aria-label="Click text to edit it"]')!;
        const t0 = performance.now();
        svg.dispatchEvent(new PointerEvent("pointerdown", { clientX: x, clientY: y, button: 0, pointerType: "mouse", bubbles: true }));
        const tick = () => (document.querySelector('[data-testid="inline-editor"]') ? res(performance.now() - t0) : requestAnimationFrame(tick));
        tick();
      }),
    { x: b.x + 70 * k, y: b.y + (80 - 0.3 * 18) * k }
  );
  console.log(`editor opened in ${ms.toFixed(1)} ms`);
  expect(ms).toBeLessThan(100);
});
