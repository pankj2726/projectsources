/**
 * TASKS-02 §2.4C gate – the ACTIVE TEXT BOX (F45). NOT RUN (no browsers here; @playwright/test is not installed).
 *   node scripts/make-fixtures.mjs && npm run build && npm run preview &
 *   npx playwright test tests/e2e/textframe.spec.ts --project=chromium --project=firefox --project=webkit
 * Needs: layout.pdf + layout.truth.json, rotated.pdf, cropbox.pdf, frame-bg.pdf, para.pdf.
 * Visual baselines (`toHaveScreenshot`) only run with VISUAL=1 and need `--update-snapshots` once to create them.
 * NOTE: tests/ is not covered by `tsc`, and Playwright serialises every page.evaluate callback, so those callbacks must not
 * reference module-level helpers (only the inlined `window as … Qf` cast, which is erased).
 * Cases NOT covered (docs/KNOWN_LIMITATIONS.md KL-FRAME-*): dragging handles BY TOUCH (Playwright's touchscreen has no drag),
 * scanned pages, WebKit-specific focus behaviour beyond what these tests assert.
 */
import { readFileSync } from "node:fs";
import { expect, test, type Locator, type Page } from "@playwright/test";

const BASE = process.env.BASE_URL ?? "http://localhost:4173";
interface Word { text: string; x: number; w: number; baseline: number; size: number; start: number }
interface Truth { size: [number, number]; units: { text: string; words: Word[] }[] }
const truth: Truth = JSON.parse(readFileSync("tests/fixtures/layout.truth.json", "utf8"));
const PAD = 3; // visual padding in screen px, see FRAME_PAD_PX
const unit = (prefix: string) => truth.units.find((u) => u.text.startsWith(prefix))!;

type Qf = {
  useEditor: { getState(): { doc: { objects: Record<string, unknown>[] } }; setState(p: object): void };
  useEditSession: { getState(): { session: null | { past: unknown[]; base: { size: number }; extras: Record<string, number | null> } } };
};

async function open(page: Page, fixture = "layout.pdf", query = "e2e=1&debug=text") {
  await page.goto(`${BASE}/?${query}`);
  await page.setInputFiles('input[type="file"]', `tests/fixtures/${fixture}`);
  await expect(page.getByRole("document")).toBeVisible();
  await page.evaluate(() => localStorage.setItem("qf-tour", "done"));
  const skip = page.getByRole("button", { name: "Skip" });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.keyboard.press("e");
  await expect(page.getByTestId("text-regions").first()).toHaveAttribute("d", /M/);
}
const screenOf = async (page: Page, wx: number, wy: number) => {
  const b = (await page.locator("[data-page-index='0']").boundingBox())!;
  const k = b.width / truth.size[0];
  return { x: b.x + wx * k, y: b.y + wy * k, k };
};
const clickWord = async (page: Page, w: Word) => {
  const p = await screenOf(page, w.x + w.w / 2, w.baseline - 0.3 * w.size);
  await page.mouse.click(p.x, p.y);
};
/** click the centre of the Nth detected unit (works on any page rotation / CropBox, no ground truth needed) */
const clickUnit = async (page: Page, n = 0) => {
  const b = (await page.locator("[data-unit-id]").nth(n).boundingBox())!;
  await page.mouse.click(b.x + b.width / 2, b.y + b.height / 2);
};
const frame = (page: Page) => page.getByTestId("text-frame");
const outline = (page: Page) => page.getByTestId("frame-outline");
const setView = (page: Page, patch: Record<string, unknown>) => page.evaluate((p) => (window as unknown as { __qf: Qf }).__qf.useEditor.setState(p), patch);
const objs = (page: Page) => page.evaluate(() => (window as unknown as { __qf: Qf }).__qf.useEditor.getState().doc.objects.filter((o) => o.type === "textedit"));
const sess = (page: Page) =>
  page.evaluate(() => {
    const s = (window as unknown as { __qf: Qf }).__qf.useEditSession.getState().session;
    return s ? { past: s.past.length, size: s.base.size, dx: s.extras.dx as number, dy: s.extras.dy as number, rot: s.extras.rotation as number, boxW: s.extras.boxW as number | null } : null;
  });
const num = async (l: Locator, a: string) => parseFloat((await l.getAttribute(a))!);

/** drag from the centre of `from` (or an explicit point) by (dx, dy) screen px */
async function drag(page: Page, from: Locator | { x: number; y: number }, dx: number, dy: number, shift = false) {
  let pt: { x: number; y: number };
  if ("boundingBox" in from) {
    const b = (await from.boundingBox())!;
    pt = { x: b.x + b.width / 2, y: b.y + b.height / 2 };
  } else pt = from;
  if (shift) await page.keyboard.down("Shift");
  await page.mouse.move(pt.x, pt.y);
  await page.mouse.down();
  await page.mouse.move(pt.x + dx / 2, pt.y + dy / 2, { steps: 4 });
  await page.mouse.move(pt.x + dx, pt.y + dy, { steps: 4 });
  await page.mouse.up();
  if (shift) await page.keyboard.up("Shift");
}
/** the frame's outline and the inline editor must coincide (the frame adds PAD px of visual padding on every side) */
async function expectAligned(page: Page, tol = 2.5) {
  const o = (await outline(page).boundingBox())!;
  const i = (await page.getByTestId("inline-editor").boundingBox())!;
  expect(Math.abs(o.x - (i.x - PAD)), "left").toBeLessThanOrEqual(tol);
  expect(Math.abs(o.y - (i.y - PAD)), "top").toBeLessThanOrEqual(tol);
  expect(Math.abs(o.width - (i.width + 2 * PAD)), "width").toBeLessThanOrEqual(tol);
  expect(Math.abs(o.height - (i.height + 2 * PAD)), "height").toBeLessThanOrEqual(tol);
}

test("ONE click shows the text box within 100 ms, with no hover first; its bounds equal the unit's (±2 px)", async ({ page }) => {
  await open(page);
  const u = unit("Left column first");
  const first = u.words[0];
  const last = u.words[u.words.length - 1];
  const p = await screenOf(page, first.x + first.w / 2, first.baseline - 0.3 * first.size);
  const ms = await page.evaluate(
    ({ x, y }) =>
      new Promise<number>((res) => {
        const svg = document.querySelector('svg[aria-label="Click text to edit it"]')!;
        const t0 = performance.now();
        svg.dispatchEvent(new PointerEvent("pointerdown", { clientX: x, clientY: y, button: 0, pointerType: "mouse", bubbles: true })); // no mousemove before
        const tick = () => (document.querySelector('[data-testid="text-frame"]') ? res(performance.now() - t0) : requestAnimationFrame(tick));
        tick();
      }),
    { x: p.x, y: p.y }
  );
  console.log(`text box visible after ${ms.toFixed(1)} ms`);
  expect(ms).toBeLessThan(100);
  const tol = 2 / p.k + 0.5; // ±2 px, expressed in pt (+ the 0.2 pt the descender adds to the band)
  const f = frame(page);
  expect(Math.abs((await num(f, "data-box-x")) - (first.x - 1))).toBeLessThanOrEqual(tol);
  expect(Math.abs((await num(f, "data-box-w")) - (last.x + last.w - first.x + 2))).toBeLessThanOrEqual(tol);
  expect(Math.abs((await num(f, "data-box-y")) - (first.baseline - 0.8 * first.size - 1))).toBeLessThanOrEqual(tol);
  expect(Math.abs((await num(f, "data-box-h")) - (first.size + 2))).toBeLessThanOrEqual(tol);
  await expectAligned(page);
  for (const id of ["nw", "n", "ne", "e", "se", "s", "sw", "w"]) await expect(page.getByTestId(`frame-handle-${id}`)).toBeVisible();
  await expect(page.getByTestId("frame-rotate")).toBeVisible();
  await expect(page.getByTestId("frame-move-grip")).toBeVisible();
});

test("never on hover, never on a non-active unit, fully removed after commit or cancel", async ({ page }) => {
  await open(page);
  for (const u of truth.units) for (const w of u.words) {
    const p = await screenOf(page, w.x + w.w / 2, w.baseline - 0.3 * w.size);
    await page.mouse.move(p.x, p.y);
  }
  await expect(frame(page)).toHaveCount(0);
  await clickWord(page, unit("Left column first").words[0]);
  await expect(frame(page)).toHaveCount(1);
  const a = await num(frame(page), "data-box-x");
  await clickWord(page, unit("Right column first").words[0]); // commit A + open B in one action: still exactly ONE frame, now B's
  await expect(frame(page)).toHaveCount(1);
  expect(Math.abs((await num(frame(page), "data-box-x")) - a)).toBeGreaterThan(50);
  await page.keyboard.press("Escape"); // cancel
  const residue = () => page.evaluate(() => document.querySelectorAll('[data-text-frame], [data-testid^="frame-"], [data-testid="editor-rotator"]').length);
  expect(await residue()).toBe(0);
  await clickWord(page, unit("Left column first").words[0]);
  await page.getByTestId("inline-editor").fill("changed");
  await page.keyboard.press("Enter"); // commit
  expect(await residue()).toBe(0);
  const before = await objs(page);
  const p = await screenOf(page, 200, 150);
  await page.mouse.move(p.x, p.y);
  await page.mouse.down();
  await page.mouse.move(p.x + 40, p.y + 40);
  await page.mouse.up(); // a stray drag over the old frame position changes nothing: no listener survived the edit
  expect(await objs(page)).toEqual(before);
});

test("stays aligned through zoom, scroll, view rotation, page /Rotate and CropBox offsets; grows and shrinks with the text", async ({ page }) => {
  await open(page);
  await clickWord(page, unit("Left column first").words[0]);
  await expectAligned(page);
  await setView(page, { fitWidth: false, zoom: 1.7 });
  await expectAligned(page);
  await setView(page, { fitWidth: false, zoom: 0.6 });
  await expectAligned(page);
  await page.getByRole("document").evaluate((el) => el.scrollBy(0, 30));
  await expectAligned(page);
  await setView(page, { viewRotation: 90 });
  await expectAligned(page);
  await setView(page, { viewRotation: 0 });
  const w0 = (await outline(page).boundingBox())!.width;
  await page.getByTestId("inline-editor").pressSequentially(" and quite a few more words", { delay: 5 });
  const w1 = (await outline(page).boundingBox())!.width;
  expect(w1).toBeGreaterThan(w0 + 30); // grows as typed
  await page.getByTestId("inline-editor").press("Control+a");
  await page.getByTestId("inline-editor").press("Delete");
  await page.getByTestId("inline-editor").pressSequentially("ab");
  expect((await outline(page).boundingBox())!.width).toBeLessThan(w0); // …and shrinks
  await expectAligned(page);
  for (const fixture of ["rotated.pdf", "cropbox.pdf"]) {
    await page.keyboard.press("Escape");
    await open(page, fixture);
    await clickUnit(page, 0);
    await expect(frame(page)).toHaveCount(1);
    await expectAligned(page);
    await setView(page, { fitWidth: false, zoom: 1.3 });
    await expectAligned(page);
  }
});

test.describe("handles – every change is ONE undo step and survives export", () => {
  test.beforeEach(async ({ page }) => {
    await open(page);
    await clickWord(page, unit("Left column first").words[0]);
    await expect(frame(page)).toHaveCount(1);
  });

  test("right edge: wider gives room, narrower shrinks to fit (never below 60%)", async ({ page }) => {
    const s0 = (await sess(page))!;
    await drag(page, page.getByTestId("frame-handle-e"), 80, 0);
    const wider = (await sess(page))!;
    expect(wider.boxW!).toBeGreaterThan(0);
    expect(wider.size).toBe(s0.size);
    expect(wider.past).toBe(s0.past + 1);
    const b = (await outline(page).boundingBox())!;
    await drag(page, page.getByTestId("frame-handle-e"), -(b.width * 0.55), 0);
    const narrower = (await sess(page))!;
    expect(narrower.size).toBeLessThan(s0.size);
    expect(narrower.size).toBeGreaterThanOrEqual(s0.size * 0.6 - 0.01);
    expect(narrower.past).toBe(wider.past + 1);
    await expect(page.getByTestId("inline-editor")).toBeVisible();
  });

  test("Shift + corner scales the font size proportionally", async ({ page }) => {
    const s0 = (await sess(page))!;
    await drag(page, page.getByTestId("frame-handle-se"), 60, 20, true);
    const s1 = (await sess(page))!;
    expect(s1.size).toBeGreaterThan(s0.size * 1.1);
    expect(s1.past).toBe(s0.past + 1);
  });

  test("rotate handle rotates the text; Shift snaps to 15° steps; the frame and the editor turn together", async ({ page }) => {
    const h = (await page.getByTestId("frame-rotate").boundingBox())!;
    const o = (await outline(page).boundingBox())!;
    await drag(page, { x: h.x + h.width / 2, y: h.y + h.height / 2 }, o.width * 0.6, o.height * 2.5, true);
    const s = (await sess(page))!;
    expect(s.rot).not.toBe(0);
    expect(Math.abs(s.rot % 15)).toBeLessThan(0.001);
    expect(await frame(page).getAttribute("data-rotation")).toBe(String(s.rot));
    await expect(page.getByTestId("editor-rotator")).toHaveCSS("transform", /matrix/);
    await expectAligned(page, 6); // axis-aligned boxes of two rotated rectangles about the same pivot agree within the padding
  });

  test("move: drag the border, or the grip", async ({ page }) => {
    const o = (await outline(page).boundingBox())!;
    const s0 = (await sess(page))!;
    await drag(page, { x: o.x + o.width * 0.25, y: o.y + o.height }, 30, 20); // border, away from the handles
    const s1 = (await sess(page))!;
    expect(s1.dx).toBeGreaterThan(s0.dx);
    expect(s1.dy).toBeGreaterThan(s0.dy);
    expect(s1.past).toBe(s0.past + 1);
    await drag(page, page.getByTestId("frame-move-grip"), -10, -10);
    const s2 = (await sess(page))!;
    expect(s2.dx).toBeLessThan(s1.dx);
    expect(s2.past).toBe(s1.past + 1);
  });

  test("arrow keys nudge 1 pt (10 with Shift) when the BOX has focus; the editor keeps its caret otherwise", async ({ page }) => {
    const ed = page.getByTestId("inline-editor");
    await ed.press("ArrowLeft"); // in the editor: arrows move the caret, nothing is nudged
    expect((await sess(page))!.dx).toBe(0);
    await page.getByTestId("frame-border").focus();
    await expect(ed).toBeVisible(); // focusing the box does not commit or close the edit
    await page.keyboard.press("ArrowRight");
    expect((await sess(page))!.dx).toBe(1);
    await page.keyboard.press("Shift+ArrowDown");
    expect((await sess(page))!.dy).toBe(10);
    await page.keyboard.press("Escape"); // returns to typing
    await expect(ed).toBeFocused();
  });

  test("clicking the frame, a handle or the sidebar never blurs or commits the editor", async ({ page }) => {
    const ed = page.getByTestId("inline-editor");
    const s0 = (await sess(page))!;
    await page.getByTestId("frame-handle-nw").click();
    await expect(ed).toBeVisible();
    await expect(ed).toBeFocused();
    const o = (await outline(page).boundingBox())!;
    await page.mouse.click(o.x + o.width * 0.25, o.y + o.height); // the border
    await expect(ed).toBeFocused();
    await page.getByRole("button", { name: "Bold", exact: true }).click(); // the sidebar
    await expect(ed).toBeFocused();
    expect(await objs(page)).toHaveLength(0); // nothing was committed
    expect((await sess(page))!.past).toBe(s0.past + 1); // only the Bold change; the clicks left no undo steps
  });

  test("the sidebar's Box fields and the frame stay in sync BOTH ways", async ({ page }) => {
    await drag(page, page.getByTestId("frame-move-grip"), 24, 12);
    const s = (await sess(page))!;
    await expect(page.getByLabel("Offset X", { exact: true })).toHaveValue(String(Math.round(s.dx * 100) / 100));
    const x0 = (await outline(page).boundingBox())!.x;
    await page.getByLabel("Offset X", { exact: true }).fill(String(s.dx + 20));
    const x1 = (await outline(page).boundingBox())!.x;
    expect(x1).toBeGreaterThan(x0 + 5); // editing the field moved the frame live
    await page.getByLabel("Box width", { exact: true }).fill("150");
    expect(await num(frame(page), "data-box-w")).toBeCloseTo(150, 0);
    await page.getByLabel("Rotation", { exact: true }).fill("30");
    expect(await frame(page).getAttribute("data-rotation")).toBe("30");
    await expect(page.getByTestId("inline-editor")).toBeVisible();
  });

  test("a handle drag shows up in the committed object and in the downloaded PDF; the whole edit is one undo", async ({ page }) => {
    const o = (await outline(page).boundingBox())!;
    await drag(page, { x: o.x + o.width * 0.25, y: o.y + o.height }, 20, 10); // move
    const h = (await page.getByTestId("frame-rotate").boundingBox())!;
    await drag(page, { x: h.x + h.width / 2, y: h.y + h.height / 2 }, o.width * 0.5, o.height * 2.5, true); // rotate (snapped)
    await page.getByTestId("inline-editor").press("Enter");
    const e = (await objs(page)) as { rotation: number; dx: number; dy: number; restyled: boolean; text: string }[];
    expect(e).toHaveLength(1);
    expect(e[0].rotation).not.toBe(0);
    expect(e[0].dx).toBeGreaterThan(0);
    expect(e[0].restyled).toBe(true);
    await page.getByRole("button", { name: /^⇩ Download/ }).click();
    const [dl] = await Promise.all([page.waitForEvent("download"), page.getByRole("button", { name: /export & download/i }).click()]);
    expect((await dl.suggestedFilename()).endsWith(".pdf")).toBe(true);
    await expect(page.getByText(/Re-parsed with pdf\.js: 1 page/)).toBeVisible();
    await expect(page.getByText(/text outside your edit changed/)).toHaveCount(0);
    await expect(page.getByTestId("frame-handle-nw")).toHaveCount(0); // chrome never reaches the page / the file
    await page.keyboard.press("Escape");
    await page.keyboard.press("Control+z");
    expect(await objs(page)).toHaveLength(0); // the whole edit is a single command
  });
});

test("paragraph mode: dragging the right edge reflows the paragraph and the frame grows", async ({ page }) => {
  await open(page, "para.pdf");
  await page.getByRole("checkbox", { name: /Edit whole paragraph/ }).check();
  await clickUnit(page, 0);
  await expect(frame(page)).toHaveAttribute("data-kind", "para");
  const h0 = await num(frame(page), "data-box-h");
  const w0 = await num(frame(page), "data-box-w");
  const b = (await outline(page).boundingBox())!;
  await drag(page, page.getByTestId("frame-handle-e"), -b.width * 0.4, 0);
  const s = (await sess(page))!;
  expect(s.boxW!).toBeLessThan(w0);
  expect(await num(frame(page), "data-box-h")).toBeGreaterThan(h0); // more lines → taller box
  await page.getByTestId("inline-editor").press("Enter");
  const e = (await objs(page)) as { unitKey: string; w: number; text: string }[];
  expect(e[0].unitKey).toMatch(/^p/);
  expect(e[0].text.split("\n").length).toBeGreaterThan(4);
});

test("visible on light, dark and image backgrounds (white halo + accent line)", async ({ page }) => {
  await open(page, "frame-bg.pdf");
  for (const n of [0, 1, 2]) {
    await clickUnit(page, n);
    const o = (await outline(page).boundingBox())!;
    const clip = { x: Math.max(0, o.x - 8), y: Math.max(0, o.y - 8), width: o.width + 16, height: o.height + 16 };
    const png = (await page.screenshot({ clip })).toString("base64");
    const stats = await page.evaluate(async (b64) => {
      const img = await createImageBitmap(await (await fetch(`data:image/png;base64,${b64}`)).blob());
      const c = new OffscreenCanvas(img.width, img.height);
      const g = c.getContext("2d")!;
      g.drawImage(img, 0, 0);
      const d = g.getImageData(0, 0, img.width, img.height).data;
      let accent = 0;
      let white = 0;
      for (let i = 0; i < d.length; i += 4) {
        if (Math.abs(d[i] - 193) < 28 && Math.abs(d[i + 1] - 95) < 28 && Math.abs(d[i + 2] - 60) < 28) accent++;
        if (d[i] > 245 && d[i + 1] > 245 && d[i + 2] > 245) white++;
      }
      return { accent, white };
    }, png);
    expect(stats.accent, `accent line on background ${n}`).toBeGreaterThan(20);
    expect(stats.white, `white halo on background ${n}`).toBeGreaterThan(20);
    if (process.env.VISUAL) await expect(page).toHaveScreenshot(`text-frame-bg-${n}.png`, { clip, maxDiffPixelRatio: 0.02 });
    await page.keyboard.press("Escape");
  }
});

test.describe("touch", () => {
  test.use({ hasTouch: true });
  test("a tap opens the editor AND the text box with all its handles (they are large enough to hit)", async ({ page }) => {
    await open(page, "layout.pdf", "e2e=1");
    const w = unit("The quarterly").words[1];
    const p = await screenOf(page, w.x + w.w / 2, w.baseline - 0.3 * w.size);
    await page.touchscreen.tap(p.x, p.y);
    await expect(frame(page)).toHaveCount(1);
    for (const id of ["nw", "e", "se"]) {
      const b = (await page.getByTestId(`frame-handle-${id}`).boundingBox())!;
      expect(Math.min(b.width, b.height)).toBeGreaterThanOrEqual(8);
    }
    await expect(page.getByTestId("inline-editor")).toBeVisible();
  });
});
