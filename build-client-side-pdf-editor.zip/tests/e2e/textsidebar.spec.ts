/**
 * TASKS-02 §2.4A gate – the text properties sidebar (F44). NOT RUN (no browsers here; @playwright/test is not installed).
 *   node scripts/make-fixtures.mjs && npm run build && npm run preview &
 *   npx playwright test tests/e2e/textsidebar.spec.ts --project=chromium --project=firefox --project=webkit
 * Needs: layout.pdf + layout.truth.json, gray-text.pdf, cmyk-text.pdf. axe needs `npm i -D @axe-core/playwright` (that test skips without it).
 * Cases NOT covered yet (docs/KNOWN_LIMITATIONS.md KL-SIDEBAR-*): scanned/OCR pages, rotated pages, per-run colour detection on multi-colour pages.
 */
import { readFileSync } from "node:fs";
import { PDFDict, PDFDocument, PDFName } from "@cantoo/pdf-lib";
import { expect, test, type Page } from "@playwright/test";

const BASE = process.env.BASE_URL ?? "http://localhost:4173";
interface Word { text: string; x: number; w: number; baseline: number; size: number; start: number }
interface Truth { size: [number, number]; units: { text: string; words: Word[] }[] }
const truth: Truth = JSON.parse(readFileSync("tests/fixtures/layout.truth.json", "utf8"));
const SIDEBAR = '[data-testid="text-sidebar"]';
const LAYER = 'svg[aria-label="Click text to edit it"]';

async function open(page: Page, fixture = "layout.pdf", query = "e2e=1&debug=text") {
  await page.goto(`${BASE}/?${query}`);
  await page.setInputFiles('input[type="file"]', `tests/fixtures/${fixture}`);
  await expect(page.getByRole("document")).toBeVisible();
  await page.evaluate(() => localStorage.setItem("qf-tour", "done"));
  const skip = page.getByRole("button", { name: "Skip" });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.keyboard.press("e");
  await expect(page.getByTestId("text-regions")).toHaveAttribute("d", /M/); // the text map is ready
}
const screenOf = async (page: Page, wx: number, wy: number, pageW = truth.size[0]) => {
  const b = (await page.locator("[data-page-index='0']").boundingBox())!;
  const k = b.width / pageW;
  return { x: b.x + wx * k, y: b.y + wy * k };
};
const centre = (w: Word) => ({ x: w.x + w.w / 2, y: w.baseline - 0.3 * w.size });
const unit = (prefix: string) => truth.units.find((u) => u.text.startsWith(prefix))!;
const clickWord = async (page: Page, w: Word) => {
  const p = await screenOf(page, centre(w).x, centre(w).y);
  await page.mouse.click(p.x, p.y);
};
const objs = (page: Page) =>
  page.evaluate(() => (window as unknown as { __qf: { useEditor: { getState(): { doc: { objects: Record<string, unknown>[] } } } } }).__qf.useEditor.getState().doc.objects.filter((o) => o.type === "textedit"));
/** select [a, b) in the inline editor the way a user's drag/shift-arrows would */
const select = (page: Page, a: number, b: number) =>
  page.getByTestId("inline-editor").evaluate((el, [s, e]) => {
    const i = el as HTMLInputElement;
    i.setSelectionRange(s, e);
    i.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true }));
  }, [a, b]);
const btn = (page: Page, name: string) => page.getByRole("button", { name, exact: true });

test("ONE click opens the sidebar within 100 ms, with no hover first, populated from the clicked unit", async ({ page }) => {
  await open(page);
  const u = unit("The quarterly");
  const w = u.words[1];
  const p = await screenOf(page, centre(w).x, centre(w).y);
  const ms = await page.evaluate(
    ({ x, y }) =>
      new Promise<number>((res) => {
        const svg = document.querySelector('svg[aria-label="Click text to edit it"]')!;
        const t0 = performance.now();
        svg.dispatchEvent(new PointerEvent("pointerdown", { clientX: x, clientY: y, button: 0, pointerType: "mouse", bubbles: true })); // no mousemove before
        const tick = () => (document.querySelector('[data-testid="text-sidebar"][data-mode="editing"]') ? res(performance.now() - t0) : requestAnimationFrame(tick));
        tick();
      }),
    p
  );
  console.log(`sidebar visible after ${ms.toFixed(1)} ms`);
  expect(ms).toBeLessThan(100);
  const bar = page.locator(SIDEBAR);
  await expect(bar).toHaveAttribute("data-detected-size", String(w.size));
  await expect(bar).toHaveAttribute("data-detected-color", "#000000");
  await expect(bar).toHaveAttribute("data-detected-font", /Helvetica/);
  await expect(page.getByLabel("Font family", { exact: true })).toHaveValue(/Sans/);
  await expect(page.getByLabel("Font size", { exact: true })).toHaveValue(String(w.size));
  await expect(page.getByTestId("text-sidebar-target")).toContainText(u.text.slice(0, 20));
});

test("the heading reports ITS style (bold 18), not defaults", async ({ page }) => {
  await open(page);
  await clickWord(page, unit("Quarterly Report").words[0]);
  await expect(page.locator(SIDEBAR)).toHaveAttribute("data-detected-size", "18");
  await expect(page.getByTestId("detected-font")).toContainText("Helvetica");
});

test("gray and CMYK text: the colour is DETECTED (shown as RGB), not 'estimated'", async ({ page }) => {
  for (const [file, check] of [["gray-text.pdf", (c: string) => expect(c).toBe("#666666")], ["cmyk-text.pdf", (c: string) => { expect(c).toMatch(/^#[0-9a-f]{6}$/); expect(c).not.toBe("#000000"); }]] as const) {
    await open(page, file);
    const p = await screenOf(page, 70, 56, 300);
    await page.mouse.click(p.x, p.y);
    const colour = await page.locator(SIDEBAR).getAttribute("data-detected-color");
    check(colour!);
    await expect(page.getByLabel("Text colour hex", { exact: true })).toHaveValue(colour!);
    await expect(page.locator(SIDEBAR).getByText("estimated", { exact: false })).toHaveCount(0);
  }
});

test("interacting with the sidebar never closes or commits the editor; the edit is exported with the change", async ({ page }) => {
  await open(page);
  const u = unit("Left column first");
  await clickWord(page, u.words[0]);
  const editor = page.getByTestId("inline-editor");
  const target = await page.getByTestId("text-sidebar-target").textContent();

  await btn(page, "Bold").click();
  await expect(editor).toBeVisible();
  await expect(editor).toBeFocused(); // focus returned to the editor
  expect(await objs(page)).toHaveLength(0); // nothing committed yet

  await page.getByLabel("Font size", { exact: true }).fill("14"); // a real field takes focus legitimately…
  await expect(editor).toBeVisible(); // …and the editor stays open
  await page.getByLabel("Font size", { exact: true }).press("Enter");
  await expect(editor).toBeFocused();
  await btn(page, "Underline").click();
  await page.getByLabel("Text colour hex", { exact: true }).fill("#cc0000");
  await btn(page, "Italic").click();
  await expect(page.getByTestId("text-sidebar-target")).toHaveText(target!); // the unit never changed
  await expect(page.getByTestId("text-live-preview")).toBeVisible(); // live preview of underline

  await page.keyboard.press("Enter"); // commit
  const o = (await objs(page)) as { fontSize: number; bold: boolean; italic: boolean; underline: boolean; color: string; restyled: boolean; unitA: number }[];
  expect(o).toHaveLength(1);
  expect(o[0]).toMatchObject({ fontSize: 14, bold: true, italic: true, underline: true, color: "#cc0000", restyled: true, unitA: 0 });

  await page.getByRole("button", { name: /^⇩ Download/ }).click();
  const [dl] = await Promise.all([page.waitForEvent("download"), page.getByRole("button", { name: /export & download/i }).click()]);
  const bytes = readFileSync((await dl.path())!);
  await expect(page.getByText(/Re-parsed with pdf\.js: 1 page/)).toBeVisible();
  await expect(page.getByText(/text outside your edit changed/)).toHaveCount(0);
  const fonts = async (b: Uint8Array) => {
    const d = await PDFDocument.load(b);
    let n = 0;
    for (const [, obj] of d.context.enumerateIndirectObjects()) if (obj instanceof PDFDict && obj.get(PDFName.of("BaseFont"))?.toString() === "/Helvetica-BoldOblique") n++;
    return n;
  };
  expect(await fonts(bytes)).toBeGreaterThan(await fonts(readFileSync("tests/fixtures/layout.pdf"))); // the bold-italic face is in the output
});

test("range-aware: mixed values show 'Mixed'; a colour applies to the selected range only", async ({ page }) => {
  await open(page);
  const u = unit("The quarterly");
  await clickWord(page, u.words[1]);
  const full = u.text;
  const q = full.indexOf("quarterly");
  await select(page, q, q + 9);
  await expect(page.getByText("Applies to the 9 selected character(s)")).toBeVisible();
  await btn(page, "Bold").click();
  await expect(btn(page, "Bold")).toHaveAttribute("aria-pressed", "true"); // the selection is all bold…
  await select(page, 0, full.length);
  await expect(btn(page, "Bold")).toHaveAttribute("aria-pressed", "mixed"); // …the whole line is mixed
  await select(page, q, q + 9);
  await page.getByLabel("Text colour hex", { exact: true }).fill("#ff0000");
  await select(page, 0, full.length);
  await expect(page.getByLabel("Text colour hex", { exact: true })).toHaveAttribute("placeholder", "Mixed");
  await page.getByTestId("inline-editor").press("Enter");
  const o = (await objs(page)) as { spans: { a: number; b: number; s: Record<string, unknown> }[]; unitA: number; text: string }[];
  expect(o).toHaveLength(1);
  expect(o[0].unitA).toBe(q); // unchanged words before the range were NOT redrawn
  expect(o[0].spans).toEqual([{ a: 0, b: 9, s: { bold: true, color: "#ff0000" } }]);
  expect(o[0].text.startsWith("quarterly")).toBe(true);
});

test("keyboard shortcuts Ctrl/Cmd+B / I / U toggle the style from inside the editor", async ({ page }) => {
  await open(page);
  await clickWord(page, unit("Left column first").words[0]);
  const mod = process.platform === "darwin" ? "Meta" : "Control";
  for (const [k, name] of [["b", "Bold"], ["i", "Italic"], ["u", "Underline"]] as const) {
    await page.keyboard.press(`${mod}+${k}`);
    await expect(btn(page, name)).toHaveAttribute("aria-pressed", "true");
  }
});

test("click outside editor AND sidebar commits and closes; another unit switches the sidebar without it ever disappearing", async ({ page }) => {
  await open(page);
  const a = unit("The quarterly").words[0];
  const b = unit("Left column first").words[0];
  await clickWord(page, a);
  await expect(page.getByTestId("text-sidebar-target")).toContainText("The quarterly");
  await btn(page, "Bold").click();
  await page.evaluate(() => {
    const w = window as unknown as { __sidebarCounts: number[] };
    w.__sidebarCounts = [];
    new MutationObserver(() => w.__sidebarCounts.push(document.querySelectorAll('[data-testid="text-sidebar"]').length)).observe(document.body, { childList: true, subtree: true });
  });
  await clickWord(page, b); // commit A + open B in ONE action
  await expect(page.getByTestId("text-sidebar-target")).toContainText("Left column first");
  expect(await objs(page)).toHaveLength(1);
  const counts = await page.evaluate(() => (window as unknown as { __sidebarCounts: number[] }).__sidebarCounts);
  expect(counts.every((n) => n === 1)).toBe(true); // no frame without the sidebar → no flicker
  const blank = await screenOf(page, 380, 20);
  await page.mouse.click(blank.x, blank.y); // outside both
  await expect(page.getByTestId("inline-editor")).toHaveCount(0);
  await expect(page.locator(SIDEBAR)).toHaveAttribute("data-mode", "defaults"); // back to "next text box" defaults
});

test("with nothing being edited the sidebar shows the defaults for the NEXT text box and they are used", async ({ page }) => {
  await open(page);
  await expect(page.locator(SIDEBAR)).toHaveAttribute("data-mode", "defaults");
  await page.getByLabel("Font size", { exact: true }).fill("22");
  await btn(page, "Bold").click();
  await page.keyboard.press("Escape");
  await page.keyboard.press("t");
  const p = await screenOf(page, 200, 250);
  await page.mouse.click(p.x, p.y);
  const o = await page.evaluate(() => (window as unknown as { __qf: { useEditor: { getState(): { doc: { objects: Record<string, unknown>[] } } } } }).__qf.useEditor.getState().doc.objects.filter((x) => x.type === "text"));
  expect(o[0]).toMatchObject({ fontSize: 22, bold: true });
});

test("reset formatting, undo/redo format change, case transform and lock are wired", async ({ page }) => {
  await open(page);
  await clickWord(page, unit("Left column first").words[0]);
  await btn(page, "Bold").click();
  await expect(btn(page, "Bold")).toHaveAttribute("aria-pressed", "true");
  await btn(page, "Undo format change").click();
  await expect(btn(page, "Bold")).toHaveAttribute("aria-pressed", "false");
  await btn(page, "Redo format change").click();
  await expect(btn(page, "Bold")).toHaveAttribute("aria-pressed", "true");
  await btn(page, "Reset formatting").click();
  await expect(btn(page, "Bold")).toHaveAttribute("aria-pressed", "false");
  await btn(page, "UPPERCASE").click();
  await expect(page.getByTestId("inline-editor")).toHaveValue(/^LEFT COLUMN FIRST LINE$/);
  await btn(page, "Lock position").click();
  await expect(btn(page, "Lock position")).toHaveAttribute("aria-pressed", "true");
  await page.getByTestId("inline-editor").press("Enter");
  expect(((await objs(page)) as { locked: boolean }[])[0].locked).toBe(true);
});

test("keyboard-only: Tab from the editor reaches the sidebar without closing the edit; Escape returns to the editor", async ({ page }) => {
  await open(page);
  await clickWord(page, unit("Left column first").words[0]);
  let inside = false;
  for (let i = 0; i < 14 && !inside; i++) {
    await page.keyboard.press("Tab");
    inside = await page.evaluate(() => !!document.activeElement?.closest("[data-text-sidebar]"));
  }
  expect(inside).toBe(true);
  await expect(page.getByTestId("inline-editor")).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(page.getByTestId("inline-editor")).toBeFocused();
});

test("collapsible groups remember their state", async ({ page }) => {
  await open(page);
  await clickWord(page, unit("Left column first").words[0]);
  await page.getByRole("button", { name: "Color", exact: true }).click();
  await expect(page.getByLabel("Text colour", { exact: true })).toHaveCount(0);
  await page.reload();
  await page.setInputFiles('input[type="file"]', "tests/fixtures/layout.pdf");
  await page.keyboard.press("e");
  await expect(page.getByTestId("text-regions")).toHaveAttribute("d", /M/);
  await clickWord(page, unit("Left column first").words[0]);
  await expect(page.getByLabel("Text colour", { exact: true })).toHaveCount(0); // still collapsed
});

test("axe: no serious violations while the sidebar is open", async ({ page }) => {
  let Axe: new (o: { page: Page }) => { include(s: string): { analyze(): Promise<{ violations: { impact?: string | null; id: string }[] }> } };
  try {
    Axe = (await import("@axe-core/playwright" as string)).default;
  } catch {
    test.skip(true, "@axe-core/playwright is not installed");
    return;
  }
  await open(page);
  await clickWord(page, unit("Left column first").words[0]);
  const r = await new Axe({ page }).include(SIDEBAR).analyze();
  expect(r.violations.filter((v) => v.impact === "serious" || v.impact === "critical")).toEqual([]);
});

test("the Properties/Forms tabs stay visible while a text edit is open (they used to be replaced)", async ({ page }) => {
  await open(page, "layout.pdf", "e2e=1");
  await clickWord(page, unit("The quarterly").words[0]);
  for (const name of ["Properties", "Forms"]) await expect(page.getByRole("tab", { name, exact: true }), name).toBeVisible();
  await expect(page.getByRole("tab", { name: "Properties", exact: true })).toHaveAttribute("aria-selected", "true");
  await expect(page.getByTestId("text-sidebar")).toBeVisible(); // the text panel is INSIDE the Properties tab
});

test("the sidebar's Text box shows the line, is two-way with the page editor, and commits (the panel from the screenshot)", async ({ page }) => {
  await open(page, "layout.pdf", "e2e=1");
  const u = unit("The quarterly");
  await clickWord(page, u.words[0]);
  const box = page.getByTestId("sidebar-text");
  await expect(box).toBeVisible();
  await expect(box).toHaveValue(u.text); // the whole line segment, not a single word
  await expect(page.getByLabel("Reset text to the original")).toBeDisabled(); // nothing changed yet
  await expect(page.getByTestId("cover-note")).toContainText("Cover-and-replace");

  // sidebar → page editor → frame (two-way)
  await box.fill("The annual report is due on Friday");
  await expect(page.getByTestId("inline-editor")).toHaveValue("The annual report is due on Friday");
  await expect(page.getByTestId("text-frame")).toBeVisible();
  await expect(page.getByLabel("Reset text to the original")).toBeEnabled();

  // page editor → sidebar
  await page.getByTestId("inline-editor").fill("The weekly report is due on Friday");
  await expect(box).toHaveValue("The weekly report is due on Friday");

  // Original: … + Reset
  await expect(page.getByTestId("text-sidebar")).toContainText(`Original: “${u.text}”`);
  await page.getByLabel("Reset text to the original").click();
  await expect(box).toHaveValue(u.text);
  await expect(page.getByTestId("inline-editor")).toBeVisible(); // resetting the text must not close the edit

  // Enter in the sidebar commits the whole edit (one command)
  await box.fill("The annual report is due on Friday");
  await box.press("Enter");
  await expect(page.getByTestId("inline-editor")).toHaveCount(0);
  const o = (await objs(page)) as { text: string; unitA: number }[];
  expect(o).toHaveLength(1);
  expect(o[0].text).toBe("The annual report is due on Friday");
  expect(o[0].unitA).toBe(0); // the whole line was replaced → the whole line is redrawn
  await page.keyboard.press("Control+z");
  expect(await objs(page)).toHaveLength(0);
});

test.describe("mobile / tablet: bottom sheet", () => {
  test.use({ viewport: { width: 390, height: 844 }, hasTouch: true });
  test("a tap opens the editor AND a bottom sheet with exactly one sidebar; its controls work by touch", async ({ page }) => {
    await open(page, "layout.pdf", "e2e=1");
    const w = unit("The quarterly").words[1];
    const p = await screenOf(page, centre(w).x, centre(w).y);
    await page.touchscreen.tap(p.x, p.y);
    await expect(page.getByRole("region", { name: "Text properties sheet" })).toBeVisible();
    await expect(page.locator(SIDEBAR)).toHaveCount(1);
    await btn(page, "Italic").tap();
    await expect(btn(page, "Italic")).toHaveAttribute("aria-pressed", "true");
    await expect(page.getByTestId("inline-editor")).toBeVisible(); // the tap did not close the edit
  });
});
