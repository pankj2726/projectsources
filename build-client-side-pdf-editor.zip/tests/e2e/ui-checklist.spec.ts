/**
 * TASKS-02 §2.4B – UI feature checklist suite. NOT RUN (no browsers here).
 * Asserts that every toolbar / panel / shortcut from the feature registry (src/lib/uiRegistry.ts) is present and functional in
 * the RUNNING editor. Any previously working control that disappears fails the build. The static half is src/tests/uiChecklist.test.ts.
 */
import { expect, test, type Page } from "@playwright/test";
import { TEXT_FRAME_CONTROLS, TEXT_SIDEBAR_CONTROLS, UI_CHECKLIST } from "../../src/lib/uiRegistry";
import { TOOL_BUTTONS } from "../../src/lib/toolbarDef";

const BASE = process.env.BASE_URL ?? "http://localhost:4173";
const rx = (s: string) => new RegExp(`^\\s*${s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s*$`);

async function open(page: Page, fixture = "layout.pdf") {
  await page.goto(`${BASE}/?e2e=1`);
  await page.setInputFiles('input[type="file"]', `tests/fixtures/${fixture}`);
  await expect(page.getByRole("document")).toBeVisible();
  await page.evaluate(() => localStorage.setItem("qf-tour", "done"));
  const skip = page.getByRole("button", { name: "Skip" });
  if (await skip.isVisible().catch(() => false)) await skip.click();
}

test("every toolbar tool is present, and its shortcut selects it", async ({ page }) => {
  await open(page);
  for (const it of UI_CHECKLIST.filter((i) => i.where === "toolbar-tool")) await expect(page.getByRole("button", { name: it.name, exact: true }), `${it.feature} ${it.name}`).toBeVisible();
  for (const b of TOOL_BUTTONS) {
    if (b.id === "image" || b.id === "signature") continue; // these open a file chooser / dialog instead of arming a tool
    await page.keyboard.press(b.key.toLowerCase());
    await expect(page.getByRole("button", { name: `${b.label} (${b.key})`, exact: true }), `shortcut ${b.key}`).toHaveAttribute("aria-pressed", "true");
  }
});

test("header buttons, tabs and the page toolbar are present", async ({ page }) => {
  await open(page);
  for (const it of UI_CHECKLIST.filter((i) => i.where === "header-button")) await expect(page.getByRole("button", { name: it.name, exact: true }), `${it.feature} ${it.name}`).toBeVisible();
  for (const it of UI_CHECKLIST.filter((i) => i.where === "tab")) await expect(page.getByRole("tab", { name: it.name, exact: true }), `${it.feature} ${it.name}`).toBeVisible();
  await page.getByRole("button", { name: /^Page 1/ }).click();
  for (const it of UI_CHECKLIST.filter((i) => i.where === "page-toolbar")) await expect(page.getByRole("button", { name: it.name, exact: true }), `${it.feature} ${it.name}`).toBeVisible();
});

test("every Tools-menu entry is present and opens its panel", async ({ page }) => {
  await open(page);
  for (const it of UI_CHECKLIST.filter((i) => i.where === "tools-menu")) {
    await page.getByRole("button", { name: /^Tools/ }).click();
    await expect(page.getByRole("menuitem", { name: rx(it.name) }), `${it.feature} ${it.name}`).toBeVisible();
    await page.getByRole("menuitem", { name: rx(it.name) }).click();
    await expect(page.getByRole("dialog"), `${it.name} panel`).toBeVisible();
    await page.keyboard.press("Escape");
    await expect(page.getByRole("dialog")).toHaveCount(0);
  }
});

test("Find (Ctrl+F) and Replace (Ctrl+H) still open", async ({ page }) => {
  await open(page);
  await page.keyboard.press("Control+f");
  await expect(page.getByRole("search", { name: "Find" })).toBeVisible();
  await page.keyboard.press("Escape");
  await page.keyboard.press("Control+h");
  await expect(page.getByRole("search", { name: "Find and replace" })).toBeVisible();
});

test("the properties panel still appears for selected objects and for the text tools", async ({ page }) => {
  await open(page);
  await page.keyboard.press("e");
  await expect(page.getByTestId("text-sidebar")).toBeVisible(); // F44: defaults panel, never empty or hidden
  await page.keyboard.press("t");
  await expect(page.getByTestId("text-sidebar")).toBeVisible();
  await page.keyboard.press("r"); // rectangle: draw one and check the classic properties panel
  const b = (await page.locator("[data-page-index='0']").boundingBox())!;
  await page.mouse.move(b.x + 40, b.y + 200);
  await page.mouse.down();
  await page.mouse.move(b.x + 140, b.y + 260);
  await page.mouse.up();
  await expect(page.getByRole("heading", { name: "Rectangle" })).toBeVisible();
});

test("an open text edit shows the ACTIVE TEXT BOX with every handle (F45), and none while idle", async ({ page }) => {
  await open(page);
  await page.keyboard.press("e");
  await expect(page.getByTestId("text-frame")).toHaveCount(0); // idle: no frame, nothing on hover
  const b = (await page.locator("[data-page-index='0']").boundingBox())!;
  await page.mouse.click(b.x + b.width * 0.1, b.y + b.height * 0.2);
  if (!(await page.getByTestId("inline-editor").isVisible().catch(() => false))) test.skip(true, "could not hit a text line with the fixed click point; run textframe.spec.ts for the hit-tested flow");
  for (const name of TEXT_FRAME_CONTROLS) await expect(page.getByRole("button", { name, exact: true }), `text box lost "${name}"`).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(page.getByTestId("text-frame")).toHaveCount(0);
});

test("the text sidebar offers every control (F44) and each one is operable", async ({ page }) => {
  await open(page);
  await page.keyboard.press("e");
  const b = (await page.locator("[data-page-index='0']").boundingBox())!;
  await page.mouse.click(b.x + b.width * 0.1, b.y + b.height * 0.2); // any word on the first line of text
  if (!(await page.getByTestId("inline-editor").isVisible().catch(() => false))) test.skip(true, "could not hit a text line with the fixed click point; run textsidebar.spec.ts for the hit-tested flow");
  for (const name of TEXT_SIDEBAR_CONTROLS) await expect(page.getByLabel(name, { exact: true }).first(), `text sidebar lost "${name}"`).toBeVisible();
});
